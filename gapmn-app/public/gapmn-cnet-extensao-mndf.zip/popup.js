const _ext = typeof browser !== 'undefined' ? browser : chrome;
const POPUP_VERSION = '1.5.0'; // prefer /seguro/ tab over error/redirect pages

// Mapeamento real dos códigos de item do ComprasNet, confirmado ao vivo (via /v1/enums e
// inspeção de itens reais do pregão 90104/2025 - Lei 14.133/2021) contra a API do governo:
// `situacao` (SituacaoItemCompraEnum) só muda de "1" (Ativo) quando o item é formalmente
// encerrado fora do fluxo normal; `fase` (FaseItemEnum) é quem carrega a fase de trabalho
// real (aguardando julgamento, aguardando habilitação, aguardando encerramento etc).
const SITUACAO_ITEM_TERMINAL = {
  '2':  'Cancelado',
  '3':  'Anulado',
  '13': 'Anulado',
  '4':  'Revogado',
  '14': 'Revogado',
  '5':  'Suspenso',
  '6':  'Deserto',
  '7':  'Fracassado',
  '8':  'Fracassado',
  '9':  'Fracassado',
};
const FASE_ITEM_LABEL = {
  AS: 'Aguardando abertura da sessão pública',
  AP: 'Pendente de análise de propostas',
  F:  'Aguardando disputa',
  AA: 'Aguardando abertura',
  LS: 'Disputa suspensa',
  LA: 'Em disputa',
  LF: 'Em disputa (etapa fechada)',
  AL: 'Em disputa',
  FE: 'Aguardando encerramento',
  RA: 'Aguardando decisão sobre reinício',
  AF: 'Aguardando disputa fechada',
  AM: 'Aguardando desempate ME/EPP',
  DM: 'Em desempate ME/EPP',
  A7: 'Aguardando desempate',
  D7: 'Em desempate',
  DF: 'Em disputa final',
  B3: 'Aguardando decisão sobre item de cota',
  JT: 'Aguardando julgamento de técnica',
  E:  'Aguardando julgamento',
  JE: 'Aguardando habilitação',
  HE: 'Aguardando adjudicação',
  PE: 'Aguardando encerramento',
  PR: 'Aguardando reabertura',
  JR: 'Julgamento/Habilitação reaberto',
  AR: 'Aberto para recursos',
  AC: 'Aberto para contrarrazões',
  D1: 'Aguardando decisão de recursos',
  D2: 'Aguardando revisão de decisão',
  AE: 'Apto para homologação',
};

// Rótulo de situação de um item — usar sempre esta função (não SITUACAO_ITEM_TERMINAL/FASE_ITEM_LABEL direto)
function situacaoItemLabel(item) {
  if (item?.homologado) return 'Homologado';
  const sitCod   = String(item?.situacao ?? '');
  const terminal = SITUACAO_ITEM_TERMINAL[sitCod];
  if (terminal) {
    // "Fracassado (aguardando encerramento)" / "Revogado (aguardando encerramento)" etc,
    // quando o item já terminou mas ainda não foi formalmente encerrado no fluxo.
    return item?.fase === 'PE' || item?.fase === 'FE' ? terminal + ' (aguardando encerramento)' : terminal;
  }
  return FASE_ITEM_LABEL[item?.fase] ?? (item?.fase || 'Em andamento');
}

// Agrupamento grosso de fase (usado nos filtros da aba Licitantes e no pré-preenchimento
// das frases-padrão: propostas → em_julgamento, documentos → aguardando_habilitacao)
function itemFaseBucket(item) {
  if (item?.homologado) return 'homologado';
  const fase = item?.fase;
  if (fase === 'JE') return 'aguardando_habilitacao';
  if (['E', 'JT', 'AA', 'LA', 'LF', 'AL', 'AF', 'AM', 'DM', 'A7', 'D7', 'DF', 'B3', 'AP', 'F', 'AS'].includes(fase)) return 'em_julgamento';
  if (fase === 'PE' || fase === 'FE') return 'aguardando_encerramento';
  if (fase === 'HE' || fase === 'AE') return 'aguardando_homologacao';
  if (['AR', 'AC', 'D1', 'D2', 'PR', 'JR'].includes(fase)) return 'recurso';
  if (SITUACAO_ITEM_TERMINAL[String(item?.situacao ?? '')]) return 'encerrado';
  return 'outro';
}
const FASE_BUCKET_LABEL = {
  em_julgamento:            'Em julgamento',
  aguardando_habilitacao:   'Aguardando habilitação',
  aguardando_homologacao:   'Aguardando homologação',
  aguardando_encerramento:  'Aguardando encerramento',
  homologado:               'Homologado',
  recurso:                  'Em recurso',
  encerrado:                'Encerrado (cancelado/revogado/fracassado)',
  outro:                    'Outro',
};

const _rt  = _ext.runtime;

const CNET_URL  = 'https://cnetmobile.estaleiro.serpro.gov.br/comprasnet-area-trabalho-web/seguro/governo/area-trabalho';
const SUPA_URL  = 'https://fychrtyyqbzlfbzbvzqp.supabase.co';
const SUPA_KEY  = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ5Y2hydHl5cWJ6bGZiemJ2enFwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA5Mzk5NzcsImV4cCI6MjA4NjUxNTk3N30.i27qaCYX9qZ6liL9iXaOtYgddWgKyiM5eoobIN1loFw';

// Projeto Supabase pessoal do pregoeiro (dados manuais: tipo de contratação, observações,
// checklist de habilitação) — separado do projeto da equipe acima.
const PREG_SUPA_URL = 'https://lbwbduksczehdhpaslvf.supabase.co';
const PREG_SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxid2JkdWtzY3plaGRocGFzbHZmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1MDExOTUsImV4cCI6MjEwNTA3NzE5NX0.wlMChRJXKylHMjzlZJqjSj_Tt-wev5ZSGeXspnstsHQ';

// ── Config remota + tradução de erros ────────────────────────────────────────

const ERROR_MAP = {
  'HTTP 401': 'Sessão expirada no ComprasNet. Abra comprasnet.gov.br, faça login e clique em Sincronizar.',
  'HTTP 403': 'Acesso negado. Verifique se sua conta tem permissão para esta operação.',
  'HTTP 404': 'Recurso não encontrado no ComprasNet. O processo pode ter sido cancelado ou a URL mudou.',
  'HTTP 500': 'Servidor do ComprasNet com instabilidade. Aguarde alguns minutos e tente novamente.',
  'HTTP 503': 'Servidor do ComprasNet temporariamente indisponível. Tente novamente em alguns minutos.',
  'Script não retornou': 'A extensão precisa ser executada na aba inicial do ComprasNet (Área de Trabalho). Abra o ComprasNet, faça login e tente novamente.',
  'não retornou dados': 'A extensão precisa ser executada na aba inicial do ComprasNet. Recarregue o ComprasNet (F5) e tente novamente.',
  'identificador não encontrado': 'Processo não identificado — a URL do ComprasNet pode ter mudado. Recarregue a extensão.',
  'Nenhum endpoint retornou': 'Não foi possível carregar os itens deste processo. O processo pode estar em formato não suportado.',
};

let _remoteConfig = null;

function translateError(raw, context = '') {
  const remote = (_remoteConfig?.errorMessages) ?? {};
  const merged = { ...ERROR_MAP, ...remote };
  for (const [key, friendly] of Object.entries(merged)) {
    if (raw.includes(key)) return friendly;
  }
  return `Erro inesperado${context ? ' em ' + context : ''}: ${raw}. Se persistir, use o botão 💬 Sugestões para reportar.`;
}

async function loadRemoteConfig() {
  const cached = await _ext.storage.local.get('cnet_remote_config');
  const now = Date.now();
  if (cached.cnet_remote_config?.ts && now - cached.cnet_remote_config.ts < 86400000) {
    _remoteConfig = cached.cnet_remote_config.data;
    return;
  }
  try {
    const r = await fetch(
      SUPA_URL + '/rest/v1/cnet_extensao_config?id=eq.v1&select=config',
      { headers: { apikey: SUPA_KEY } }
    );
    if (r.ok) {
      const rows = await r.json();
      _remoteConfig = rows[0]?.config ?? {};
      await _ext.storage.local.set({ cnet_remote_config: { ts: now, data: _remoteConfig } });
    }
  } catch {}
}

let allItems       = [];
let filtroAtivo    = 'todos';
let buscaProcesso  = '';    // termo de busca livre na lista de processos
let currentTab     = null;  // ComprasNet tab used for scripting
let authToken      = null;  // raw JWT (without "Bearer " prefix)
let detalheId      = null;  // identificador resolved for current detail view
let detalhamentosMap = {};  // { itemNum → descricaoDetalhada } — populated when process detail loads
let detalheProcesso  = null; // processo atual no detalhe (objeto da lista)
let detalheItens     = [];   // itens carregados no detalhe atual
let _detalheWinMap   = {};   // { itemNum → {cnpj, empresa, vlrUnit, vlrTotal} } — populado ao abrir aba Itens/Licitantes
let detalheTabAtiva  = 'itens'; // aba ativa no detalhe: itens | licitantes | habilitacao
let _pregCache = { tipoContratacao: null, itensObs: {}, habilitacao: {}, valorNegociado: {}, comprovacao: {}, etapa: {}, amostra: {} }; // cache do Supabase pessoal para o processo aberto
let itensSort   = { campo: null, dir: 1 };                    // ordenação da tabela de Itens
let itensFiltro = { exeq: new Set(), situacao: new Set() };   // filtros multi-seleção da tabela de Itens (vazio = todos)
let licBusca    = '';                                    // busca na aba Licitantes
let licFiltroBuckets = new Set();                        // filtro de situação na aba Licitantes (vazio = todos)
let _itensCache = {};                                    // { identificacao → string com todas as descrições } — busca por item

// ── Bootstrap ─────────────────────────────────────────────────────────────────

(async () => {
  const isWindow = new URLSearchParams(location.search).has('w');
  if (!isWindow) {
    const win = await _ext.windows.create({
      url: _rt.getURL('popup.html?w=1'),
      type: 'popup', width: 1000, height: 720, focused: true,
    });
    setTimeout(() => {
      if (win?.id != null) _ext.windows.update(win.id, { focused: true });
    }, 150);
    window.close();
    return;
  }

  // Other listeners
  document.getElementById('btn-close').addEventListener('click', () => window.close());

  // Minimizar / restaurar popup (janela separada — requer chrome.windows.update)
  let _minimized = false;
  let _savedHeight = 720;
  const _minBtn     = document.getElementById('btn-min');
  const _minTargets = ['#toolbar','#filtros','#sync-log-wrap','#lista-view','#detalhe-view']
    .map(s => document.querySelector(s)).filter(Boolean);

  _minBtn.addEventListener('click', async () => {
    _minimized = !_minimized;
    _minBtn.textContent = _minimized ? '⊞' : '⊟';
    _minBtn.title       = _minimized ? 'Restaurar' : 'Minimizar';
    _minTargets.forEach(el => el.style.display = _minimized ? 'none' : '');
    document.body.style.minWidth = _minimized ? '400px' : '960px';
    try {
      const win = await chrome.windows.getCurrent();
      if (_minimized) {
        _savedHeight = win.height;
        await chrome.windows.update(win.id, { height: 52 });
      } else {
        await chrome.windows.update(win.id, { height: _savedHeight, width: 1000 });
      }
    } catch {}
  });
  document.getElementById('btn-sync').addEventListener('click', sincronizar);
  document.getElementById('btn-back').addEventListener('click', mostrarLista);

  // Feedback modal
  document.getElementById('btn-feedback').addEventListener('click', () => {
    document.getElementById('fb-status').textContent = '';
    document.getElementById('feedback-modal').classList.add('open');
  });
  document.getElementById('btn-fb-cancel').addEventListener('click', () => {
    document.getElementById('feedback-modal').classList.remove('open');
  });
  document.getElementById('btn-fb-send').addEventListener('click', async () => {
    const msg = document.getElementById('fb-mensagem').value.trim();
    if (!msg) return;
    const sendBtn = document.getElementById('btn-fb-send');
    sendBtn.disabled = true;
    try {
      const r = await fetch(SUPA_URL + '/rest/v1/feedback_extensao', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPA_KEY,
          'Prefer': 'return=minimal',
        },
        body: JSON.stringify({
          mensagem: msg,
          tipo: document.getElementById('fb-tipo').value,
          versao_extensao: _rt.getManifest().version,
          user_agent: navigator.userAgent.slice(0, 200),
        }),
      });
      if (r.ok) {
        document.getElementById('fb-status').textContent = '✅ Enviado! Obrigado pela contribuição.';
        document.getElementById('fb-mensagem').value = '';
        setTimeout(() => document.getElementById('feedback-modal').classList.remove('open'), 2000);
      } else {
        document.getElementById('fb-status').textContent = '❌ Erro ao enviar. Tente novamente.';
      }
    } catch {
      document.getElementById('fb-status').textContent = '❌ Sem conexão.';
    }
    sendBtn.disabled = false;
  });
  document.getElementById('btn-xls').addEventListener('click', exportarProcessoXLS);
  document.getElementById('btn-xls-lista').addEventListener('click', exportarListaXLS);
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(c => c.classList.remove('ativo'));
      chip.classList.add('ativo');
      filtroAtivo = chip.dataset.sit;
      renderTable();
    });
  });
  document.getElementById('busca-processo').addEventListener('input', e => {
    buscaProcesso = e.target.value;
    renderTable();
  });

  // Sub-abas do detalhe (Itens / Licitantes / Habilitação)
  document.querySelectorAll('.dtab').forEach(btn => {
    btn.addEventListener('click', () => mudarAbaDetalhe(btn.dataset.tab));
  });

  // Tipo de contratação (persistido no Supabase pessoal, dispara recálculo de exequibilidade)
  document.getElementById('sel-tipo-contratacao').addEventListener('change', async e => {
    _pregCache.tipoContratacao = e.target.value || null;
    atualizarExequibilidadeUI();
    if (detalheProcesso && _pregCache.tipoContratacao) {
      try {
        await pregUpsert('processos', {
          identificacao: detalheProcesso.identificacao,
          tipo_contratacao: _pregCache.tipoContratacao,
          updated_at: new Date().toISOString(),
        }, 'identificacao');
      } catch {}
    }
  });

  // Observação por item — salva no blur (debounce simples: só grava se o texto mudou)
  document.getElementById('detalhe-body').addEventListener('blur', async e => {
    const ta = e.target;
    if (!ta.classList?.contains('obs-item') || !detalheProcesso) return;
    const num = ta.dataset.obsnum;
    if (_pregCache.itensObs[num] === ta.value) return;
    _pregCache.itensObs[num] = ta.value;
    try {
      await pregUpsert('itens_obs', {
        identificacao: detalheProcesso.identificacao,
        numero_item: Number(num),
        observacao: ta.value,
        updated_at: new Date().toISOString(),
      }, 'identificacao,numero_item');
    } catch {}
  }, true); // capture: 'blur' não borbulha

  // Ordenação e filtros da tabela de Itens (delegado, pois a tabela é recriada a cada render)
  document.getElementById('detalhe-body').addEventListener('click', e => {
    const th = e.target.closest('.th-sort');
    if (th) {
      const campo = th.dataset.sortCampo;
      itensSort = itensSort.campo === campo ? { campo, dir: -itensSort.dir } : { campo, dir: 1 };
      renderItens(detalheItens, null);
      atualizarExequibilidadeUI();
      return;
    }
    const copyBtn = e.target.closest('.btn-copy-mini');
    if (copyBtn) { copiarTexto(copyBtn.dataset.copy, copyBtn); return; }

    const fornToggle = e.target.closest('.ddet-forn-toggle');
    if (fornToggle) {
      const num  = fornToggle.dataset.num;
      const body = document.getElementById('ddet-forn-' + num);
      const abrir = body.hidden;
      body.hidden = !abrir;
      fornToggle.textContent = (abrir ? '▾' : '▸') + ' Fornecedores do item';
      if (abrir) renderFornecedoresDoItem(num, body);
      return;
    }

    // Abre/fecha o menu de filtro multi-seleção do cabeçalho
    const fbtn = e.target.closest('.th-filtro-btn');
    if (fbtn) {
      const menu = document.getElementById('th-filtro-menu-' + fbtn.dataset.filtroTipo);
      const abrir = !menu.classList.contains('open');
      document.querySelectorAll('.th-filtro-menu.open').forEach(m => m.classList.remove('open'));
      if (abrir) menu.classList.add('open');
      return;
    }
    if (!e.target.closest('.th-filtro-menu')) {
      document.querySelectorAll('.th-filtro-menu.open').forEach(m => m.classList.remove('open'));
    }
  });
  document.getElementById('detalhe-body').addEventListener('change', e => {
    const t = e.target;
    if (t.classList.contains('th-filtro-check') || t.classList.contains('th-filtro-todos')) {
      const tipo = t.dataset.filtroTipo;
      const set  = itensFiltro[tipo];
      if (t.classList.contains('th-filtro-todos')) set.clear();
      else t.checked ? set.add(t.value) : set.delete(t.value);
      if (tipo === 'exeq') {
        // sem re-render: só sincroniza o botão/checkboxes e aplica visibilidade
        const menu = document.getElementById('th-filtro-menu-exeq');
        menu.querySelector('.th-filtro-todos').checked = !set.size;
        menu.querySelectorAll('.th-filtro-check').forEach(c => { c.checked = set.has(c.value); });
        const btn = document.querySelector('.th-filtro-btn[data-filtro-tipo="exeq"]');
        btn.textContent = (set.size ? set.size + ' marcado' + (set.size > 1 ? 's' : '') : 'Todos') + ' ▾';
        btn.classList.toggle('ativo', !!set.size);
        aplicarFiltroExequibilidadeVisual();
        atualizarBtnLimparFiltros();
      } else {
        renderItens(detalheItens, null);
        atualizarExequibilidadeUI();
        document.getElementById('th-filtro-menu-situacao')?.classList.add('open');
      }
      return;
    }
    if (t.classList.contains('chk-comprovado')) {
      const num = t.dataset.num;
      const win = _detalheWinMap[num];
      if (!win?.cnpj || !detalheProcesso) {
        t.checked = false;
        setMsg('⚠ Ainda não sei quem é o melhor colocado deste item — aguarde carregar.');
        return;
      }
      _pregCache.comprovacao[num] = { cnpj: win.cnpj, comprovado: t.checked };
      atualizarExequibilidadeUI();
      pregUpsert('itens_exequibilidade_comprovada', {
        identificacao: detalheProcesso.identificacao,
        numero_item: Number(num),
        cnpj: win.cnpj,
        comprovado: t.checked,
        updated_at: new Date().toISOString(),
      }, 'identificacao,numero_item,cnpj').catch(e2 => setMsg('❌ Erro ao salvar comprovação: ' + e2.message));
      return;
    }

    // Etapa operacional do item
    if (t.classList.contains('sel-etapa')) {
      const num = t.dataset.num;
      const win = _detalheWinMap[num];
      if (!win?.cnpj || !detalheProcesso) {
        t.value = '';
        setMsg('⚠ Ainda não sei quem é o melhor colocado deste item — aguarde carregar.');
        return;
      }
      _pregCache.etapa[num] = { cnpj: win.cnpj, etapa: t.value || null };
      // sem re-render: manteria o dropdown aberto. A etapa nova entra nas opções do filtro
      // no próximo render natural da tabela.
      atualizarExequibilidadeUI();
      pregUpsert('itens_etapa', {
        identificacao: detalheProcesso.identificacao,
        numero_item: Number(num),
        cnpj: win.cnpj,
        etapa: t.value || null,
        updated_at: new Date().toISOString(),
      }, 'identificacao,numero_item,cnpj').catch(e2 => setMsg('❌ Erro ao salvar etapa: ' + e2.message));
      return;
    }

    // Amostra: data limite e "recebida"
    if (t.classList.contains('inp-amostra-data') || t.classList.contains('chk-amostra-recebida')) {
      const num = t.dataset.num;
      const win = _detalheWinMap[num];
      if (!win?.cnpj || !detalheProcesso) {
        if (t.type === 'checkbox') t.checked = false; else t.value = '';
        setMsg('⚠ Ainda não sei quem é o melhor colocado deste item — aguarde carregar.');
        return;
      }
      const atual = amostraEfetiva(num, win) || {};
      const dataLimite = t.classList.contains('inp-amostra-data') ? (t.value || null) : (atual.dataLimite ?? null);
      const recebida   = t.classList.contains('chk-amostra-recebida') ? t.checked : !!atual.recebida;
      _pregCache.amostra[num] = { cnpj: win.cnpj, dataLimite, recebida, observacao: atual.observacao ?? null };
      atualizarExequibilidadeUI();
      atualizarAlertas();
      pregUpsert('amostras', {
        identificacao: detalheProcesso.identificacao,
        numero_item: Number(num),
        cnpj: win.cnpj,
        data_limite: dataLimite,
        recebida,
        updated_at: new Date().toISOString(),
      }, 'identificacao,numero_item,cnpj').catch(e2 => setMsg('❌ Erro ao salvar amostra: ' + e2.message));
    }
  });
  document.getElementById('detalhe-body').addEventListener('click', async e => {
    const btn = e.target.closest('.btn-salvar-negociado');
    if (!btn || !detalheProcesso) return;
    const num = btn.dataset.num;
    const inp = document.querySelector('.inp-valor-negociado[data-num="' + num + '"]');
    const valor = parseFloat((inp?.value || '').replace(',', '.'));
    const win = _detalheWinMap[num];
    if (!win?.cnpj) { setMsg('⚠ Ainda não sei quem é o melhor colocado deste item — aguarde carregar ou abra a aba Licitantes primeiro.'); return; }
    if (isNaN(valor)) { setMsg('⚠ Informe um valor numérico válido.'); return; }
    const orig = btn.textContent;
    btn.textContent = '⏳ Salvando…'; btn.disabled = true;
    try {
      await pregUpsert('itens_valor_negociado', {
        identificacao: detalheProcesso.identificacao,
        numero_item: Number(num),
        cnpj: win.cnpj,
        valor,
        updated_at: new Date().toISOString(),
      }, 'identificacao,numero_item,cnpj');
      _pregCache.valorNegociado[num] = { cnpj: win.cnpj, valor };
      atualizarExequibilidadeUI();
      setMsg('✅ Valor negociado salvo pro item ' + num + ' (vale enquanto ' + (win.empresa || win.cnpj) + ' for o melhor colocado).');
    } catch (e2) {
      setMsg('❌ Erro ao salvar valor negociado: ' + e2.message);
    }
    btn.textContent = orig; btn.disabled = false;
  });

  document.getElementById('btn-limpar-filtros').addEventListener('click', () => {
    itensSort   = { campo: null, dir: 1 };
    itensFiltro = { exeq: new Set(), situacao: new Set() };
    renderItens(detalheItens, null);
    atualizarExequibilidadeUI();
  });

  // Modal de frases (aba Licitantes)
  // chip de situação: marca todos os itens daquela situação (ou desmarca, se já estavam todos marcados)
  document.getElementById('frase-modal-filtros').addEventListener('click', e => {
    const chip = e.target.closest('.frase-modal-bucket-chip');
    if (!chip || !_fraseModalState) return;
    const { l, selecionados } = _fraseModalState;
    const doBucket = l.itens.filter(it => it.bucket === chip.dataset.bucket);
    const todosMarcados = doBucket.every(it => selecionados.has(it.num));
    for (const it of doBucket) todosMarcados ? selecionados.delete(it.num) : selecionados.add(it.num);
    renderFraseModal();
  });
  // checkbox individual por item
  document.getElementById('frase-modal-itens-body').addEventListener('change', e => {
    const chk = e.target.closest('.frase-modal-item-check');
    if (!chk || !_fraseModalState) return;
    const num = Number(chk.dataset.num);
    chk.checked ? _fraseModalState.selecionados.add(num) : _fraseModalState.selecionados.delete(num);
    renderFraseModal();
  });
  // clicar na linha inteira também alterna o checkbox
  document.getElementById('frase-modal-itens-body').addEventListener('click', e => {
    if (e.target.closest('input')) return;
    const row = e.target.closest('.frase-modal-item-row');
    if (!row || !_fraseModalState) return;
    const num = Number(row.dataset.num);
    const sel = _fraseModalState.selecionados;
    sel.has(num) ? sel.delete(num) : sel.add(num);
    renderFraseModal();
  });
  // Registra a desclassificação (item + fornecedor + motivo) no histórico do processo
  document.getElementById('frase-modal-extra').addEventListener('click', async e => {
    if (e.target.id !== 'btn-registrar-ocorrencia' || !_fraseModalState || !detalheProcesso) return;
    const { l, selecionados, extra } = _fraseModalState;
    const status = document.getElementById('fm-registro-status');
    if (!selecionados.size) { status.style.color = '#fbbf24'; status.textContent = 'Marque pelo menos um item.'; return; }
    const payload = [...selecionados].map(num => ({
      identificacao: detalheProcesso.identificacao,
      numero_item: num,
      cnpj: l.cnpj,
      tipo: 'desclassificacao',
      motivo: extra.infracao || null,
      documento: extra.documento || null,
      item_documento: extra.itemDoc || null,
    }));
    try {
      await pregUpsert('ocorrencias', payload, 'identificacao,numero_item,cnpj,tipo');
      status.style.color = '#34d399';
      status.textContent = '✅ Registrado em ' + payload.length + ' item(ns).';
    } catch (e2) {
      status.style.color = '#f87171';
      status.textContent = '❌ ' + e2.message;
    }
  });
  document.getElementById('frase-modal-extra').addEventListener('input', e => {
    if (!_fraseModalState) return;
    if (e.target.id === 'fm-infracao')  _fraseModalState.extra.infracao  = e.target.value;
    if (e.target.id === 'fm-documento') _fraseModalState.extra.documento = e.target.value;
    if (e.target.id === 'fm-itemdoc')   _fraseModalState.extra.itemDoc   = e.target.value;
    atualizarFraseModalPreview();
  });
  document.getElementById('btn-frase-fechar-x').addEventListener('click', fecharFraseModal);
  document.getElementById('frase-modal').addEventListener('click', e => {
    if (e.target.id === 'frase-modal') fecharFraseModal(); // clique no fundo escuro fecha
  });
  document.getElementById('btn-frase-copiar-inline').addEventListener('click', () => {
    copiarTexto(document.getElementById('frase-modal-preview-texto').textContent, document.getElementById('btn-frase-copiar-inline'));
  });

  // Mostra versão no subtítulo para confirmar que o zip correto está instalado
  const sub = document.getElementById('header-sub');
  if (sub) sub.textContent = 'UASG 120630 · v' + POPUP_VERSION + ' · Status real via API interna';
  console.log('[GAP-MN/GAP-DF] Popup carregado — versão', POPUP_VERSION);

  // Sino de pendências (amostras) — abre/fecha no clique, fecha ao clicar fora
  document.getElementById('btn-alertas').addEventListener('click', e => {
    e.stopPropagation();
    document.getElementById('alerta-menu').classList.toggle('open');
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('#alerta-wrap')) document.getElementById('alerta-menu')?.classList.remove('open');
  });

  // Atualização da extensão
  document.getElementById('btn-verificar-update').addEventListener('click', () => verificarAtualizacao(true));
  document.getElementById('btn-update-fechar').addEventListener('click', () => {
    document.getElementById('update-banner').classList.remove('open');
  });
  document.getElementById('btn-update-baixar').addEventListener('click', e => {
    const url = e.target.dataset.url;
    if (url) window.open(url, '_blank', 'noopener');
  });
  document.getElementById('btn-update-como').addEventListener('click', () => {
    setMsg('Como atualizar: baixe o .zip, descompacte por cima da pasta da extensão, '
      + 'abra <b>chrome://extensions</b> e clique no ↻ do card "Painel ComprasNet — GAP-MN/GAP-DF".');
  });

  // Rodapé DEV — 5 cliques abrem painel de sugestões
  let _devClicks = 0, _devTimer = null;
  document.getElementById('footer-dev').addEventListener('click', () => {
    _devClicks++;
    clearTimeout(_devTimer);
    _devTimer = setTimeout(() => { _devClicks = 0; }, 2000);
    if (_devClicks >= 5) { _devClicks = 0; abrirDevPanel(); }
  });
  document.getElementById('btn-dev-fechar').addEventListener('click', () => {
    document.getElementById('dev-modal').classList.remove('open');
  });

  // Carrega config remota (cache 24h) para tradução de erros
  await loadRemoteConfig();
  atualizarAlertas();
  verificarAtualizacao();
})();

// ── Painel DEV — leitura de sugestões do Supabase ────────────────────────────

async function abrirDevPanel() {
  document.getElementById('dev-modal').classList.add('open');
  const list = document.getElementById('dev-feedback-list');
  list.innerHTML = '<span style="color:#64748b;font-size:12px">⏳ Buscando sugestões…</span>';
  try {
    const r = await fetch(
      SUPA_URL + '/rest/v1/feedback_extensao?select=*&order=created_at.desc&limit=100',
      { headers: { apikey: SUPA_KEY } }
    );
    if (!r.ok) {
      list.innerHTML = '<span style="color:#f87171;font-size:12px">❌ Erro ' + r.status
        + ' — adicione a policy <code>SELECT TO anon</code> na tabela feedback_extensao no Supabase.</span>';
      return;
    }
    const rows = await r.json();
    if (!rows.length) {
      list.innerHTML = '<span style="color:#64748b;font-size:12px">Nenhuma sugestão ainda.</span>';
      return;
    }
    const tipoCor = { bug: '#f87171', 'sugestão': '#818cf8', elogio: '#34d399', outro: '#94a3b8' };
    list.innerHTML = rows.map(row => {
      const cor  = tipoCor[row.tipo] || '#94a3b8';
      const data = new Date(row.created_at).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
      return '<div style="border:1px solid rgba(148,163,184,0.12);border-radius:8px;padding:10px 12px;margin-bottom:8px">'
        + '<div style="display:flex;gap:8px;align-items:center;margin-bottom:5px">'
        + '<span style="background:rgba(0,0,0,0.3);border:1px solid ' + cor + ';color:' + cor + ';font-size:9px;padding:1px 8px;border-radius:999px;font-weight:700">' + esc(row.tipo || 'outro') + '</span>'
        + '<span style="color:#475569;font-size:10px">v' + esc(row.versao_extensao || '?') + ' · ' + data + '</span>'
        + '</div>'
        + '<div style="color:#e2e8f0;font-size:12px;line-height:1.55;white-space:pre-wrap">' + esc(row.mensagem) + '</div>'
        + '</div>';
    }).join('');
  } catch (e) {
    list.innerHTML = '<span style="color:#f87171;font-size:12px">❌ ' + esc(e.message) + '</span>';
  }
}

// ── cnetFetch — runs in MAIN world of ComprasNet tab ─────────────────────────

function cnetFetch() {
  const BASE = '/comprasnet-area-trabalho';

  function getToken() {
    try {
      const direct = localStorage.getItem('areaTrabalhoGovernoToken');
      if (direct && direct.startsWith('eyJ')) return { source: 'localStorage.areaTrabalhoGovernoToken', token: direct };
    } catch {}

    try {
      if (window.keycloak && window.keycloak.token) return { source: 'window.keycloak', token: window.keycloak.token };
      if (window._keycloak && window._keycloak.token) return { source: 'window._keycloak', token: window._keycloak.token };
      if (window.kcInstance && window.kcInstance.token) return { source: 'window.kcInstance', token: window.kcInstance.token };
    } catch {}

    try {
      for (const key of Object.keys(window)) {
        try {
          const obj = window[key];
          if (obj && typeof obj === 'object' && typeof obj.token === 'string' && obj.token.startsWith('eyJ')) {
            return { source: 'window.' + key + '.token', token: obj.token };
          }
        } catch {}
      }
    } catch {}

    function extractJWT(val) {
      if (typeof val === 'string') {
        if (val.startsWith('eyJ')) return val;
        if (val.startsWith('{') || val.startsWith('[')) {
          try { return extractJWT(JSON.parse(val)); } catch {}
        }
        return null;
      }
      if (Array.isArray(val)) {
        for (const v of val) { const t = extractJWT(v); if (t) return t; }
        return null;
      }
      if (val && typeof val === 'object') {
        for (const prio of ['access_token', 'token', 'jwt', 'bearer', 'id_token', 'accessToken']) {
          if (val[prio]) { const t = extractJWT(val[prio]); if (t) return t; }
        }
        for (const k of Object.keys(val)) { const t = extractJWT(val[k]); if (t) return t; }
      }
      return null;
    }

    for (const store of [sessionStorage, localStorage]) {
      for (let i = 0; i < store.length; i++) {
        const key = store.key(i) || '';
        const raw = store.getItem(key) || '';
        const jwt = extractJWT(raw);
        if (jwt) return { source: (store === localStorage ? 'localStorage' : 'sessionStorage') + '.' + key, token: jwt };
      }
    }

    return null;
  }

  async function get(path, authHeader) {
    const headers = { Accept: 'application/json, text/plain, */*' };
    if (authHeader) headers['Authorization'] = authHeader;
    const r = await fetch(BASE + path, { credentials: 'include', headers });
    if (r.status !== 200 && r.status !== 206) {
      let body = '';
      try { body = await r.text(); } catch {}
      throw new Error('HTTP ' + r.status + (body ? ' | ' + body.slice(0, 120) : ''));
    }
    return r.json();
  }

  async function fetchGroup(id, authHeader) {
    const rows = [];
    for (let pg = 0; ; pg++) {
      const qs = 'size=100&page=' + pg
        + '&somenteFavoritos=false&comPendencia=false'
        + '&sobMinhaResponsabilidade=false&avisosAlice=false'
        + '&etapas=&itensTrabelho=&ultimosDias=0'
        + '&dataInicial=&dataFinal=&filtroUasg=';
      const raw = await get('/v2/agrupamento/' + id + '/itemtrabalho?' + qs, authHeader);
      // API can return either a plain array or a Spring Page object { content: [...] }
      const page = Array.isArray(raw) ? raw : (raw.content || raw.itens || raw.data || []);
      if (!page.length) break;
      rows.push(...page);
      if (page.length < 100) break;
    }
    return rows;
  }

  return (async () => {
    const authInfo = getToken();
    const authHeader = authInfo ? 'Bearer ' + authInfo.token : null;

    const grupos = [
      { id: 2, nome: 'Selecao do Fornecedor' },
      { id: 3, nome: 'Compras Finalizadas' },
      { id: 4, nome: 'Grupo 4' },
      { id: 5, nome: 'Grupo 5' },
      { id: 6, nome: 'Grupo 6' },
    ];

    const items = [];
    const erros = [];

    for (const g of grupos) {
      try {
        const rows = await fetchGroup(g.id, authHeader);
        if (!rows.length) continue;
        for (const it of rows) {
          const m = (it.identificacao || '').match(/(\d+)\/(\d{4})$/);
          items.push({
            id:              it.idItemTrabalho,
            identificacao:   it.identificacao || '',
            numero:          m ? m[1] : '',
            ano:             m ? m[2] : '',
            situacao:        it.situacao || '',
            acao:            it.acao ? (it.acao.nome || '') : '',
            acaoUrl:         it.acao ? (it.acao.url || '') : '',
            possuiPendencia: it.sinalizador ? (it.sinalizador.possuiPendencia || false) : false,
            agrupamento:     g.nome,
          });
        }
      } catch (e) {
        if (!e.message.includes('HTTP 404') && !e.message.includes('HTTP 422')) erros.push(g.nome + ': ' + e.message);
      }
    }

    return {
      ok: true, items, erros,
      authSource: authInfo ? authInfo.source : 'NENHUM',
      authToken:  authInfo ? authInfo.token  : null,
    };
  })();
}

// ── cnetResolveIdentificador — resolve identificador from action URL only

function cnetResolveIdentificador(acaoUrl, rawToken) {
  const BASE_AT = '/comprasnet-area-trabalho';
  const hdrs = { Accept: 'application/json, text/plain, */*' };
  if (rawToken) hdrs['Authorization'] = 'Bearer ' + rawToken;

  return (async () => {
    try {
      const redir = await fetch(BASE_AT + acaoUrl, {
        credentials: 'include', headers: hdrs, redirect: 'follow',
      });

      let identificador = (redir.url.match(/identificador=(\d+)/) || [])[1];

      if (!identificador) {
        try {
          const body = await redir.clone().json();
          identificador = body.identificador || body.idCompra || body.id || null;
          if (identificador) identificador = String(identificador);
          if (!identificador) {
            const s = JSON.stringify(body);
            const m = s.match(/"(?:identificador|idCompra)":\s*"?(\d{15,18})"?/)
                   || s.match(/identificador=(\d{15,18})/);
            if (m) identificador = m[1];
          }
        } catch {}
      }

      if (!identificador) {
        try {
          const txt = await redir.text();
          const m = txt.match(/identificador[=:]["']?(\d{15,18})["']?/)
                 || txt.match(/\/compras\/(\d{15,18})\//)
                 || txt.match(/"(?:id|idCompra|compraId)":\s*"?(\d{15,18})"?/);
          if (m) identificador = m[1];
        } catch {}
      }

      if (!identificador)
        return { ok: false, error: 'identificador não encontrado. URL: ' + redir.url.slice(0, 200) };

      return { ok: true, identificador };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  })();
}

// ── cnetFetchItensPage — fetches ONE page of items (one executeScript per call)

function cnetFetchItensPage(identificador, page, rawToken) {
  const BASE_FE = '/comprasnet-fase-externa';
  const hdrs = { Accept: 'application/json, text/plain, */*' };
  if (rawToken) hdrs['Authorization'] = 'Bearer ' + rawToken;

  return (async () => {
    try {
      const r = await fetch(
        BASE_FE + '/v1/compras/' + identificador
          + '/itens/em-selecao-fornecedores?tamanhoPagina=20&pagina=' + page,
        { credentials: 'include', headers: hdrs }
      );
      if (!r.ok) {
        let body = ''; try { body = await r.text(); } catch {}
        return { ok: false, status: r.status, error: 'HTTP ' + r.status + (body ? ' | ' + body.slice(0, 100) : '') };
      }
      const raw = await r.json();
      const items = Array.isArray(raw) ? raw : (raw.content || raw.itens || []);
      return { ok: true, items };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  })();
}

// ── cnetFetchItensGrupo — busca sub-itens de um grupo/lote ──────────────────────
// Tenta múltiplos endpoints pois a estrutura varia por tipo de processo

function cnetFetchItensGrupo(identificador, loteNum, grupoId, rawToken) {
  const BASE_FE = '/comprasnet-fase-externa';
  const hdrs = { Accept: 'application/json, text/plain, */*' };
  if (rawToken) hdrs['Authorization'] = 'Bearer ' + rawToken;
  const absNum = Math.abs(Number(loteNum));
  // grupoId é o identificador do grupo na API (ex: "G1", "G2")
  const gid = grupoId || ('G' + absNum);

  return (async () => {
    // Endpoint correto descoberto via DevTools:
    // /itens/em-selecao-fornecedores/{numeroGrupo}/itens-grupo
    // onde numeroGrupo é o numero negativo do item de grupo (ex: -1)
    const candidates = [
      BASE_FE + '/v1/compras/' + identificador + '/itens/em-selecao-fornecedores/' + loteNum + '/itens-grupo?tamanhoPagina=100&pagina=0',
      // Fallbacks caso o processo use estrutura diferente
      BASE_FE + '/v1/compras/' + identificador + '/grupos/' + gid + '/itens/em-selecao-fornecedores?tamanhoPagina=100&pagina=0',
      BASE_FE + '/v1/compras/' + identificador + '/grupos/' + gid + '/itens?tamanhoPagina=100&pagina=0',
      BASE_FE + '/v1/compras/' + identificador + '/itens/em-selecao-fornecedores?identificadorGrupo=' + gid + '&tamanhoPagina=100&pagina=0',
      BASE_FE + '/v1/compras/' + identificador + '/itens/em-selecao-fornecedores?tamanhoPagina=100&pagina=0&lote=' + absNum,
      BASE_FE + '/v1/compras/' + identificador + '/lotes/' + absNum + '/itens?tamanhoPagina=100&pagina=0',
    ];
    for (const url of candidates) {
      try {
        const r = await fetch(url, { credentials: 'include', headers: hdrs });
        if (!r.ok) continue;
        const raw = await r.json();
        const items = Array.isArray(raw) ? raw : (raw.content || raw.itens || raw.data || []);
        if (items.length > 0) return { ok: true, items, url };
      } catch {}
    }
    return { ok: false, error: 'Nenhum endpoint retornou sub-itens para grupo ' + gid };
  })();
}

// ── cnetFetchDetalhamento — single item description (lazy, avoids timeout)

function cnetFetchDetalhamento(identificador, numItem, rawToken) {
  const BASE_FE = '/comprasnet-fase-externa';
  const hdrs = { Accept: 'application/json, text/plain, */*' };
  if (rawToken) hdrs['Authorization'] = 'Bearer ' + rawToken;
  return (async () => {
    try {
      const r = await fetch(
        BASE_FE + '/v1/compras/' + identificador + '/itens/' + numItem + '/detalhamento',
        { credentials: 'include', headers: hdrs }
      );
      if (!r.ok) return { ok: false, status: r.status };
      const data = await r.json();
      return { ok: true, data };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  })();
}

// ── cnetFetchItensParticipante — itens ganhos e não ganhos por um fornecedor

function cnetFetchItensParticipante(identificador, cnpj, rawToken) {
  const BASE_FE = '/comprasnet-fase-externa';
  const authHeader = rawToken ? 'Bearer ' + rawToken : null;
  const hdrs = { Accept: 'application/json, text/plain, */*' };
  if (authHeader) hdrs['Authorization'] = authHeader;

  async function fetchAllPages(baseUrl, flag) {
    const PS = 20, all = [];
    for (let pg = 0; pg <= 500; pg++) {
      const r = await fetch(baseUrl + '?tamanhoPagina=' + PS + '&melhorClassificado=' + flag + '&pagina=' + pg, { credentials: 'include', headers: hdrs });
      if (!r.ok) break;
      const raw = await r.json();
      const page = Array.isArray(raw) ? raw : (raw.content || []);
      all.push(...page);
      if (!page.length || page.length < PS) break;
    }
    return all;
  }

  return (async () => {
    try {
      const base = BASE_FE + '/v1/compras/' + identificador
        + '/em-selecao-fornecedores/participantes/' + cnpj + '/itens';
      const [ganhos, naoGanhos] = await Promise.all([
        fetchAllPages(base, 'true'),
        fetchAllPages(base, 'false'),
      ]);
      return { ok: true, ganhos, naoGanhos };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  })();
}

// ── cnetFetchParticipantes — runs in MAIN world, fetches suppliers for one item

// ── cnetFetchPropostasItem — todas as propostas de UM item (roda no MAIN world)
// Endpoint confirmado ao vivo: traz a lista completa de proponentes daquele item, com
// classificação, valores, situação da proposta e o motivo da desclassificação escrito
// pelo pregoeiro. Uma chamada por item, feita só quando a seção é expandida.
function cnetFetchPropostasItem(identificador, numeroItem, rawToken) {
  const BASE_FE = '/comprasnet-fase-externa';
  const hdrs = { Accept: 'application/json, text/plain, */*' };
  if (rawToken) hdrs['Authorization'] = 'Bearer ' + rawToken;
  return (async () => {
    try {
      const r = await fetch(
        BASE_FE + '/v1/compras/' + identificador + '/em-selecao-fornecedores/itens/' + numeroItem
          + '/propostas?filtro=1&ordenacao-propostas=V',
        { credentials: 'include', headers: hdrs }
      );
      if (!r.ok) return { ok: false, status: r.status, error: 'HTTP ' + r.status };
      const raw = await r.json();
      const itemObj = Array.isArray(raw) ? raw[0] : raw;
      return { ok: true, propostas: itemObj?.propostasItem ?? [] };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  })();
}

function cnetFetchParticipantes(identificador, _itemNum, rawToken) {
  const BASE_FE = '/comprasnet-fase-externa';
  const authHeader = rawToken ? 'Bearer ' + rawToken : null;
  const hdrs = { Accept: 'application/json, text/plain, */*' };
  if (authHeader) hdrs['Authorization'] = authHeader;

  return (async () => {
    try {
      const url = BASE_FE + '/v1/compras/' + identificador
        + '/em-selecao-fornecedores/participantes?tamanhoPagina=200&pagina=0';
      const resp = await fetch(url, { credentials: 'include', headers: hdrs });
      if (!resp.ok) {
        let body = ''; try { body = await resp.text(); } catch {}
        return { ok: false, error: 'HTTP ' + resp.status + (body ? ' | ' + body.slice(0, 100) : '') };
      }
      const raw = await resp.json();
      const participantes = Array.isArray(raw) ? raw
        : (raw.content || raw.participantes || []);
      return { ok: true, participantes, _debugParticipante: JSON.stringify(participantes[0] || {}) };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  })();
}

// ── Sincronizar (process list from ComprasNet) ────────────────────────────────

async function sincronizar() {
  const btn = document.getElementById('btn-sync');
  btn.disabled = true;
  setMsg('🔍 Procurando aba do ComprasNet…');

  // Priority 1: authenticated area (contains /seguro/ — avoids redirect/error pages)
  let tabs = await _ext.tabs.query({ url: '*://cnetmobile.estaleiro.serpro.gov.br/*/seguro/*' });
  // Priority 2: any cnetmobile tab
  if (!tabs.length) tabs = await _ext.tabs.query({ url: '*://cnetmobile.estaleiro.serpro.gov.br/*' });
  // Priority 3: any serpro subdomain with comprasnet path
  if (!tabs.length) tabs = await _ext.tabs.query({ url: '*://*.estaleiro.serpro.gov.br/*/seguro/*' });
  // Priority 4: any serpro tab
  if (!tabs.length) tabs = await _ext.tabs.query({ url: '*://*.serpro.gov.br/*' });
  if (!tabs.length) {
    setMsg('⚠ Nenhuma aba do ComprasNet aberta (ou não autenticada). Clique em <b>Abrir ComprasNet</b>, faça login e tente novamente.');
    btn.disabled = false;
    return;
  }

  currentTab = tabs[0];
  setMsg('⏳ Executando busca na aba do ComprasNet… (tab: ' + (currentTab.url || 'sem URL') + ')');

  let result0;
  try {
    [result0] = await _ext.scripting.executeScript({
      target: { tabId: currentTab.id },
      func: cnetFetch,
      world: 'MAIN',
    });
  } catch (e) {
    setMsg('❌ ' + translateError(e.message, 'execução do script') + '<br><small>Tab: ' + (currentTab.url || '(URL oculta)') + '</small>');
    btn.disabled = false;
    return;
  }

  try {
    const result = result0;
    const data = result?.result;
    if (!data) throw new Error('Script não retornou dados — recarregue a extensão.');

    allItems  = data.items || [];
    authToken = data.authToken || null;

    let msg = '';
    if (allItems.length > 0) {
      msg = '✅ ' + allItems.length + ' processo(s) carregados · Clique em uma linha para ver detalhes';
      if (data.erros?.length) msg += ' · <span style="color:#f87171">' + data.erros.map(e => translateError(e)).join(' | ') + '</span>';
    } else {
      const authLine = 'Token: <b>' + (data.authSource || 'NENHUM') + '</b>';
      const erroLine = data.erros?.length
        ? '<br><span style="color:#f87171">' + translateError(data.erros[0]) + '</span>'
        : '';
      msg = '⚠ ' + authLine + erroLine;
    }

    setMsg(msg);

    if (allItems.length) {
      renderTable();
    }
  } catch (e) {
    setMsg('❌ ' + translateError(e.message));
  }
  btn.disabled = false;
}

// ── Supabase pessoal do pregoeiro (tipo de contratação, observações, habilitação) ─

async function pregUpsert(table, payload, onConflict) {
  const qs = onConflict ? '?on_conflict=' + encodeURIComponent(onConflict) : '';
  const r = await fetch(PREG_SUPA_URL + '/rest/v1/' + table + qs, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': PREG_SUPA_KEY,
      'Authorization': 'Bearer ' + PREG_SUPA_KEY,
      'Prefer': 'resolution=merge-duplicates',
    },
    body: JSON.stringify(payload),
  });
  if (!r.ok) {
    const b = await r.text();
    throw new Error(table + ' ' + r.status + ': ' + b.slice(0, 200));
  }
  return r;
}

async function pregGet(table, filtros) {
  const qs = Object.entries(filtros || {}).map(([k, v]) => k + '=eq.' + encodeURIComponent(v)).join('&');
  const r = await fetch(PREG_SUPA_URL + '/rest/v1/' + table + '?select=*' + (qs ? '&' + qs : ''), {
    headers: { 'apikey': PREG_SUPA_KEY, 'Authorization': 'Bearer ' + PREG_SUPA_KEY, 'Accept': 'application/json' },
  });
  if (!r.ok) return [];
  return r.json();
}

// Documentos de habilitação (colunas da aba HABILITAÇÃO da planilha) — coluna do
// Supabase pessoal + rótulo exibido + URL do portal externo onde o documento é retirado.
const HABILITACAO_DOCS = [
  { col: 'doc_contrato_social',    label: 'Contrato Social' },
  { col: 'doc_socio_cpf',          label: 'Sócio Majoritário / CPF' },
  { col: 'doc_sicaf',              label: 'SICAF', url: 'https://www3.comprasnet.gov.br/sicaf-web/public/pages/consultas/consultarFornecedor.jsf' },
  { col: 'doc_cadin',              label: 'CADIN', url: 'https://consultacadin.tesouro.gov.br/' },
  { col: 'doc_consolidada_tcu',    label: 'Consolidada (Emissão TCU)', url: 'https://certidoes-apf.apps.tcu.gov.br/' },
  { col: 'doc_cadicon',            label: 'CADICON Majoritário', url: 'https://contas.tcu.gov.br/certidao/Web/Certidao/NadaConsta/home.faces' },
  // CPF do sócio majoritário fica em branco de propósito: muda a cada licitante
  { col: 'doc_cei',                label: 'CEI Majoritário', url: 'https://portaldatransparencia.gov.br/sancoes/consulta?paginacaoSimples=true&tamanhoPagina=&offset=&direcaoOrdenacao=asc&cpfCnpj=&colunasSelecionadas=linkDetalhamento%2Ccadastro%2CcpfCnpj%2CnomeSancionado%2CufSancionado%2Corgao%2CcategoriaSancao%2CdataPublicacao%2CvalorMulta%2Cquantidade' },
  { col: 'doc_fgts',               label: 'FGTS', url: 'https://consulta-crf.caixa.gov.br/consultacrf/pages/consultaEmpregador.jsf' },
  { col: 'doc_cndt',               label: 'CNDT', url: 'https://cndt-certidao.tst.jus.br/inicio.faces' },
  { col: 'doc_cnj',                label: 'CNJ', url: 'https://www.cnj.jus.br/improbidade_adm/consultar_requerido.php' },
  { col: 'doc_decl_menor',         label: 'Declaração menor de 18 anos' },
  { col: 'doc_falencia',           label: 'Falência' },
  { col: 'doc_balanco',            label: 'Balanço (2 últimos exercícios)' },
  { col: 'doc_liquidez_geral',     label: 'Liquidez Geral' },
  { col: 'doc_solvencia_geral',    label: 'Solvência Geral' },
  { col: 'doc_liquidez_corrente',  label: 'Liquidez Corrente' },
  { col: 'doc_capacidade_tecnica', label: 'Capacidade Técnica' },
  { col: 'doc_sustentabilidade',   label: 'Sustentabilidade Ambiental' },
];

// Fórmula de exequibilidade (porta a coluna EXEQUIBILIDADE da planilha, IFS por INSTRUÇÕES!B3)
function calcExequibilidade(tipo, valorEstimado, valorOfertado) {
  if (valorEstimado == null || valorOfertado == null || !isFinite(valorEstimado) || valorEstimado === 0) return null;
  const razao = Number(valorOfertado) / Number(valorEstimado);
  if (razao > 1) return 'SOBREPREÇO';
  if (tipo === 'OBRA') {
    if (razao < 0.75) return 'INEXEQUÍVEL';
    if (razao < 0.85) return 'GARANTIA ADICIONAL';
    return 'EXEQUÍVEL';
  }
  // SERVICO_MATERIAL (default)
  if (razao < 0.5) return 'INEXEQUÍVEL';
  return 'EXEQUÍVEL';
}

// Frases prontas por licitante — texto base portado da aba LICITANTES da planilha, com o
// número do item sempre explícito (sobrepreço/exequibilidade/desclassificação ganharam essa
// menção, que faltava na planilha original). itensStr vem do modal (Fase 7.4), pode vir vazio
// se a pessoa ainda não marcou nenhum item — nesse caso mostra um placeholder no lugar.
const ITEM_PLACEHOLDER = '(selecione o(s) item(ns) ao lado)';
const FRASES_LICITANTE = {
  negociacao:      (nome, itensStr) => `Sr licitante ${nome}, consulto-o quanto a possibilidade de oferecer preço mais vantajoso nos ITENS ${itensStr || ITEM_PLACEHOLDER}. Caso não responda esta mensagem em até 5 minutos será dado prosseguimento ao certame.`,
  propostas:       (nome, itensStr) => `Sr licitante ${nome}, será aberto prazo de 2 horas para envio de anexos. Solicito que envie a proposta atualizada incluindo o ITEM ${itensStr || ITEM_PLACEHOLDER}, dos quais foi classificado como melhor colocado.`,
  documentos:      (nome, itensStr) => `Sr licitante ${nome}, será aberto prazo de 2 horas para envio de anexos. Solicito que envie os documentos de habilitação conforme previsto em Edital e Termo de Referência.`,
  sobrepreco:      (nome, itensStr) => `Sr licitante ${nome}, tendo em vista que o valor apresentado está acima do estimado para o ITEM ${itensStr || ITEM_PLACEHOLDER}, registro intenção de negociação para que ofereça valor igual ou menor ao estimado. Caso seja desfavorável ou não responda esta mensagem nos próximos 5 minutos, será desclassificado do referido item.`,
  exequibilidade:  (nome, itensStr) => `Sr licitante ${nome}, diante da aparente inexequibilidade da proposta do ITEM ${itensStr || ITEM_PLACEHOLDER}, será aberto prazo de 2 horas para envio de anexos. Solicitamos a apresentação da planilha detalhada de custos, notas fiscais dos últimos 6 meses e contratos comprobatórios (caso haja). O não atendimento deste pedido poderá resultar na desclassificação da proposta.`,
  desclassificacao:(nome, itensStr, extra) => `Sr licitante ${nome}, será desclassificado do ITEM ${itensStr || ITEM_PLACEHOLDER} por ${extra?.infracao || '(INFRAÇÃO COMETIDA)'}, vide ${extra?.itemDoc || 'ITEM X'}${extra?.documento ? ' do ' + extra.documento : ' do edital'} deste certame.`,
};

// ── Detail view ───────────────────────────────────────────────────────────────

async function mostrarDetalhe(it) {
  if (!currentTab || !authToken) {
    setMsg('⚠ Sincronize primeiro.');
    return;
  }

  if (!it.acaoUrl) {
    setMsg('⚠ Processo sem URL de ação — detalhes indisponíveis.');
    return;
  }

  detalheProcesso = it;
  detalheItens    = [];
  _detalheWinMap  = {};
  _pregCache = { tipoContratacao: null, itensObs: {}, habilitacao: {}, valorNegociado: {}, comprovacao: {}, etapa: {}, amostra: {} };
  _winMapPromise = null;
  _winMapFalhas  = {};
  itensSort   = { campo: null, dir: 1 };
  itensFiltro = { exeq: new Set(), situacao: new Set() };
  licBusca    = '';
  licFiltroBuckets = new Set();
  mudarAbaDetalhe('itens');
  ['tab-licitantes', 'tab-habilitacao'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.innerHTML = ''; delete el.dataset.loaded; }
  });

  document.getElementById('lista-view').style.display = 'none';
  const panel = document.getElementById('detalhe-view');
  panel.style.display = 'flex';

  document.getElementById('detalhe-titulo').textContent = it.identificacao;
  document.getElementById('detalhe-sit').innerHTML =
    '<span class="badge ' + classeSit(it.situacao) + '">' + it.situacao + '</span>';
  document.getElementById('detalhe-acao').textContent = it.acao || '';
  document.getElementById('btn-xls').style.display = 'none';
  document.getElementById('detalhe-itens').innerHTML =
    '<div style="color:#64748b;padding:16px 0">⏳ Resolvendo processo…</div>';

  try {
    // Step 1: resolve identificador (one executeScript, fast)
    const [resolveResult] = await _ext.scripting.executeScript({
      target: { tabId: currentTab.id },
      func: cnetResolveIdentificador,
      args: [it.acaoUrl, authToken],
      world: 'MAIN',
    });
    const resolveData = resolveResult?.result;
    if (!resolveData?.ok)
      throw new Error(resolveData?.error || 'Não foi possível resolver o identificador.');

    detalheId = resolveData.identificador;

    // Step 2: fetch items page by page — one executeScript per page (no timeout risk)
    const PAGE_SIZE = 20;
    const allItens  = [];
    let firstDebug  = null;
    let lastStatus  = 'ok';

    let retries = 0;
    for (let pg = 0; pg <= 500; pg++) {
      document.getElementById('detalhe-itens').innerHTML =
        '<div style="color:#64748b;padding:16px 0">⏳ Página ' + pg
        + ' — ' + allItens.length + ' itens carregados…</div>';

      // Delay entre páginas para evitar 429 (rate limit)
      if (pg > 0) await new Promise(r => setTimeout(r, 400));

      const [pageResult] = await _ext.scripting.executeScript({
        target: { tabId: currentTab.id },
        func: cnetFetchItensPage,
        args: [detalheId, pg, authToken],
        world: 'MAIN',
      });
      const pd = pageResult?.result;

      if (!pd) { lastStatus = 'executeScript null pg=' + pg; break; }

      // 429: espera e tenta de novo (máx 3 retries por página)
      if (!pd.ok && pd.status === 429) {
        if (retries >= 3) { lastStatus = '429 persistente pg=' + pg; break; }
        retries++;
        document.getElementById('detalhe-itens').innerHTML =
          '<div style="color:#fbbf24;padding:16px 0">⏳ Rate limit (429) — aguardando ' + (retries * 2) + 's… ' + allItens.length + ' itens</div>';
        await new Promise(r => setTimeout(r, retries * 2000));
        pg--; // retry mesmo pg
        continue;
      }
      retries = 0; // reset ao ter sucesso

      if (!pd.ok) { lastStatus = 'API error pg=' + pg + ': ' + pd.error; break; }
      if (!pd.items) { lastStatus = 'no items prop pg=' + pg; break; }

      if (pg === 0) firstDebug = JSON.stringify(pd.items[0] || {});
      allItens.push(...pd.items);
      if (!pd.items.length || pd.items.length < PAGE_SIZE) { lastStatus = 'last page pg=' + pg + ' count=' + pd.items.length; break; }
    }

    // Show total count + stop reason in header for diagnostics
    document.getElementById('detalhe-acao').textContent =
      (it.acao || '') + '  ·  ' + allItens.length + ' itens  [' + lastStatus + ']';

    // Popula cache de itens para permitir busca por descrição de item na lista
    if (allItens.length && it.identificacao) {
      _itensCache[it.identificacao] = allItens
        .map(i => [i.descricao, i.descricaoDetalhada, i.descricaoItem].filter(Boolean).join(' '))
        .join(' ');
    }

    renderItens(allItens, firstDebug);
    carregarDadosPregoeiroItens(); // fire-and-forget: tipo de contratação, observações e valores ofertados (progressivo)
  } catch (e) {
    document.getElementById('detalhe-itens').innerHTML =
      '<div style="color:#f87171;padding:16px 0">❌ ' + translateError(e.message) + '</div>';
  }
}

function mostrarLista() {
  document.getElementById('detalhe-view').style.display = 'none';
  document.getElementById('lista-view').style.display = 'block';
  detalheId = null;
}

// ── Sub-abas do detalhe (Itens / Licitantes / Habilitação) ───────────────────

function mudarAbaDetalhe(tab) {
  detalheTabAtiva = tab;
  document.querySelectorAll('.dtab').forEach(b => b.classList.toggle('ativo', b.dataset.tab === tab));
  ['itens', 'licitantes', 'habilitacao'].forEach(t => {
    const el = document.getElementById('tab-' + t);
    if (el) el.style.display = (t === tab) ? '' : 'none';
  });
  if (tab === 'licitantes' && !document.getElementById('tab-licitantes').dataset.loaded) renderLicitantesTab();
  if (tab === 'habilitacao' && !document.getElementById('tab-habilitacao').dataset.loaded) renderHabilitacaoTab();
}

// ── Dados do pregoeiro (Supabase pessoal) para a aba Itens ────────────────────

const fmtValBR = v => (v != null && v !== '' && !isNaN(Number(v)))
  ? 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2 })
  : '—';

// Valor ofertado "efetivo" de um item: o valor negociado manual tem prioridade, mas só se
// ainda pertencer ao mesmo CNPJ que hoje é o melhor colocado — se o vencedor mudou, a
// sobreposição antiga simplesmente para de valer e volta a usar o valor da API.
function valorOfertadoEfetivo(num, win) {
  const override = _pregCache.valorNegociado[String(num)];
  if (override && win?.cnpj && override.cnpj === win.cnpj) return { valor: override.valor, manual: true };
  return { valor: win?.vlrUnit ?? null, manual: false };
}

// Mesma regra pra "licitante comprovou a exequibilidade": só vale pro CNPJ da vez.
function comprovacaoEfetiva(num, win) {
  const reg = _pregCache.comprovacao[String(num)];
  return !!(reg && reg.comprovado && win?.cnpj && reg.cnpj === win.cnpj);
}

// Etapa operacional do pregoeiro (sobrepõe visualmente a situação do ComprasNet, sem apagá-la).
// Também presa ao CNPJ da vez: trocou o melhor colocado, a etapa antiga deixa de valer.
const ETAPA_OPCOES = [
  'Proposta solicitada', 'Proposta enviada', 'Em disputa', 'Em julgamento',
  'Amostra solicitada', 'Amostra recebida', 'Proposta aceita',
  'Habilitação solicitada', 'Habilitação enviada', 'Em diligências',
  'Deserto', 'Fracassado',
];

function etapaEfetiva(num, win) {
  const reg = _pregCache.etapa[String(num)];
  return (reg && reg.etapa && win?.cnpj && reg.cnpj === win.cnpj) ? reg.etapa : null;
}

// Amostra: mesma regra de vínculo com o CNPJ da vez.
function amostraEfetiva(num, win) {
  const reg = _pregCache.amostra[String(num)];
  return (reg && win?.cnpj && reg.cnpj === win.cnpj) ? reg : null;
}

// Dias restantes até a data limite (negativo = venceu). Compara só a data, sem hora.
function diasAteAmostra(dataLimite) {
  if (!dataLimite) return null;
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const [a, m, d] = String(dataLimite).slice(0, 10).split('-').map(Number);
  if (!a || !m || !d) return null;
  return Math.round((new Date(a, m - 1, d) - hoje) / 86400000);
}

const EXEQ_LABELS = ['EXEQUÍVEL', 'GARANTIA ADICIONAL', 'INEXEQUÍVEL', 'SOBREPREÇO', 'COMPROVADA'];
const EXEQ_CLASSE = {
  'EXEQUÍVEL': 'sit-homologado', 'COMPROVADA': 'sit-homologado',
  'GARANTIA ADICIONAL': 'sit-andamento',
  'INEXEQUÍVEL': 'sit-cancelado', 'SOBREPREÇO': 'sit-cancelado',
};

// Estado de exequibilidade de um item (label ou null se ainda não dá pra calcular)
function exequibilidadeDoItem(item) {
  const num = item.numeroItem ?? item.numero;
  const win = _detalheWinMap[num];
  if (comprovacaoEfetiva(num, win)) return 'COMPROVADA';
  const { valor: vof } = valorOfertadoEfetivo(num, win);
  if (vof == null || !_pregCache.tipoContratacao) return null;
  const valorEst = item.valorEstimadoUnitario ?? item.valorEstimado ?? null;
  return calcExequibilidade(_pregCache.tipoContratacao, valorEst, vof);
}

function atualizarExequibilidadeUI() {
  for (const item of detalheItens) {
    const num = item.numeroItem ?? item.numero;
    if (num == null) continue;
    const fornCell = document.getElementById('forn-' + num);
    const vofCell  = document.getElementById('vof-' + num);
    const exeqCell = document.getElementById('exeq-' + num);
    if (!vofCell || !exeqCell) continue; // item de grupo (sem essas células) ou não renderizado

    const win = _detalheWinMap[num];
    const cnpjItem = item.identificacaoFornecedorMelhorProposta ? String(item.identificacaoFornecedorMelhorProposta) : null;
    // Estado "vazio": distingue carregando / sem melhor colocado / falha na busca
    let vazio;
    if (_winMapCarregando) vazio = '<span style="color:#475569">…</span>';
    else if (cnpjItem && _winMapFalhas[cnpjItem]) vazio = '<span class="badge sit-cancelado" style="font-size:9px" title="' + esc(_winMapFalhas[cnpjItem]) + '">⚠ falhou</span>';
    else if (!cnpjItem) vazio = '<span style="color:#475569" title="Nenhum fornecedor como melhor colocado ainda">—</span>';
    else vazio = '—';

    if (fornCell) {
      fornCell.innerHTML = win?.cnpj
        ? '<div class="forn-nome">' + esc(win.empresa || '—') + '</div>'
          + '<div class="forn-cnpj">' + esc(fmtCnpj(win.cnpj))
          + ' <button class="btn-copy-mini" data-copy="' + esc(win.cnpj.replace(/\D/g, '')) + '" title="Copiar CNPJ">📋</button></div>'
        : vazio;
    }

    const chk = document.querySelector('.chk-comprovado[data-num="' + num + '"]');
    if (chk) chk.checked = comprovacaoEfetiva(num, win);

    // Etapa operacional (segunda linha da célula Situação) + marcador de amostra vencida
    const etapa = etapaEfetiva(num, win);
    const etapaCell = document.getElementById('etapa-' + num);
    if (etapaCell) {
      const am   = amostraEfetiva(num, win);
      const dias = am && !am.recebida ? diasAteAmostra(am.dataLimite) : null;
      let amostraTag = '';
      if (dias != null) {
        const venceu = dias < 0;
        amostraTag = '<span class="badge ' + (venceu ? 'sit-cancelado' : 'sit-andamento') + ' badge-amostra" title="Amostra — limite '
          + esc(String(am.dataLimite).slice(0, 10).split('-').reverse().join('/')) + '">🧪 '
          + (venceu ? 'venceu há ' + Math.abs(dias) + 'd' : (dias === 0 ? 'vence hoje' : dias + 'd')) + '</span>';
      }
      etapaCell.innerHTML = (etapa ? '<span class="badge-etapa" title="Etapa marcada por você">' + esc(etapa) + '</span>' : '') + amostraTag;
    }

    // Sincroniza os campos de controle do dropdown de detalhes com o estado atual
    const selEtapa = document.querySelector('.sel-etapa[data-num="' + num + '"]');
    if (selEtapa) selEtapa.value = etapa || '';
    const am = amostraEfetiva(num, win);
    const inpData = document.querySelector('.inp-amostra-data[data-num="' + num + '"]');
    if (inpData) inpData.value = am?.dataLimite ? String(am.dataLimite).slice(0, 10) : '';
    const chkAm = document.querySelector('.chk-amostra-recebida[data-num="' + num + '"]');
    if (chkAm) chkAm.checked = !!am?.recebida;

    const { valor: vof, manual } = valorOfertadoEfetivo(num, win);
    if (vof == null) { vofCell.innerHTML = vazio; exeqCell.innerHTML = vazio; continue; }

    const qtdItem  = Number(item.quantidadeSolicitada ?? item.quantidade ?? NaN);
    const totalOf  = manual
      ? (isNaN(qtdItem) ? null : vof * qtdItem)
      : (win?.vlrTotal ?? (isNaN(qtdItem) ? null : vof * qtdItem));
    vofCell.innerHTML = fmtValBR(vof)
      + (manual ? ' <span title="Valor negociado manualmente" style="color:#818cf8;font-size:9px">✏️</span>' : '')
      + (totalOf != null ? ' <span class="val-total" title="Valor total ofertado">· ' + fmtValBR(totalOf) + '</span>' : '');

    if (!_pregCache.tipoContratacao) {
      exeqCell.innerHTML = '<span class="badge sit-outro" style="font-size:9px">defina o tipo ↑</span>';
      continue;
    }
    const res = exequibilidadeDoItem(item);
    if (!res) { exeqCell.innerHTML = '—'; continue; }
    exeqCell.innerHTML = '<span class="badge ' + (EXEQ_CLASSE[res] || 'sit-outro') + '" style="font-size:9px">' + esc(res) + '</span>';
  }
  aplicarFiltroExequibilidadeVisual();
}

// ── Atualização da extensão ───────────────────────────────────────────────────
// Chrome não permite que uma extensão baixe e execute código novo (CSP do Manifest V3),
// e a versão "sem compactação" não consegue sobrescrever os próprios arquivos. Então aqui
// a extensão só compara a versão publicada no Supabase com a instalada e avisa.

function compararVersoes(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

async function verificarAtualizacao(manual = false) {
  const banner = document.getElementById('update-banner');
  const btn = document.getElementById('btn-verificar-update');
  if (manual && btn) { btn.disabled = true; btn.textContent = '⏳ Verificando…'; }

  let row = null;
  try {
    const rows = await pregGet('app_versao', { id: 'atual' });
    row = rows[0] ?? null;
  } catch {}

  if (manual && btn) { btn.disabled = false; btn.textContent = '⬇ Atualizações'; }
  if (!row?.versao) {
    if (manual) setMsg('⚠ Não consegui consultar a versão publicada.');
    return;
  }

  const instalada = _rt.getManifest().version;
  if (compararVersoes(row.versao, instalada) <= 0) {
    banner.classList.remove('open');
    if (manual) setMsg('✅ Você já está na versão mais recente (' + instalada + ').');
    return;
  }

  document.getElementById('update-texto').innerHTML =
    '<b>Nova versão ' + esc(row.versao) + ' disponível</b> <span style="color:#64748b">(você tem a ' + esc(instalada) + ')</span>'
    + (row.changelog ? '<div class="update-changelog">' + esc(row.changelog) + '</div>' : '');

  const btnBaixar = document.getElementById('btn-update-baixar');
  if (row.url_download) {
    btnBaixar.style.display = '';
    btnBaixar.dataset.url = row.url_download;
  } else {
    btnBaixar.style.display = 'none';
  }
  banner.classList.add('open');
}

// ── Alertas (amostras vencendo/vencidas) ──────────────────────────────────────
// Lê direto do Supabase pessoal, de todos os processos — não depende do processo aberto.

async function atualizarAlertas() {
  let rows = [];
  try { rows = await pregGet('amostras', {}); } catch { return; }

  const pendentes = rows
    .filter(r => !r.recebida && r.data_limite)
    .map(r => ({ ...r, dias: diasAteAmostra(r.data_limite) }))
    .filter(r => r.dias != null && r.dias <= 3)     // vence em até 3 dias ou já venceu
    .sort((a, b) => a.dias - b.dias);

  const btn = document.getElementById('btn-alertas');
  const cont = document.getElementById('alerta-contador');
  const menu = document.getElementById('alerta-menu');
  if (!btn || !menu) return;

  btn.classList.toggle('tem-alerta', pendentes.length > 0);
  cont.textContent = pendentes.length || '';
  btn.title = pendentes.length ? pendentes.length + ' amostra(s) com prazo próximo ou vencido' : 'Sem pendências';

  menu.innerHTML = pendentes.length
    ? pendentes.map(r => {
        const cls = r.dias < 0 ? 'vencido' : (r.dias === 0 ? 'hoje' : '');
        const prazo = r.dias < 0 ? 'venceu há ' + Math.abs(r.dias) + ' dia(s)'
                    : (r.dias === 0 ? 'vence hoje' : 'vence em ' + r.dias + ' dia(s)');
        return '<div class="alerta-item ' + cls + '">'
          + '🧪 <b>Item ' + esc(String(r.numero_item)) + '</b> · <span class="a-prazo">' + prazo + '</span>'
          + '<div class="a-proc">' + esc(r.identificacao) + ' · ' + esc(fmtCnpj(r.cnpj)) + '</div>'
          + '</div>';
      }).join('')
    : '<div class="alerta-vazio">Nenhuma pendência de amostra.</div>';
}

// Situação da proposta de cada fornecedor (SituacaoPropostaItemEnum, confirmado no /v1/enums)
const SITUACAO_PROPOSTA = {
  '1': { txt: 'Desclassificada (análise)',   cls: 'sit-cancelado'  },
  '2': { txt: 'Desclassificada (julgamento)', cls: 'sit-cancelado' },
  '9': { txt: 'Desclassificada (disputa)',   cls: 'sit-cancelado'  },
  '7': { txt: 'Pendente aceite de cota',     cls: 'sit-andamento'  },
  '8': { txt: 'Recusou assumir cota',        cls: 'sit-cancelado'  },
  '3': { txt: 'Proposta aceita',             cls: 'sit-homologado' },
  '4': { txt: 'Habilitado',                  cls: 'sit-homologado' },
  '5': { txt: 'Inabilitado',                 cls: 'sit-cancelado'  },
  '6': { txt: 'Adjudicada',                  cls: 'sit-homologado' },
};

// Fornecedores de um item: lista completa vinda do ComprasNet (classificação, valores,
// situação e motivo da desclassificação). Complementa com as ocorrências que você registrou
// aqui, pros casos em que a decisão ainda não foi formalizada no sistema.
async function renderFornecedoresDoItem(num, body) {
  body.innerHTML = '<div style="color:#64748b;font-size:11px;padding:6px 0">⏳ Buscando propostas do item…</div>';

  let propostas = [];
  let erro = null;
  if (detalheId && currentTab && authToken) {
    try {
      const [res] = await _ext.scripting.executeScript({
        target: { tabId: currentTab.id }, world: 'MAIN',
        func: cnetFetchPropostasItem, args: [detalheId, num, authToken],
      });
      const pd = res?.result;
      if (pd?.ok) propostas = pd.propostas || [];
      else erro = pd?.error || 'sem resposta';
    } catch (e) { erro = e.message; }
  } else {
    erro = 'sem sessão do ComprasNet';
  }

  let ocorrencias = [];
  if (detalheProcesso) {
    try {
      ocorrencias = await pregGet('ocorrencias', { identificacao: detalheProcesso.identificacao, numero_item: Number(num) });
    } catch {}
  }
  const ocorrPorCnpj = {};
  for (const o of ocorrencias) ocorrPorCnpj[String(o.cnpj)] = o;

  if (!propostas.length) {
    body.innerHTML = '<div style="color:#64748b;font-size:11px;padding:6px 0">'
      + (erro ? '⚠ Não foi possível carregar as propostas (' + esc(erro) + ')' : 'Nenhuma proposta neste item.')
      + '</div>';
    return;
  }

  let html = '<table class="partic-table"><thead><tr>'
    + '<th>#</th><th>Fornecedor</th><th>UF</th><th>Marca / Modelo</th>'
    + '<th>Proposta inicial</th><th>Lance final</th><th>Situação</th><th>Motivo</th>'
    + '</tr></thead><tbody>';

  for (const p of propostas) {
    const cnpj  = String(p.participante?.identificacao ?? '');
    const nome  = p.participante?.nome ?? '—';
    const uf    = p.participante?.endereco?.uf ?? '—';
    const vIni  = p.valores?.valorPropostaInicial?.valorCalculado?.valorUnitario ?? null;
    const vFim  = p.valores?.valorPropostaInicialOuLances?.valorCalculado?.valorUnitario ?? null;
    const sit   = SITUACAO_PROPOSTA[String(p.situacao ?? '')];
    const local = ocorrPorCnpj[cnpj];
    const motivo = p.motivoDesclassificacao
      || (local ? [local.motivo, local.item_documento, local.documento].filter(Boolean).join(' · ') : '');

    const sitHtml = sit
      ? '<span class="badge ' + sit.cls + '" style="font-size:9px">' + esc(sit.txt) + '</span>'
      : (local ? '<span class="badge sit-cancelado" style="font-size:9px">' + esc(local.tipo === 'inabilitacao' ? 'Inabilitado (anotado)' : 'Desclassificado (anotado)') + '</span>'
               : '<span class="badge sit-outro" style="font-size:9px">Sem decisão</span>');

    html += '<tr' + (p.classificacao === 1 ? ' style="background:rgba(52,211,153,0.07)"' : '') + '>'
      + '<td style="color:#94a3b8;font-weight:600">' + (p.classificacao ?? '—') + '</td>'
      + '<td style="max-width:200px;overflow:hidden;text-overflow:ellipsis" title="' + esc(nome) + '">' + esc(nome)
      + '<div class="forn-cnpj">' + esc(fmtCnpj(cnpj))
      + ' <button class="btn-copy-mini" data-copy="' + esc(cnpj.replace(/\D/g, '')) + '" title="Copiar CNPJ">📋</button>'
      + (p.declaracaoMeEpp ? ' <span class="badge sit-homologado" style="font-size:8px">ME/EPP</span>' : '') + '</div></td>'
      + '<td>' + esc(uf) + '</td>'
      + '<td style="max-width:130px;overflow:hidden;text-overflow:ellipsis" title="' + esc((p.marcaFabricante || '') + ' / ' + (p.modeloVersao || '')) + '">'
      + esc(p.marcaFabricante || '—') + '</td>'
      + '<td style="white-space:nowrap">' + fmtValBR(vIni) + '</td>'
      + '<td style="white-space:nowrap;color:#a5b4fc">' + fmtValBR(vFim) + '</td>'
      + '<td>' + sitHtml + '</td>'
      + '<td style="max-width:220px;font-size:10px;color:#94a3b8">' + esc(motivo || '—') + '</td>'
      + '</tr>';
  }
  html += '</tbody></table>';
  body.innerHTML = html;
}

// Filtro de exequibilidade depende de dado assíncrono (valor ofertado) — em vez de re-renderizar
// a tabela toda, só esconde/mostra as linhas já desenhadas conforme o valor calculado até agora.
function aplicarFiltroExequibilidadeVisual() {
  document.querySelectorAll('#detalhe-itens tr[data-num]').forEach(tr => {
    const num = tr.dataset.num;
    if (!itensFiltro.exeq.size) { tr.style.display = ''; return; }
    const item = detalheItens.find(it => String(it.numeroItem ?? it.numero) === num);
    const res  = item ? exequibilidadeDoItem(item) : null;
    const visivel = res != null && itensFiltro.exeq.has(res);
    tr.style.display = visivel ? '' : 'none';
    const drow = document.getElementById('drow-' + num);
    if (drow && !visivel) drow.style.display = 'none';
  });
}

async function carregarDadosPregoeiroItens() {
  if (!detalheProcesso) return;
  const ident = detalheProcesso.identificacao;

  try {
    const rows = await pregGet('processos', { identificacao: ident });
    _pregCache.tipoContratacao = rows[0]?.tipo_contratacao ?? null;
  } catch { _pregCache.tipoContratacao = null; }
  const sel = document.getElementById('sel-tipo-contratacao');
  if (sel) sel.value = _pregCache.tipoContratacao || '';

  try {
    const obsRows = await pregGet('itens_obs', { identificacao: ident });
    _pregCache.itensObs = {};
    for (const r of obsRows) _pregCache.itensObs[String(r.numero_item)] = r.observacao;
  } catch { _pregCache.itensObs = {}; }
  document.querySelectorAll('.obs-item').forEach(ta => {
    const v = _pregCache.itensObs[ta.dataset.obsnum];
    if (v != null) ta.value = v;
  });

  try {
    const negRows = await pregGet('itens_valor_negociado', { identificacao: ident });
    _pregCache.valorNegociado = {};
    for (const r of negRows) _pregCache.valorNegociado[String(r.numero_item)] = { cnpj: r.cnpj, valor: r.valor };
  } catch { _pregCache.valorNegociado = {}; }
  document.querySelectorAll('.inp-valor-negociado').forEach(inp => {
    const v = _pregCache.valorNegociado[inp.dataset.num]?.valor;
    if (v != null) inp.value = v;
  });

  try {
    const compRows = await pregGet('itens_exequibilidade_comprovada', { identificacao: ident });
    _pregCache.comprovacao = {};
    for (const r of compRows) _pregCache.comprovacao[String(r.numero_item)] = { cnpj: r.cnpj, comprovado: !!r.comprovado };
  } catch { _pregCache.comprovacao = {}; }

  try {
    const etapaRows = await pregGet('itens_etapa', { identificacao: ident });
    _pregCache.etapa = {};
    for (const r of etapaRows) _pregCache.etapa[String(r.numero_item)] = { cnpj: r.cnpj, etapa: r.etapa };
  } catch { _pregCache.etapa = {}; }

  try {
    const amostraRows = await pregGet('amostras', { identificacao: ident });
    _pregCache.amostra = {};
    for (const r of amostraRows) {
      _pregCache.amostra[String(r.numero_item)] = {
        cnpj: r.cnpj, dataLimite: r.data_limite, recebida: !!r.recebida, observacao: r.observacao,
      };
    }
  } catch { _pregCache.amostra = {}; }

  atualizarExequibilidadeUI();

  // Busca participantes/vencedores em background (compartilhado com a aba Licitantes) —
  // atualiza as células de valor ofertado/exequibilidade conforme cada um chega.
  await ensureWinMapLoaded(atualizarExequibilidadeUI);
  atualizarExequibilidadeUI();
}

// ── Render items ──────────────────────────────────────────────────────────────

// Constrói as opções do dropdown de situação a partir dos itens carregados (só os valores
// que aparecem de fato no processo, pra não listar 30 status irrelevantes).
// Botão "Limpar filtros" só aparece quando tem filtro ou ordenação ativa
function atualizarBtnLimparFiltros() {
  const ativo = !!itensSort.campo || itensFiltro.exeq.size > 0 || itensFiltro.situacao.size > 0;
  const btn = document.getElementById('btn-limpar-filtros');
  if (btn) btn.style.display = ativo ? 'inline-block' : 'none';
}

function opcoesSituacaoDisponiveis(itens) {
  const set = new Set(itens.map(situacaoItemLabel));
  // as etapas marcadas por você também entram no filtro, junto das situações do ComprasNet
  for (const it of itens) {
    const n = it.numeroItem ?? it.numero;
    const e = etapaEfetiva(n, _detalheWinMap[n]);
    if (e) set.add(e);
  }
  return [...set].sort((a, b) => a.localeCompare(b, 'pt-BR'));
}

function renderItens(itens, debugItem) {
  detalheItens = itens; // salva para exportação XLS (sempre a lista completa, sem filtro)
  const container = document.getElementById('detalhe-itens');

  if (!itens.length) {
    container.innerHTML = '<div style="color:#64748b;padding:16px 0">Nenhum item encontrado neste processo.</div>';
    return;
  }
  document.getElementById('btn-xls').style.display = 'inline-block';

  let html = '';

  // Debug block — shows raw JSON of first item to identify field names
  if (debugItem) {
    html += '<details style="margin-bottom:12px">'
      + '<summary style="font-size:10px;color:#64748b;cursor:pointer">🔍 Campos brutos (item 1) — para diagnóstico</summary>'
      + '<pre style="font-size:9px;color:#94a3b8;background:#060c1c;padding:8px;border-radius:6px;white-space:pre-wrap;margin-top:6px;max-height:160px;overflow:auto">'
      + esc(debugItem) + '</pre></details>';
  }

  detalhamentosMap = {};  // reset a cada (re)render — repopulado de forma síncrona no loop abaixo

  // Aplica filtro de situação (estático) e ordenação (por valor estimado, já disponível)
  let itensExibir = itens.slice();
  if (itensFiltro.situacao.size) {
    itensExibir = itensExibir.filter(it => {
      const n = it.numeroItem ?? it.numero;
      const e = etapaEfetiva(n, _detalheWinMap[n]);
      return itensFiltro.situacao.has(situacaoItemLabel(it)) || (e && itensFiltro.situacao.has(e));
    });
  }
  if (itensSort.campo === 'numero') {
    itensExibir.sort((a, b) => {
      const na = Number(a.numeroItem ?? a.numero ?? 0), nb = Number(b.numeroItem ?? b.numero ?? 0);
      return (na - nb) * itensSort.dir;
    });
  } else if (itensSort.campo === 'valorEstimado') {
    itensExibir.sort((a, b) => {
      const va = a.valorEstimadoUnitario ?? a.valorEstimado ?? -Infinity;
      const vb = b.valorEstimadoUnitario ?? b.valorEstimado ?? -Infinity;
      return (va - vb) * itensSort.dir;
    });
  } else if (itensSort.campo === 'valorOfertado') {
    itensExibir.sort((a, b) => {
      const na = a.numeroItem ?? a.numero, nb = b.numeroItem ?? b.numero;
      const va = valorOfertadoEfetivo(na, _detalheWinMap[na]).valor ?? -Infinity;
      const vb = valorOfertadoEfetivo(nb, _detalheWinMap[nb]).valor ?? -Infinity;
      return (va - vb) * itensSort.dir;
    });
  } else if (itensSort.campo === 'fornecedor') {
    // Ordena pela quantidade de itens em que o fornecedor é melhor colocado; empate → nome,
    // pra manter os itens do mesmo fornecedor agrupados. Sem fornecedor fica no fim.
    const qtdPorCnpj = {};
    for (const w of Object.values(_detalheWinMap)) if (w.cnpj) qtdPorCnpj[w.cnpj] = (qtdPorCnpj[w.cnpj] || 0) + 1;
    const chave = it => {
      const w = _detalheWinMap[it.numeroItem ?? it.numero];
      return { qtd: w?.cnpj ? qtdPorCnpj[w.cnpj] : -1, nome: w?.empresa || '' };
    };
    itensExibir.sort((a, b) => {
      const ka = chave(a), kb = chave(b);
      if (ka.qtd !== kb.qtd) return (ka.qtd - kb.qtd) * itensSort.dir;
      return ka.nome.localeCompare(kb.nome, 'pt-BR');
    });
  }

  const arrow = campo => itensSort.campo === campo ? (itensSort.dir === 1 ? ' ▲' : ' ▼') : ' ⇅';

  // Dropdown de filtro multi-seleção (checkboxes) no cabeçalho — dá pra combinar status
  // (ex: Fracassado + Revogado). Set vazio = mostra todos.
  const filtroMulti = (tipo, opcoes, sel) => {
    const n = sel.size;
    return '<div class="th-filtro" data-filtro-tipo="' + tipo + '">'
      + '<button class="th-filtro-btn' + (n ? ' ativo' : '') + '" data-filtro-tipo="' + tipo + '">'
      + (n ? n + ' marcado' + (n > 1 ? 's' : '') : 'Todos') + ' ▾</button>'
      + '<div class="th-filtro-menu" id="th-filtro-menu-' + tipo + '">'
      + '<label class="th-filtro-opt"><input type="checkbox" class="th-filtro-todos" data-filtro-tipo="' + tipo + '"' + (n ? '' : ' checked') + '> <i>Todos</i></label>'
      + opcoes.map(v => '<label class="th-filtro-opt"><input type="checkbox" class="th-filtro-check" data-filtro-tipo="' + tipo + '" value="' + esc(v) + '"'
          + (sel.has(v) ? ' checked' : '') + '> ' + esc(v) + '</label>').join('')
      + '</div></div>';
  };

  html += '<table class="itens-table"><thead><tr>'
    + '<th class="th-sort" data-sort-campo="numero" style="cursor:pointer">#' + arrow('numero') + '</th><th>Item</th>'
    + '<th class="th-sort" data-sort-campo="fornecedor" style="cursor:pointer" title="Ordenar pela qtde de itens do fornecedor">Fornecedor' + arrow('fornecedor') + '</th>'
    + '<th>Qtde Sol.</th>'
    + '<th class="th-sort" data-sort-campo="valorEstimado" style="cursor:pointer">Valor Est. Unit.' + arrow('valorEstimado') + '</th>'
    + '<th class="th-sort" data-sort-campo="valorOfertado" style="cursor:pointer">Valor Ofertado' + arrow('valorOfertado') + '</th>'
    + '<th>Exequibilidade' + filtroMulti('exeq', EXEQ_LABELS, itensFiltro.exeq) + '</th>'
    + '<th>Situação' + filtroMulti('situacao', opcoesSituacaoDisponiveis(itens), itensFiltro.situacao) + '</th>'
    + '<th></th>'
    + '</tr></thead><tbody>';

  for (const item of itensExibir) {
    const num  = item.numeroItem ?? item.numero ?? item.numItem ?? item.id ?? '?';
    const desc = item.descricaoDetalhada ?? item.descricao ?? item.descricaoItem ?? item.objeto ?? item.nome ?? '—';
    const qtde = item.quantidadeSolicitada ?? item.quantidade ?? item.qtde ?? item.quantidadeTotal ?? '—';
    const vlr  = item.valorEstimadoUnitario ?? item.valorEstimado ?? item.valorUnitarioEstimado
              ?? item.valorReferencia ?? item.valorUnitario ?? item.preco ?? null;

    const sit = situacaoItemLabel(item);

    // Detecta se é um grupo/lote (numero negativo ou sem valor unitário mas com valor total)
    const isGrupo = (typeof num === 'number' && num < 0)
      || (String(num).startsWith('-'))
      || (vlr == null && (item.valorEstimadoTotal ?? item.valorTotal) != null)
      || String(desc).match(/^grupo\s*\d+$/i);

    detalhamentosMap[num] = desc;

    // Extra fields for expanded detail
    const vlrTotal   = item.valorEstimadoTotal ?? item.valorTotal ?? null;
    const unidade    = item.unidadeFornecimento ?? item.unidadeMedida ?? item.unidade ?? '';
    const criterio   = item.criterioJulgamento ?? item.critJulgamento
                    ?? (item.criterio ? (item.criterio.descricao ?? item.criterio) : '') ?? '';
    const tratamento = item.tratamentoDiferenciado ?? item.descricaoTratamento ?? '';
    const margemPref = item.aplicabilidadeMargemPreferencia ?? item.margemPreferencia ?? '';

    // Prefixo de grupo na célula do número
    const numLabel = isGrupo
      ? '<span style="color:#818cf8;font-size:9px;font-weight:700;display:block">GRUPO</span>' + String(num)
      : num;

    html += '<tr data-num="' + num + '"' + (isGrupo ? ' style="background:rgba(129,140,248,0.06)"' : '') + '>'
      + '<td style="color:#94a3b8;font-weight:600;white-space:nowrap">' + numLabel + '</td>'
      + '<td style="font-size:11px;max-width:420px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + esc(desc) + '">'
      + (isGrupo ? '<span style="color:#818cf8;font-weight:600">📦 ' + desc + '</span>' : desc)
      + '</td>'
      + '<td id="forn-' + num + '" style="font-size:10px;white-space:nowrap">' + (isGrupo ? '—' : '<span style="color:#475569">…</span>') + '</td>'
      + '<td style="color:#94a3b8;font-size:11px;white-space:nowrap">' + (isGrupo ? '—' : qtde) + '</td>'
      + '<td style="font-size:11px;white-space:nowrap">'
      + (isGrupo
        ? (vlrTotal ? '<span style="color:#64748b;font-size:10px">Total: </span>' + fmtValBR(vlrTotal) : '—')
        : fmtValBR(vlr) + (vlrTotal != null ? ' <span class="val-total" title="Valor total estimado">· ' + fmtValBR(vlrTotal) + '</span>' : ''))
      + '</td>'
      + '<td id="vof-' + num + '" style="font-size:11px;white-space:nowrap;color:#a5b4fc">' + (isGrupo ? '—' : '<span style="color:#475569">…</span>') + '</td>'
      + '<td id="exeq-' + num + '">' + (isGrupo ? '—' : '<span class="badge sit-outro" style="font-size:9px">…</span>') + '</td>'
      + '<td><span class="badge ' + classeSit(sit) + '">' + sit + '</span>'
      + (isGrupo ? '' : '<div id="etapa-' + num + '" class="etapa-wrap"></div>') + '</td>'
      + '<td style="white-space:nowrap">'
      + (isGrupo
        ? '<button class="btn-exp btn-grupo-itens" data-lote="' + num + '" data-grupoid="' + esc(item.identificador ?? '') + '" style="margin-right:4px;background:rgba(129,140,248,0.15);border-color:#818cf8;color:#818cf8">▼ Itens do Grupo</button>'
        : '<button class="btn-exp" data-det="' + num + '" style="margin-right:4px">▼ Detalhes</button>'
      )
      + '</td>'
      + '</tr>'
      + '<tr id="drow-' + num + '" style="display:none">'
      + '<td colspan="9"><div id="ddet-' + num + '" style="padding:10px 14px;background:rgba(0,0,0,0.18);border-radius:6px;font-size:11px;color:#94a3b8;line-height:1.7">'
      + (isGrupo
        ? '<div style="color:#818cf8;font-size:11px;padding:4px 0">⏳ Carregando itens do grupo…</div>'
        : // 1) Dados automáticos do ComprasNet
          '<div class="ddet-sec"><div class="ddet-sec-tit">Dados do item</div>'
          + '<div class="ddet-grid">'
          + (unidade    ? '<div><b>Unidade</b><span>' + esc(String(unidade))    + '</span></div>' : '')
          + (criterio   ? '<div><b>Critério</b><span>' + esc(String(criterio))  + '</span></div>' : '')
          + (vlrTotal   ? '<div><b>Valor est. total</b><span>' + fmtValBR(vlrTotal) + '</span></div>' : '')
          + (tratamento ? '<div><b>Tratamento</b><span>' + esc(String(tratamento)) + '</span></div>' : '')
          + (margemPref ? '<div><b>Margem de preferência</b><span>' + esc(String(margemPref)) + '</span></div>' : '')
          + '</div>'
          + '<div id="desc-det-' + num + '" class="ddet-desc">⏳ Carregando descrição detalhada…</div>'
          + '</div>'
          // 2) Controles manuais (todos amarrados ao fornecedor da vez)
          + '<div class="ddet-sec"><div class="ddet-sec-tit">Controles '
          + '<span class="ddet-sec-nota">valem pro fornecedor da vez — resetam se o melhor colocado mudar</span></div>'
          + '<div class="ddet-ctrl-linha">'
          + '<label class="ddet-lbl">Etapa</label>'
          + '<select class="sel-etapa ddet-inp" data-num="' + num + '">'
          + '<option value="">— nenhuma —</option>'
          + ETAPA_OPCOES.map(e => '<option value="' + esc(e) + '">' + esc(e) + '</option>').join('')
          + '</select>'
          + '</div>'
          + '<div class="ddet-ctrl-linha">'
          + '<label class="ddet-lbl">Valor negociado</label>'
          + '<input type="number" step="0.0001" class="inp-valor-negociado ddet-inp" data-num="' + num + '" placeholder="0,00" style="width:110px">'
          + '<button class="btn-exp btn-salvar-negociado" data-num="' + num + '">Salvar</button>'
          + '<label class="ddet-check"><input type="checkbox" class="chk-comprovado" data-num="' + num + '"> comprovou exequibilidade</label>'
          + '</div>'
          + '<div class="ddet-ctrl-linha">'
          + '<label class="ddet-lbl">Amostra até</label>'
          + '<input type="date" class="inp-amostra-data ddet-inp" data-num="' + num + '" style="width:130px">'
          + '<label class="ddet-check"><input type="checkbox" class="chk-amostra-recebida" data-num="' + num + '"> recebida</label>'
          + '</div>'
          + '<div class="ddet-ctrl-linha">'
          + '<label class="ddet-lbl">Observação</label>'
          + '<textarea class="obs-item ddet-inp" data-obsnum="' + num + '" placeholder="Nota pessoal sobre este item…"></textarea>'
          + '</div>'
          + '</div>'
          // 3) Fornecedores do item — retrátil, fechado por padrão
          + '<div class="ddet-sec ddet-sec-forn">'
          + '<button class="ddet-forn-toggle" data-num="' + num + '">▸ Fornecedores do item</button>'
          + '<div class="ddet-forn-body" id="ddet-forn-' + num + '" hidden></div>'
          + '</div>'
      )
      + '</div></td>'
      + '</tr>';
  }

  html += '</tbody></table>';

  // Fornecedores section (process-level, lazy loaded)
  html += '<div style="margin-top:16px">'
    + '<button id="btn-fornecedores-proc" class="btn-exp" style="font-size:12px;padding:7px 16px">'
    + '🏢 Ver todos os fornecedores do processo</button>'
    + '<div id="fornecedores-proc-inner" style="margin-top:10px"></div>'
    + '</div>';

  container.innerHTML = html;
  atualizarBtnLimparFiltros();

  document.getElementById('btn-fornecedores-proc').addEventListener('click', async function() {
    const inner = document.getElementById('fornecedores-proc-inner');
    if (inner.dataset.loaded) {
      inner.style.display = inner.style.display === 'none' ? 'block' : 'none';
      this.textContent = inner.style.display === 'none'
        ? '🏢 Ver todos os fornecedores do processo'
        : '🏢 Ocultar fornecedores';
      return;
    }
    this.textContent = '⏳ Carregando…';
    try {
      const [res] = await _ext.scripting.executeScript({
        target: { tabId: currentTab.id },
        func: cnetFetchParticipantes,
        args: [detalheId, null, authToken],
        world: 'MAIN',
      });
      const pd = res?.result;
      if (!pd?.ok) throw new Error(pd?.error || 'Sem dados');
      renderParticipantes(inner, pd.participantes || []);
      inner.dataset.loaded = '1';

      const isCancelled = /cancel|fracass|desert|revog|anulad/i.test(detalheProcesso?.situacao || '');
      if (!isCancelled && pd.participantes?.length) {
        buildWinMapBackground(pd.participantes); // mapa de vencedores em memória (usado pelo XLS e pela aba Itens/Licitantes)
      }
      this.textContent = '🏢 Ocultar fornecedores';
    } catch (e) {
      inner.innerHTML = '<span style="color:#f87171;font-size:11px">' + translateError(e.message) + '</span>';
      this.textContent = '🏢 Ver todos os fornecedores do processo';
    }
  });

  container.querySelectorAll('[data-det]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const num  = btn.dataset.det;
      const drow = document.getElementById('drow-' + num);
      if (drow.style.display !== 'none') {
        drow.style.display = 'none';
        btn.textContent = '▼ Detalhes';
        return;
      }
      drow.style.display = 'table-row';
      btn.textContent = '▲ Fechar';

      // Lazy-fetch descricaoDetalhada on first open (one request, no timeout)
      const descEl = document.getElementById('desc-det-' + num);
      if (descEl && !descEl.dataset.loaded) {
        descEl.dataset.loaded = '1';
        if (detalheId && currentTab && authToken) {
          try {
            const [res] = await _ext.scripting.executeScript({
              target: { tabId: currentTab.id },
              func: cnetFetchDetalhamento,
              args: [detalheId, num, authToken],
              world: 'MAIN',
            });
            const d = res?.result;
            if (d?.ok && d?.data?.descricaoDetalhada) {
              descEl.innerHTML = '<b style="color:#64748b">Descrição detalhada:</b> ' + esc(d.data.descricaoDetalhada);
              detalhamentosMap[num] = d.data.descricaoDetalhada;
            } else {
              descEl.style.display = 'none';
            }
          } catch {
            descEl.style.display = 'none';
          }
        } else {
          descEl.style.display = 'none';
        }
      }
    });
  });

  container.querySelectorAll('.btn-exp').forEach(btn => {
    btn.addEventListener('click', async () => {
      const num  = btn.dataset.num;
      const prow = document.getElementById('prow-' + num);

      if (prow.style.display !== 'none') {
        prow.style.display = 'none';
        btn.textContent = '+ Fornecedores';
        return;
      }

      prow.style.display = 'table-row';
      btn.textContent = '− Fechar';
      const inner = document.getElementById('pinner-' + num);
      inner.textContent = '⏳ Carregando fornecedores…';

      try {
        const [res] = await _ext.scripting.executeScript({
          target: { tabId: currentTab.id },
          func: cnetFetchParticipantes,
          args: [detalheId, num, authToken],
          world: 'MAIN',
        });
        const pd = res?.result;
        if (!pd?.ok) throw new Error(pd?.error || 'Sem dados');
        renderParticipantes(inner, pd.participantes || [], pd._debugParticipante);
      } catch (e) {
        inner.innerHTML = '<span style="color:#f87171">' + translateError(e.message) + '</span>';
      }
    });
  });

  // Botão "Itens do Grupo" — busca sub-itens de um lote/grupo
  container.querySelectorAll('.btn-grupo-itens').forEach(btn => {
    btn.addEventListener('click', async () => {
      const loteNum = btn.dataset.lote;
      const grupoId = btn.dataset.grupoid || null;
      const drow = document.getElementById('drow-' + loteNum);
      const ddet = document.getElementById('ddet-' + loteNum);

      if (drow.style.display !== 'none') {
        drow.style.display = 'none';
        btn.textContent = '▼ Itens do Grupo';
        return;
      }

      drow.style.display = 'table-row';
      btn.textContent = '▲ Fechar';

      if (ddet.dataset.loaded) return;
      ddet.dataset.loaded = '1';

      if (!detalheId || !currentTab) {
        ddet.innerHTML = '<span style="color:#f87171;font-size:11px">Sem conexão com ComprasNet.</span>';
        return;
      }

      ddet.innerHTML = '<div style="color:#818cf8;font-size:11px">⏳ Buscando itens do grupo…</div>';

      try {
        const [res] = await _ext.scripting.executeScript({
          target: { tabId: currentTab.id },
          func: cnetFetchItensGrupo,
          args: [detalheId, loteNum, grupoId, authToken],
          world: 'MAIN',
        });
        const pd = res?.result;

        if (!pd?.ok || !pd.items?.length) {
          ddet.innerHTML = '<span style="color:#f87171;font-size:11px">'
            + (pd?.error || 'Nenhum sub-item encontrado para este grupo.')
            + '</span><br><span style="color:#64748b;font-size:10px">O processo pode usar estrutura diferente — expanda "Campos brutos" para diagnóstico.</span>';
          return;
        }

        // Adiciona ao detalheItens para exportação XLS (marca grupo pai para propagação de vencedor)
        if (detalheProcesso) {
          for (const si of pd.items) {
            if (!detalheItens.find(i => (i.numeroItem ?? i.numero) === (si.numeroItem ?? si.numero))) {
              detalheItens.push({ ...si, _grupoNum: Number(loteNum) });
            }
          }
        }

        const fmtVal2 = v => (v != null && !isNaN(Number(v)))
          ? 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2 })
          : '—';

        // Prefixo único por grupo para evitar colisão de IDs
        const gpfx = 'g' + String(loteNum).replace(/[^a-z0-9]/gi, '_');

        let h = '<table class="itens-table" style="font-size:10px;margin-top:4px"><thead><tr>'
          + '<th>#</th><th>Descrição</th><th>Qtde</th><th>Val. Est. Unit.</th><th>Val. Est. Total</th><th>Situação</th><th></th>'
          + '</tr></thead><tbody>';

        for (const si of pd.items) {
          const sNum  = si.numeroItem ?? si.numero ?? '?';
          const sDesc = si.descricaoDetalhada ?? si.descricao ?? si.descricaoItem ?? '—';
          const sQtde = si.quantidadeSolicitada ?? si.quantidade ?? '—';
          const sVlrU = si.valorEstimadoUnitario ?? si.valorEstimado ?? null;
          const sVlrT = si.valorEstimadoTotal ?? null;
          const sUnd  = si.unidadeFornecimento ?? si.unidadeMedida ?? si.unidade ?? '';
          const sCrit = si.criterioJulgamento ?? '';
          const sTrat = si.tratamentoDiferenciado ?? '';
          const sSit  = situacaoItemLabel(si);
          detalhamentosMap[sNum] = sDesc;
          const rowId = gpfx + '_' + sNum;
          h += '<tr>'
            + '<td style="color:#94a3b8;font-weight:600">' + sNum + '</td>'
            + '<td style="max-width:300px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + esc(sDesc) + '">' + sDesc + '</td>'
            + '<td style="color:#94a3b8;text-align:center">' + sQtde + '</td>'
            + '<td>' + fmtVal2(sVlrU) + '</td>'
            + '<td>' + fmtVal2(sVlrT) + '</td>'
            + '<td><span class="badge ' + classeSit(sSit) + '">' + sSit + '</span></td>'
            + '<td><button class="btn-exp btn-si-det" data-sinum="' + sNum + '" data-rowid="' + rowId + '" style="font-size:9px;padding:2px 8px">▼ Detalhes</button></td>'
            + '</tr>'
            + '<tr id="sirow-' + rowId + '" style="display:none">'
            + '<td colspan="7"><div id="sidet-' + rowId + '" style="padding:8px 14px;background:rgba(0,0,0,0.22);border-radius:6px;font-size:10px;color:#94a3b8;line-height:1.8">'
            + (sUnd  ? '<div><b style="color:#64748b">Unidade:</b> ' + esc(sUnd)  + '</div>' : '')
            + (sCrit ? '<div><b style="color:#64748b">Critério:</b> ' + esc(String(sCrit)) + '</div>' : '')
            + (sTrat ? '<div><b style="color:#64748b">Tratamento:</b> ' + esc(String(sTrat)) + '</div>' : '')
            + (sVlrT ? '<div><b style="color:#64748b">Val. est. total:</b> ' + fmtVal2(sVlrT) + '</div>' : '')
            + '<div id="sidetd-' + rowId + '" style="color:#64748b;font-size:10px">⏳ Carregando descrição…</div>'
            + '</div></td>'
            + '</tr>';
        }

        h += '</tbody></table>';
        h += '<div style="color:#64748b;font-size:9px;margin-top:4px">Endpoint: ' + esc(pd.url || '') + '</div>';
        ddet.innerHTML = h;

        // Handlers para "▼ Detalhes" de cada sub-item
        ddet.querySelectorAll('.btn-si-det').forEach(sbtn => {
          sbtn.addEventListener('click', async () => {
            const sNum  = sbtn.dataset.sinum;
            const rowId = sbtn.dataset.rowid;
            const srow  = document.getElementById('sirow-' + rowId);
            if (srow.style.display !== 'none') {
              srow.style.display = 'none';
              sbtn.textContent = '▼ Detalhes';
              return;
            }
            srow.style.display = 'table-row';
            sbtn.textContent = '▲ Fechar';

            const detEl = document.getElementById('sidetd-' + rowId);
            if (!detEl || detEl.dataset.loaded) return;
            detEl.dataset.loaded = '1';

            if (!detalheId || !currentTab || !authToken) {
              detEl.style.display = 'none';
              return;
            }
            try {
              const [res] = await _ext.scripting.executeScript({
                target: { tabId: currentTab.id },
                func: cnetFetchDetalhamento,
                args: [detalheId, sNum, authToken],
                world: 'MAIN',
              });
              const d = res?.result;
              if (d?.ok && d?.data?.descricaoDetalhada) {
                detEl.innerHTML = '<b style="color:#64748b">Descrição detalhada:</b> ' + esc(d.data.descricaoDetalhada);
                detalhamentosMap[sNum] = d.data.descricaoDetalhada;
              } else {
                detEl.style.display = 'none';
              }
            } catch {
              detEl.style.display = 'none';
            }
          });
        });
      } catch (e) {
        ddet.innerHTML = '<span style="color:#f87171;font-size:11px">' + translateError(e.message) + '</span>';
      }
    });
  });
}

// ── Render participants ───────────────────────────────────────────────────────

function renderParticipantes(container, participantes, debugParticipante) {
  let html = '';

  if (debugParticipante) {
    html += '<details style="margin-bottom:8px">'
      + '<summary style="font-size:10px;color:#64748b;cursor:pointer">🔍 Campos brutos (participante 1)</summary>'
      + '<pre style="font-size:9px;color:#94a3b8;background:#060c1c;padding:8px;border-radius:6px;white-space:pre-wrap;margin-top:4px;max-height:140px;overflow:auto">'
      + esc(debugParticipante) + '</pre></details>';
  }

  if (!participantes.length) {
    container.innerHTML = html + '<span style="color:#64748b;font-size:11px">Nenhum fornecedor encontrado.</span>';
    return;
  }

  const sorted = [...participantes].sort((a, b) =>
    (b.qtdeTotalItensParaSelecao ?? 0) - (a.qtdeTotalItensParaSelecao ?? 0)
  );

  html += '<table class="partic-table"><thead><tr>'
    + '<th>CNPJ/CPF</th><th>Empresa</th><th>ME/EPP</th>'
    + '<th title="Total de itens em que participou">Itens</th>'
    + '<th title="Itens aguardando julgamento">Julg.</th>'
    + '<th title="Itens aguardando habilitação">Habil.</th>'
    + '<th></th>'
    + '</tr></thead><tbody>';

  for (const p of sorted) {
    const cnpj   = p.identificacaoParticipante ?? '—';
    const empresa = p.nomeParticipante ?? '—';
    const meEpp  = p.declaracaoMeEpp ? '<span class="badge sit-homologado">ME/EPP</span>' : '';
    const total  = p.qtdeTotalItensParaSelecao ?? 0;
    const julg   = p.qtdeItensAguardandoJulgamento ?? 0;
    const habil  = p.qtdeItensAguardandoHabilitacao ?? 0;
    const cnpjId = cnpj.replace(/\D/g, '') || cnpj.replace(/[^a-zA-Z0-9]/g, '_');

    html += '<tr>'
      + '<td style="white-space:nowrap;font-size:10px;color:#64748b">' + cnpj + '</td>'
      + '<td style="max-width:240px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + esc(empresa) + '">' + empresa + '</td>'
      + '<td>' + meEpp + '</td>'
      + '<td style="text-align:center;color:#94a3b8">' + total + '</td>'
      + '<td style="text-align:center;color:' + (julg  > 0 ? '#fbbf24' : '#475569') + '">' + julg  + '</td>'
      + '<td style="text-align:center;color:' + (habil > 0 ? '#818cf8' : '#475569') + '">' + habil + '</td>'
      + '<td style="white-space:nowrap">'
      + '<button class="btn-exp btn-itens-forn" data-cnpj="' + esc(cnpj) + '" data-cnpjid="' + cnpjId + '" data-nome="' + esc(empresa) + '">▼ Itens</button>'
      + '</td>'
      + '</tr>'
      + '<tr id="irow-' + cnpjId + '" style="display:none">'
      + '<td colspan="7" style="padding:0"><div id="iinner-' + cnpjId + '" style="padding:8px 14px"></div></td>'
      + '</tr>';
  }

  html += '</tbody></table>';
  container.innerHTML = html;

  container.querySelectorAll('.btn-itens-forn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const cnpj   = btn.dataset.cnpj;
      const cnpjId = btn.dataset.cnpjid;
      const irow   = document.getElementById('irow-' + cnpjId);
      const inner  = document.getElementById('iinner-' + cnpjId);

      if (irow.style.display !== 'none') {
        irow.style.display = 'none';
        btn.textContent = '▼ Itens';
        return;
      }

      irow.style.display = 'table-row';
      btn.textContent = '▲ Fechar';

      if (inner.dataset.loaded) return;

      inner.textContent = '⏳ Carregando itens…';

      try {
        const [res] = await _ext.scripting.executeScript({
          target: { tabId: currentTab.id },
          func: cnetFetchItensParticipante,
          args: [detalheId, cnpj, authToken],
          world: 'MAIN',
        });
        const pd = res?.result;
        if (!pd?.ok) throw new Error(pd?.error || 'Sem dados');
        renderItensParticipante(inner, pd.ganhos || [], pd.naoGanhos || []);
        inner.dataset.loaded = '1';
      } catch (e) {
        inner.innerHTML = '<span style="color:#f87171;font-size:11px">' + translateError(e.message) + '</span>';
        btn.textContent = '▼ Itens';
        irow.style.display = 'none';
      }
    });
  });
}

// ── Render per-supplier items (ganhos / não ganhos) ───────────────────────────

function renderItensParticipante(container, ganhos, naoGanhos) {
  const fmtVal = v => (v != null && v !== '' && !isNaN(Number(v)))
    ? 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2 })
    : '—';

  function getCalcNegOuProp(item) {
    const vals     = item.propostaItem.valores;
    const calcNeg  = vals.valorNegociado?.valorCalculado;
    const calcProp = vals.valorPropostaInicialOuLances?.valorCalculado;
    return (calcNeg?.valorUnitario ?? calcNeg?.valorTotal) != null ? calcNeg : calcProp;
  }

  function getValorProposto(item) {
    try {
      const calc = getCalcNegOuProp(item);
      return calc?.valorUnitario ?? calc?.valorTotal ?? null;
    } catch { return null; }
  }

  function getValorPropostoTotal(item) {
    try {
      const calc = getCalcNegOuProp(item);
      return calc?.valorTotal ?? null;
    } catch { return null; }
  }

  function fmtEco(vlrEst, vlrProp) {
    if (vlrEst == null || vlrProp == null || isNaN(vlrEst) || isNaN(vlrProp) || vlrEst <= 0) return '—';
    const eco = ((Number(vlrEst) - Number(vlrProp)) / Number(vlrEst)) * 100;
    return (eco >= 0 ? '-' : '+') + Math.abs(eco).toFixed(1) + '%';
  }

  function renderSection(title, items, cor) {
    if (!items.length) {
      return '<div style="color:#475569;font-size:10px;padding:4px 0 8px">' + title + ': nenhum</div>';
    }
    let h = '<div style="margin-bottom:12px">'
      + '<div style="font-size:11px;font-weight:700;color:' + cor + ';margin-bottom:6px">'
      + title + ' (' + items.length + ')</div>'
      + '<table class="partic-table" style="font-size:10px"><thead><tr>'
      + '<th>#</th><th>Item</th><th>Qtde</th>'
      + '<th>Val. Est.</th><th>Val. Proposto</th>'
      + '<th title="Economia em relação ao estimado">Eco.</th><th>Hom.</th>'
      + '</tr></thead><tbody>';

    for (const item of items) {
      const num     = item.numero ?? item.numeroItem ?? '?';
      const isGroup = item.tipo === 'G' || Number(num) < 0;
      const desc    = detalhamentosMap[num] ?? item.descricaoDetalhada ?? item.descricao ?? item.descricaoItem ?? '—';
      const qtde    = isGroup ? '—' : (item.quantidadeSolicitada ?? item.quantidade ?? '—');

      // Grupos: comparar totais; itens normais: comparar unitários
      const vlrEst  = isGroup
        ? (item.valorEstimadoTotal ?? null)
        : (item.valorEstimadoUnitario ?? item.valorEstimadoTotal ?? null);
      const vlrProp = isGroup ? getValorPropostoTotal(item) : getValorProposto(item);
      const eco      = fmtEco(vlrEst, vlrProp);
      const ecoColor = (vlrProp != null && vlrEst != null && Number(vlrProp) < Number(vlrEst))
        ? '#34d399' : '#94a3b8';
      const hom      = item.homologado
        ? '<span class="badge sit-homologado" style="font-size:9px">✓</span>'
        : '<span class="badge sit-outro" style="font-size:9px">—</span>';

      // Label do número: grupos mostram "GRUPO" em roxo
      const numLabel = isGroup
        ? '<span style="color:#818cf8;font-size:8px;font-weight:700;display:block">GRUPO</span>' + num
        : num;
      // Label do valor estimado: "(total)" para grupos
      const vlrEstLabel = isGroup
        ? fmtVal(vlrEst) + '<span style="color:#64748b;font-size:8px"> total</span>'
        : fmtVal(vlrEst);
      const vlrPropLabel = isGroup
        ? fmtVal(vlrProp) + '<span style="color:#64748b;font-size:8px"> total</span>'
        : fmtVal(vlrProp);

      h += '<tr' + (isGroup ? ' style="background:rgba(129,140,248,0.06)"' : '') + '>'
        + '<td style="color:#94a3b8;font-weight:600;white-space:nowrap">' + numLabel + '</td>'
        + '<td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + esc(desc) + '">'
        + (isGroup ? '<span style="color:#818cf8">' + desc + '</span>' : desc) + '</td>'
        + '<td style="text-align:center;color:#94a3b8">' + qtde + '</td>'
        + '<td style="white-space:nowrap">' + vlrEstLabel + '</td>'
        + '<td style="white-space:nowrap;color:#a5b4fc">' + vlrPropLabel + '</td>'
        + '<td style="white-space:nowrap;color:' + ecoColor + '">' + eco + '</td>'
        + '<td>' + hom + '</td>'
        + '</tr>';
    }

    h += '</tbody></table></div>';
    return h;
  }

  container.innerHTML =
    '<div style="padding:4px 0">'
    + renderSection('🥇 Itens ganhos', ganhos, '#34d399')
    + renderSection('Itens não ganhos', naoGanhos, '#94a3b8')
    + '</div>';
}

// ── Tabela (process list) ─────────────────────────────────────────────────────

function classeSit(s) {
  const l = (s || '').toLowerCase();
  // Checa desfecho ruim primeiro (mesmo quando o rótulo diz "... (aguardando encerramento)")
  if (/cancel|fracass|desert|revog|anulad|suspenso/.test(l)) return 'sit-cancelado';
  if (/homolog/.test(l)) return 'sit-homologado';
  if (/julgamento|adjudic|abertura|aguardando|andamento|proposta|sess|analise|recurso|decidindo|disputa/.test(l)) return 'sit-andamento';
  return 'sit-outro';
}

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
}

function fmtCnpj(cnpj) {
  const n = String(cnpj ?? '').replace(/\D/g, '');
  if (n.length !== 14) return cnpj ?? '';
  return n.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
}

// Copia `texto` pro clipboard e dá feedback visual passageiro no botão clicado.
function copiarTexto(texto, btnEl) {
  navigator.clipboard.writeText(texto).then(() => {
    if (!btnEl) return;
    const orig = btnEl.textContent;
    btnEl.textContent = '✅';
    setTimeout(() => { btnEl.textContent = orig; }, 1200);
  }).catch(() => {});
}

function normalizarBusca(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

function filtrar() {
  const termo = normalizarBusca(buscaProcesso.trim());
  return allItems.filter(it => {
    if (termo) {
      const matchProc = normalizarBusca(it.identificacao + ' ' + it.acao).includes(termo);
      const matchItem = _itensCache[it.identificacao]
        ? normalizarBusca(_itensCache[it.identificacao]).includes(termo)
        : false;
      if (!matchProc && !matchItem) return false;
    }
    if (filtroAtivo === 'todos')      return true;
    if (filtroAtivo === 'andamento')  return !/homolog|cancel|fracass|desert|revog|anulad|encerr/i.test(it.situacao);
    if (filtroAtivo === 'homologado') return /homolog/i.test(it.situacao);
    if (filtroAtivo === 'cancelado')  return /cancel|fracass|desert|revog|anulad/i.test(it.situacao);
    if (filtroAtivo === 'pendente')   return it.possuiPendencia;
    return true;
  });
}

function renderTable() {
  const items = filtrar();
  document.getElementById('count').textContent = items.length + ' processo' + (items.length !== 1 ? 's' : '');
  const tbody = document.getElementById('tbody');
  tbody.innerHTML = '';
  if (!items.length) {
    document.getElementById('tabela').style.display = 'none';
    document.getElementById('empty').textContent = allItems.length
      ? 'Nenhum processo corresponde ao filtro.'
      : 'Nenhum dado carregado.';
    document.getElementById('empty').style.display = 'block';
    return;
  }
  document.getElementById('empty').style.display = 'none';
  document.getElementById('tabela').style.display = 'table';
  document.getElementById('btn-xls-lista').style.display = 'inline-block';
  for (const it of items) {
    const tr = document.createElement('tr');
    tr.title = 'Clique para ver itens e fornecedores';
    tr.innerHTML =
      '<td style="font-weight:600;color:#cbd5e1">' + it.identificacao + '</td>' +
      '<td><span class="badge ' + classeSit(it.situacao) + '">' + it.situacao + '</span></td>' +
      '<td style="color:#64748b;font-size:11px">' + it.agrupamento + '</td>' +
      '<td style="color:#94a3b8;font-size:11px;max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + it.acao + '</td>' +
      '<td>' + (it.possuiPendencia ? '<span class="pendencia">⚠</span>' : '') + '</td>';
    tr.addEventListener('click', () => mostrarDetalhe(it));
    tbody.appendChild(tr);
  }
}

// ── Constrói _detalheWinMap em background (sem Supabase) ─────────────────────

// Roda na página (MAIN world): itens em que o participante é o melhor colocado, com retry em 429.
function cnetFetchItensVencidos(compraId, cnpj, nome, rawToken) {
  const BASE = 'https://cnetmobile.estaleiro.serpro.gov.br/comprasnet-fase-externa';
  const hdrs = { 'Authorization': 'Bearer ' + rawToken, 'Accept': 'application/json' };
  return (async () => {
    const out = [];
    let status = 'ok';
    for (let pg = 0; pg <= 500; pg++) {
      let r = null;
      for (let tent = 0; tent < 4; tent++) {
        if (tent > 0) await new Promise(res => setTimeout(res, 1500 * tent));
        try {
          r = await fetch(
            BASE + '/v1/compras/' + compraId + '/em-selecao-fornecedores/participantes/' + cnpj
              + '/itens?tamanhoPagina=20&melhorClassificado=true&pagina=' + pg,
            { credentials: 'include', headers: hdrs }
          );
        } catch (e) { r = null; status = 'ERR:' + (e?.message || '?').slice(0, 40); break; }
        if (r.status !== 429) break;
        status = 'HTTP 429';
      }
      if (!r || !r.ok) { if (r) status = 'HTTP ' + r.status; break; }
      status = 'ok';
      const raw  = await r.json();
      const page = Array.isArray(raw) ? raw : (raw.content || []);
      for (const it of page) {
        const n = it.numero ?? it.numeroItem;
        if (n == null) continue;
        let vlrUnit = null, vlrTotal = null;
        try {
          const vals     = it.propostaItem.valores;
          const calcNeg  = vals.valorNegociado?.valorCalculado;
          const calcProp = vals.valorPropostaInicialOuLances?.valorCalculado;
          const calc     = (calcNeg?.valorUnitario ?? calcNeg?.valorTotal) != null ? calcNeg : calcProp;
          vlrUnit  = calc?.valorUnitario ?? null;
          vlrTotal = calc?.valorTotal    ?? null;
        } catch {}
        out.push({ n, cnpj, empresa: nome, vlrUnit, vlrTotal });
      }
      if (!page.length || page.length < 20) break;
    }
    return { out, status };
  })();
}

let _winMapFalhas = {}; // { cnpj → status } — participantes cuja busca de itens falhou

async function buildWinMapBackground(participantes, onProgress) {
  if (!detalheId || !authToken || !currentTab || !participantes?.length) return;

  // Só busca quem pode realmente ser melhor colocado em algum item: o próprio item já diz
  // o CNPJ (identificacaoFornecedorMelhorProposta); fallback = quem tem itens em seleção.
  // No 90104/2025, isso cortou de 58 pra ~15 chamadas — menos rate-limit, mais rápido.
  const cnpjsNosItens = new Set(
    detalheItens.map(it => it.identificacaoFornecedorMelhorProposta).filter(Boolean).map(String)
  );
  const alvos = participantes.filter(p => {
    const cnpj = String(p.identificacaoParticipante ?? p.cnpj ?? '');
    if (!cnpj) return false;
    if (cnpjsNosItens.size) return cnpjsNosItens.has(cnpj);
    return (p.qtdeTotalItensParaSelecao ?? 1) > 0;
  });
  addLog(`▶ vencedores: ${alvos.length} de ${participantes.length} participantes relevantes`);

  _winMapFalhas = {};
  const buscar = async (p) => {
    const cnpj = String(p.identificacaoParticipante ?? p.cnpj);
    const nome = p.nomeParticipante ?? p.nome ?? '';
    try {
      const [res] = await _ext.scripting.executeScript({
        target: { tabId: currentTab.id }, world: 'MAIN',
        func: cnetFetchItensVencidos,
        args: [detalheId, cnpj, nome, authToken],
      });
      const { out = [], status = 'sem resultado' } = res?.result ?? {};
      for (const it of out) {
        _detalheWinMap[it.n] = { cnpj: it.cnpj, empresa: it.empresa, vlrUnit: it.vlrUnit, vlrTotal: it.vlrTotal };
      }
      if (status !== 'ok') { _winMapFalhas[cnpj] = status; addLog(`⚠ ${cnpj} → ${out.length} itens (${status})`); }
      else delete _winMapFalhas[cnpj];
    } catch (e) {
      _winMapFalhas[cnpj] = 'execErr';
      addLog(`❌ ${cnpj} executeScript: ${e.message}`);
    }
    if (onProgress) onProgress();
  };

  for (const p of alvos) {
    await buscar(p);
    await new Promise(r => setTimeout(r, 400));
  }
  // Segunda passada nos que falharam (normalmente 429), depois de uma pausa maior
  const falhados = alvos.filter(p => _winMapFalhas[String(p.identificacaoParticipante ?? p.cnpj)]);
  if (falhados.length) {
    addLog(`↻ repetindo ${falhados.length} participante(s) que falharam…`);
    await new Promise(r => setTimeout(r, 4000));
    for (const p of falhados) {
      await buscar(p);
      await new Promise(r => setTimeout(r, 800));
    }
  }
}

// Garante que _detalheWinMap foi populado pro processo atual, compartilhando a mesma
// busca entre a aba Itens (que dispara isso automaticamente) e a aba Licitantes
// (que pode ser aberta antes da busca terminar) — evita fetches duplicados.
let _winMapPromise = null;

let _winMapCarregando = false;

function ensureWinMapLoaded(onProgress) {
  if (!currentTab || !authToken || !detalheId) return Promise.resolve();
  if (!_winMapPromise) {
    _winMapCarregando = true;
    _winMapPromise = (async () => {
      try {
        const [res] = await _ext.scripting.executeScript({
          target: { tabId: currentTab.id }, func: cnetFetchParticipantes, args: [detalheId, null, authToken], world: 'MAIN',
        });
        const pd = res?.result;
        if (pd?.ok && pd.participantes?.length) await buildWinMapBackground(pd.participantes, onProgress);
        else addLog(`⚠ participantes: ${pd?.error || 'lista vazia'}`);
      } finally {
        _winMapCarregando = false;
      }
    })();
  }
  return _winMapPromise;
}

// ── Aba Licitantes ────────────────────────────────────────────────────────────

// itens de cada licitante vêm enriquecidos com situação/bucket/descrição/valor ofertado —
// dado 100% derivado do que já está em memória (_detalheWinMap + detalheItens), sem fetch novo.
function agruparLicitantesPorMelhorColocado() {
  const itemByNum = {};
  for (const it of detalheItens) {
    const n = it.numeroItem ?? it.numero;
    if (n != null) itemByNum[String(n)] = it;
  }
  const map = {};
  for (const [numStr, win] of Object.entries(_detalheWinMap)) {
    if (!win.cnpj) continue;
    if (!map[win.cnpj]) map[win.cnpj] = { nome: win.empresa || win.cnpj, cnpj: win.cnpj, itens: [] };
    const raw = itemByNum[numStr];
    const { valor } = valorOfertadoEfetivo(numStr, win);
    map[win.cnpj].itens.push({
      num: Number(numStr),
      situacao: raw ? situacaoItemLabel(raw) : '—',
      bucket: raw ? itemFaseBucket(raw) : 'outro',
      valorOfertado: valor,
      descricao: detalhamentosMap[numStr] ?? detalhamentosMap[Number(numStr)] ?? raw?.descricao ?? '',
    });
  }
  for (const l of Object.values(map)) l.itens.sort((a, b) => a.num - b.num);
  return Object.values(map).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
}

const FRASE_LABELS = [
  ['negociacao',       'Negociação'],
  ['propostas',        'Propostas'],
  ['documentos',       'Documentos'],
  ['sobrepreco',       'Sobrepreço'],
  ['exequibilidade',   'Exequibilid.'],
  ['desclassificacao', 'Desclassif.'],
];
const FRASE_LABELS_MAP = Object.fromEntries(FRASE_LABELS);

// Filtro de item pré-marcado no modal, por tipo de frase (o resto vem desmarcado — a pessoa escolhe)
const FRASE_DEFAULT_BUCKET = {
  propostas:  'em_julgamento',
  documentos: 'aguardando_habilitacao',
};

let _licitantesTodos  = []; // cache da aba Licitantes (evita refazer o fetch a cada busca/filtro)
let _fraseModalState  = null;

async function renderLicitantesTab() {
  const container = document.getElementById('tab-licitantes');
  container.innerHTML = '<div style="color:#64748b;padding:16px 0">⏳ Buscando melhor colocado por item (pode levar alguns segundos)…</div>';
  await ensureWinMapLoaded();
  container.dataset.loaded = '1';

  _licitantesTodos = agruparLicitantesPorMelhorColocado();
  if (!_licitantesTodos.length) {
    container.innerHTML = '<div style="color:#64748b;padding:16px 0">Nenhum licitante identificado como melhor colocado em algum item ainda.</div>';
    return;
  }

  const bucketsPresentes = [...new Set(_licitantesTodos.flatMap(l => l.itens.map(i => i.bucket)))];

  container.innerHTML =
    '<div style="margin-bottom:10px">'
    + '<input id="lic-busca" type="text" placeholder="🔎 Buscar por razão social ou CNPJ…" '
    + 'style="width:100%;max-width:360px;background:rgba(15,23,42,0.6);border:1px solid rgba(148,163,184,0.2);'
    + 'border-radius:8px;padding:6px 12px;color:#e2e8f0;font-size:12px" value="' + esc(licBusca) + '"></div>'
    + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">'
    + bucketsPresentes.map(b => '<span class="chip lic-bucket-chip' + (licFiltroBuckets.has(b) ? ' ativo' : '') + '" data-bucket="' + esc(b) + '">'
        + esc(FASE_BUCKET_LABEL[b] || b) + '</span>').join('')
    + '</div>'
    + '<div id="lic-lista"></div>';

  renderLicitantesLista();

  document.getElementById('lic-busca').addEventListener('input', e => {
    licBusca = e.target.value;
    renderLicitantesLista();
  });
  container.querySelectorAll('.lic-bucket-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const b = chip.dataset.bucket;
      if (licFiltroBuckets.has(b)) licFiltroBuckets.delete(b); else licFiltroBuckets.add(b);
      chip.classList.toggle('ativo');
      renderLicitantesLista();
    });
  });
}

function renderLicitantesLista() {
  const termo       = normalizarBusca(licBusca.trim());
  const termoDigits = licBusca.replace(/\D/g, '');
  const licitantes = _licitantesTodos.filter(l => {
    if (licFiltroBuckets.size && !l.itens.some(it => licFiltroBuckets.has(it.bucket))) return false;
    if (!termo) return true;
    if (termoDigits && l.cnpj.includes(termoDigits)) return true;
    return normalizarBusca(l.nome).includes(termo);
  });

  const listaEl = document.getElementById('lic-lista');
  if (!licitantes.length) {
    listaEl.innerHTML = '<div style="color:#64748b;padding:16px 0">Nenhum licitante encontrado com esse filtro.</div>';
    return;
  }

  let html = '';
  for (const l of licitantes) {
    const itensStr = l.itens.map(i => i.num).join(', ');
    html += '<div class="lic-card"><div class="lic-card-head">'
      + '<span class="lic-nome">' + esc(l.nome) + '</span>'
      + '<span class="lic-cnpj">' + esc(fmtCnpj(l.cnpj)) + ' <button class="btn-copy-mini" data-copy="' + esc(l.cnpj.replace(/\D/g, '')) + '" title="Copiar CNPJ">📋</button></span>'
      + '<span class="lic-itens">Itens: ' + esc(itensStr) + '</span>'
      + '<button class="btn-exp btn-lic-detalhe" data-cnpj="' + esc(l.cnpj) + '" style="margin-left:auto">▼ Ver itens detalhados</button>'
      + '</div>'
      + '<div class="lic-detalhe" id="lic-detalhe-' + esc(l.cnpj) + '" style="display:none"></div>';
    for (const [key, label] of FRASE_LABELS) {
      html += '<div class="frase-row">'
        + '<span class="frase-label">' + label + '</span>'
        + '<span class="frase-texto">' + esc(textoFraseDefault(l, key)) + '</span>'
        + '<button class="btn-copiar btn-abrir-frase" data-cnpj="' + esc(l.cnpj) + '" data-frase="' + key + '">✏️ Montar frase</button>'
        + '</div>';
    }
    html += '</div>';
  }
  listaEl.innerHTML = html;

  listaEl.querySelectorAll('.btn-copy-mini').forEach(btn => btn.addEventListener('click', () => copiarTexto(btn.dataset.copy, btn)));

  listaEl.querySelectorAll('.btn-lic-detalhe').forEach(btn => {
    btn.addEventListener('click', () => {
      const cnpj   = btn.dataset.cnpj;
      const el     = document.getElementById('lic-detalhe-' + cnpj);
      const aberto = el.style.display !== 'none';
      el.style.display  = aberto ? 'none' : 'block';
      btn.textContent   = aberto ? '▼ Ver itens detalhados' : '▲ Ocultar itens';
      if (aberto) return;
      const l = _licitantesTodos.find(x => x.cnpj === cnpj);
      el.innerHTML = '<table class="partic-table" style="margin-top:6px"><thead><tr>'
        + '<th>#</th><th>Descrição</th><th>Valor Ofertado</th><th>Situação</th></tr></thead><tbody>'
        + l.itens.map(it => '<tr><td>' + it.num + '</td><td>' + esc(it.descricao || '—') + '</td><td>'
            + fmtValBR(it.valorOfertado) + '</td><td><span class="badge ' + classeSit(it.situacao)
            + '" style="font-size:9px">' + esc(it.situacao) + '</span></td></tr>').join('')
        + '</tbody></table>';
    });
  });

  listaEl.querySelectorAll('.btn-abrir-frase').forEach(btn => {
    btn.addEventListener('click', () => {
      const l = _licitantesTodos.find(x => x.cnpj === btn.dataset.cnpj);
      abrirFraseModal(l, btn.dataset.frase);
    });
  });
}

// ── Modal de frases ───────────────────────────────────────────────────────────
// Estrutura: título + frase (com copiar sutil e X pra fechar) → chips de situação (marcam em
// lote os itens daquela situação) → tabela dos itens do licitante com checkbox por item.
// Desclassificação usa a mesma estrutura, só ganha os 3 campos de texto extras.

function selecaoDefaultFrase(l, key) {
  const bucket = FRASE_DEFAULT_BUCKET[key];
  return bucket ? l.itens.filter(it => it.bucket === bucket).map(it => it.num) : [];
}

function textoFraseDefault(l, key) {
  const itensStr = selecaoDefaultFrase(l, key).sort((a, b) => a - b).join(', ');
  return FRASES_LICITANTE[key](l.nome, itensStr, {});
}

function abrirFraseModal(l, key) {
  _fraseModalState = {
    l, key,
    selecionados: new Set(selecaoDefaultFrase(l, key)),
    extra: { infracao: '', documento: '', itemDoc: '' },
  };
  document.getElementById('frase-modal-extra').innerHTML = ''; // não herda campos de outro modal
  renderFraseModal();
  document.getElementById('frase-modal').classList.add('open');
}

function fecharFraseModal() {
  document.getElementById('frase-modal').classList.remove('open');
  _fraseModalState = null;
}

function renderFraseModal() {
  const { l, key, selecionados, extra } = _fraseModalState;
  document.getElementById('frase-modal-titulo').textContent = FRASE_LABELS_MAP[key] + ' — ' + l.nome;

  const extraEl = document.getElementById('frase-modal-extra');
  if (key === 'desclassificacao') {
    extraEl.style.display = '';
    // só (re)cria os inputs se ainda não existem, pra não perder o foco enquanto digita
    if (!document.getElementById('fm-infracao')) {
      extraEl.innerHTML =
        '<input type="text" id="fm-infracao" class="field-input" placeholder="Infração cometida" value="' + esc(extra.infracao) + '">'
        + '<input type="text" id="fm-documento" class="field-input" placeholder="Documento descumprido (Edital, TR, etc.)" value="' + esc(extra.documento) + '">'
        + '<input type="text" id="fm-itemdoc" class="field-input" placeholder="Item do documento (ex: item 5.2)" value="' + esc(extra.itemDoc) + '">'
        + '<button id="btn-registrar-ocorrencia" class="btn-exp" style="align-self:flex-start">💾 Registrar desclassificação nos itens marcados</button>'
        + '<span id="fm-registro-status" style="font-size:10px;color:#34d399"></span>';
    }
  } else {
    extraEl.style.display = 'none';
    extraEl.innerHTML = '';
  }

  // Chips de situação: "ativo" quando todos os itens daquela situação estão marcados
  const buckets = [...new Set(l.itens.map(it => it.bucket))];
  document.getElementById('frase-modal-filtros').innerHTML = buckets.map(b => {
    const doBucket = l.itens.filter(it => it.bucket === b);
    const todos = doBucket.every(it => selecionados.has(it.num));
    return '<span class="chip frase-modal-bucket-chip' + (todos ? ' ativo' : '') + '" data-bucket="' + esc(b) + '">'
      + esc(FASE_BUCKET_LABEL[b] || b) + ' <small>(' + doBucket.length + ')</small></span>';
  }).join('');

  document.getElementById('frase-modal-itens-body').innerHTML = l.itens.map(it =>
    '<tr class="frase-modal-item-row' + (selecionados.has(it.num) ? ' marcado' : '') + '" data-num="' + it.num + '">'
    + '<td><input type="checkbox" class="frase-modal-item-check" data-num="' + it.num + '"' + (selecionados.has(it.num) ? ' checked' : '') + '></td>'
    + '<td style="color:#94a3b8;font-weight:600">' + it.num + '</td>'
    + '<td class="frase-modal-desc" title="' + esc(it.descricao) + '">' + esc(it.descricao || '—') + '</td>'
    + '<td><span class="badge ' + classeSit(it.situacao) + '" style="font-size:9px">' + esc(it.situacao) + '</span></td>'
    + '</tr>'
  ).join('');

  atualizarFraseModalPreview();
}

function atualizarFraseModalPreview() {
  const { l, key, selecionados, extra } = _fraseModalState;
  const itensStr = [...selecionados].sort((a, b) => a - b).join(', ');
  document.getElementById('frase-modal-preview-texto').textContent = FRASES_LICITANTE[key](l.nome, itensStr, extra);
}

// ── Aba Habilitação ───────────────────────────────────────────────────────────

async function renderHabilitacaoTab() {
  const container = document.getElementById('tab-habilitacao');
  container.innerHTML = '<div style="color:#64748b;padding:16px 0">⏳ Buscando licitantes vencedores…</div>';
  await ensureWinMapLoaded();
  container.dataset.loaded = '1';

  const licitantes = agruparLicitantesPorMelhorColocado(); // já filtra: só quem tem >=1 item
  if (!licitantes.length) {
    container.innerHTML = '<div style="color:#64748b;padding:16px 0">Nenhum licitante venceu item ainda.</div>';
    return;
  }

  const ident = detalheProcesso.identificacao;
  let rows = [];
  try { rows = await pregGet('habilitacao', { identificacao: ident }); } catch {}
  _pregCache.habilitacao = {};
  for (const r of rows) _pregCache.habilitacao[r.cnpj] = r;

  // Só Prioridade/Habilitado vão pra frente; os documentos ficam depois de Licitante/CNPJ/Itens.
  const colsFrente = [
    { key: 'prioridade', label: 'Prioridade' },
    { key: 'habilitado',  label: 'Habilitado' },
  ];
  const colsDocs = HABILITACAO_DOCS.map(d => ({ key: d.col, label: d.label, url: d.url }));
  const thDoc = c => '<th class="h-doc">' + (c.url
    ? '<a class="doc-header-link" data-url="' + esc(c.url) + '" title="Abrir portal">' + esc(c.label) + ' 🔗</a>'
    : esc(c.label)) + '</th>';
  const tdCheck = (l, reg, c) => '<td class="h-doc-cell">'
    + '<input type="checkbox" class="hab-check" data-cnpj="' + esc(l.cnpj) + '" data-campo="' + c.key + '"'
    + (reg[c.key] ? ' checked' : '') + '></td>';

  let html = '<div id="hab-table-wrap"><table class="hab-table"><thead><tr>'
    + colsFrente.map(thDoc).join('')
    + '<th class="h-plain">Licitante</th><th class="h-plain">CNPJ</th><th class="h-plain h-itens">Itens</th>'
    + colsDocs.map(thDoc).join('')
    + '<th class="h-plain">OBS</th>'
    + '</tr></thead><tbody>';

  for (const l of licitantes) {
    const reg = _pregCache.habilitacao[l.cnpj] || {};
    const itensStr = l.itens.map(i => i.num).join(', ');
    html += '<tr id="hab-row-' + esc(l.cnpj) + '"' + (reg.habilitado ? ' class="hab-row-ok"' : '') + '>'
      + colsFrente.map(c => tdCheck(l, reg, c)).join('')
      + '<td class="h-nome" id="hab-nome-' + esc(l.cnpj) + '"' + (reg.prioridade ? ' style="outline:2px solid #f87171;outline-offset:-2px"' : '') + ' title="' + esc(l.nome) + '">' + esc(l.nome) + '</td>'
      + '<td style="white-space:nowrap">' + esc(fmtCnpj(l.cnpj)) + ' <button class="btn-copy-mini" data-copy="' + esc(l.cnpj.replace(/\D/g, '')) + '" title="Copiar CNPJ (só números)">📋</button></td>'
      + '<td class="h-itens">' + esc(itensStr) + '</td>'
      + colsDocs.map(c => tdCheck(l, reg, c)).join('')
      + '<td><input type="text" class="obs-hab" data-cnpj="' + esc(l.cnpj) + '" value="' + esc(reg.obs || '') + '" placeholder="Observação…"></td>'
      + '</tr>';
  }
  html += '</tbody></table></div>';
  container.innerHTML = html;

  async function salvarCampo(cnpj, campo, valor) {
    try {
      await pregUpsert('habilitacao', {
        identificacao: ident, cnpj, [campo]: valor, updated_at: new Date().toISOString(),
      }, 'identificacao,cnpj');
    } catch {}
  }

  container.querySelectorAll('.hab-check').forEach(chk => {
    chk.addEventListener('change', () => {
      salvarCampo(chk.dataset.cnpj, chk.dataset.campo, chk.checked);
      if (chk.dataset.campo === 'prioridade') {
        const nomeCell = document.getElementById('hab-nome-' + chk.dataset.cnpj);
        if (nomeCell) nomeCell.style.outline = chk.checked ? '2px solid #f87171' : 'none';
      }
      if (chk.dataset.campo === 'habilitado') {
        document.getElementById('hab-row-' + chk.dataset.cnpj)?.classList.toggle('hab-row-ok', chk.checked);
      }
    });
  });
  container.querySelectorAll('.obs-hab').forEach(inp => {
    inp.addEventListener('blur', () => salvarCampo(inp.dataset.cnpj, 'obs', inp.value));
  });
  container.querySelectorAll('.btn-copy-mini').forEach(btn => {
    btn.addEventListener('click', () => copiarTexto(btn.dataset.copy, btn));
  });
  container.querySelectorAll('.doc-header-link').forEach(a => {
    a.addEventListener('click', () => window.open(a.dataset.url, '_blank', 'noopener'));
  });
}

// ── CSV por processo ──────────────────────────────────────────────────────────

async function exportarProcessoXLS() {
  if (!detalheItens.length || !detalheProcesso) return;

  const btnXls = document.getElementById('btn-xls');
  const origLabel = btnXls.textContent;
  btnXls.disabled = true;
  btnXls.textContent = '⏳ Iniciando…';
  console.log('[GAP-MN/GAP-DF Export] INÍCIO — detalheId:', detalheId, '| authToken:', authToken ? 'SET('+authToken.slice(0,20)+'...)' : 'NULL', '| tabId:', currentTab?.id, '| itens:', detalheItens.length);

  function ehGrupo(it) {
    const vlr = it.valorEstimadoUnitario ?? it.valorEstimado ?? null;
    const num  = it.numeroItem ?? it.numero ?? '';
    return (typeof num === 'number' && num < 0)
      || String(num).startsWith('-')
      || (vlr == null && (it.valorEstimadoTotal ?? it.valorTotal) != null)
      || /^grupo\s*\d+$/i.test(String(it.descricaoDetalhada ?? it.descricao ?? ''));
  }

  const standalone = detalheItens.filter(it => !ehGrupo(it));
  const grupoNums  = detalheItens.filter(ehGrupo).map(it => it.numeroItem ?? it.numero).filter(n => n != null);
  const stNums     = standalone.map(it => it.numeroItem ?? it.numero).filter(n => n != null);

  let subItensMap = {}; // { grupoNum → [items] }
  let descMap     = {}; // { itemNum → descricaoDetalhada }
  let winMap      = {}; // { itemNum → { cnpj, empresa } }

  // Relê o token atual da página (Keycloak rotaciona o JWT a cada ~5 min)
  if (currentTab) {
    try {
      const [tRes] = await _ext.scripting.executeScript({
        target: { tabId: currentTab.id }, world: 'MAIN',
        func: () => {
          try { const t = localStorage.getItem('areaTrabalhoGovernoToken'); if (t?.startsWith('eyJ')) return t; } catch {}
          try { if (window.keycloak?.token) return window.keycloak.token; } catch {}
          try { if (window._keycloak?.token) return window._keycloak.token; } catch {}
          try { if (window.kcInstance?.token) return window.kcInstance.token; } catch {}
          return null;
        },
        args: [],
      });
      if (tRes?.result) authToken = tRes.result;
    } catch (e) { console.warn('[GAP-MN/GAP-DF Export] token re-read error:', e?.message); }
  }
  console.log('[GAP-MN/GAP-DF Export] após releitura — authToken:', authToken ? 'SET('+authToken.slice(0,20)+'...)' : 'NULL');

  if (detalheId && authToken && currentTab) {

    // PASSO 1: Expandir grupos (Script 1 — único executeScript, paralelo dentro da página)
    if (grupoNums.length > 0) {
      btnXls.textContent = '⏳ Expandindo grupos…';
      try {
        const [r1] = await _ext.scripting.executeScript({
          target: { tabId: currentTab.id }, world: 'MAIN',
          func: async (compraId, token, grupoNums) => {
            const BASE = 'https://cnetmobile.estaleiro.serpro.gov.br/comprasnet-fase-externa';
            const hdrs = { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' };
            const subMap = {};
            await Promise.all(grupoNums.map(async (loteNum) => {
              const absNum = Math.abs(Number(loteNum));
              const urls = [
                BASE + '/v1/compras/' + compraId + '/itens/em-selecao-fornecedores/' + loteNum + '/itens-grupo?tamanhoPagina=100&pagina=0',
                BASE + '/v1/compras/' + compraId + '/lotes/' + absNum + '/itens?tamanhoPagina=100&pagina=0',
              ];
              for (const url of urls) {
                try {
                  const r = await fetch(url, { credentials: 'include', headers: hdrs });
                  if (!r.ok) continue;
                  const raw = await r.json();
                  const items = Array.isArray(raw) ? raw : (raw.content || raw.itens || raw.data || []);
                  if (items.length > 0) { subMap[loteNum] = items; break; }
                } catch {}
              }
            }));
            return subMap;
          },
          args: [detalheId, authToken, grupoNums],
        });
        subItensMap = r1?.result ?? {};
      } catch (e) { console.warn('[GAP-MN/GAP-DF Export] grupos:', e.message); }
    }

    // PASSO 2: Descrições — 1 executeScript, fetches SEQUENCIAIS dentro da página (evita rate-limit)
    // PASSO 2: Descrições — um executeScript por item (mesmo padrão do botão "▼ Detalhes", 100% confiável)
    const subNums = Object.values(subItensMap).flat().map(it => it.numeroItem ?? it.numero).filter(n => n != null);
    const allNums = [...new Set([...stNums, ...subNums])];
    for (let i = 0; i < allNums.length; i++) {
      const num = allNums[i];
      btnXls.textContent = '⏳ Descrições (' + (i + 1) + '/' + allNums.length + ')…';
      for (let attempt = 0; attempt < 4; attempt++) {
        if (attempt > 0) await new Promise(r => setTimeout(r, 3000 * attempt)); // 3s, 6s, 9s on retry
        try {
          const [res] = await _ext.scripting.executeScript({
            target: { tabId: currentTab.id }, world: 'MAIN',
            func: cnetFetchDetalhamento,
            args: [detalheId, num, authToken],
          });
          const d = res?.result;
          if (d?.ok && d?.data?.descricaoDetalhada) {
            descMap[String(num)] = d.data.descricaoDetalhada;
            detalhamentosMap[String(num)] = d.data.descricaoDetalhada;
            break;
          }
          if (d?.status !== 429) break; // erro que não é rate-limit: não adianta retry
          // 429 → loop continua para próximo attempt
        } catch { break; }
      }
      await new Promise(r => setTimeout(r, 500)); // 500ms entre cada item (evita rate-limit)
    }

    // PASSO 3: Vencedores — relê token antes (pode ter expirado durante as descrições)
    try {
      const [tRes2] = await _ext.scripting.executeScript({
        target: { tabId: currentTab.id }, world: 'MAIN',
        func: () => {
          try { const t = localStorage.getItem('areaTrabalhoGovernoToken'); if (t?.startsWith('eyJ')) return t; } catch {}
          try { if (window.keycloak?.token) return window.keycloak.token; } catch {}
          try { if (window._keycloak?.token) return window._keycloak.token; } catch {}
          return null;
        },
        args: [],
      });
      if (tRes2?.result) authToken = tRes2.result;
    } catch {}
    btnXls.textContent = '⏳ Buscando vencedores…';
    try {
      const [pRes] = await _ext.scripting.executeScript({
        target: { tabId: currentTab.id }, world: 'MAIN',
        func: cnetFetchParticipantes, args: [detalheId, null, authToken],
      });
      const participantes = pRes?.result?.participantes ?? [];
      for (const p of participantes) {
        const cnpj = p.identificacaoParticipante ?? p.cnpj;
        const nome = p.nomeParticipante ?? p.nome ?? '';
        if (!cnpj) continue;
        try {
          const [iRes] = await _ext.scripting.executeScript({
            target: { tabId: currentTab.id }, world: 'MAIN',
            func: async (compraId, cnpj, nome, rawToken) => {
              const BASE = 'https://cnetmobile.estaleiro.serpro.gov.br/comprasnet-fase-externa';
              const hdrs = { 'Authorization': 'Bearer ' + rawToken, 'Accept': 'application/json' };
              const out = {};
              for (let pg = 0; pg <= 500; pg++) {
                try {
                  const r = await fetch(
                    BASE + '/v1/compras/' + compraId + '/em-selecao-fornecedores/participantes/' + cnpj
                      + '/itens?tamanhoPagina=20&melhorClassificado=true&pagina=' + pg,
                    { credentials: 'include', headers: hdrs }
                  );
                  if (!r.ok) break;
                  const raw = await r.json();
                  const page = Array.isArray(raw) ? raw : (raw.content || []);
                  for (const it of page) {
                    const n = it.numero ?? it.numeroItem;
                    if (n == null) continue;
                    let vlrUnit = null, vlrTotal = null;
                    try {
                      const vals     = it.propostaItem.valores;
                      const calcNeg  = vals.valorNegociado?.valorCalculado;
                      const calcProp = vals.valorPropostaInicialOuLances?.valorCalculado;
                      const calc     = (calcNeg?.valorUnitario ?? calcNeg?.valorTotal) != null ? calcNeg : calcProp;
                      vlrUnit  = calc?.valorUnitario ?? null;
                      vlrTotal = calc?.valorTotal    ?? null;
                    } catch {}
                    const qtdIt = it.quantidadeSolicitada ?? it.quantidade ?? null;
                    if (vlrUnit != null && vlrTotal == null && qtdIt != null)
                      vlrTotal = vlrUnit * Number(qtdIt);
                    out[String(n)] = { cnpj, empresa: nome, vlrUnit, vlrTotal };
                  }
                  if (!page.length || page.length < 20) break;
                } catch { break; }
              }
              return out;
            },
            args: [detalheId, cnpj, nome, authToken],
          });
          Object.assign(winMap, iRes?.result ?? {});
        } catch {}
        await new Promise(r => setTimeout(r, 150));
      }
    } catch (e) { console.warn('[GAP-MN/GAP-DF Export] winners:', e.message); }

  }


  // Monta lista de exportação: standalone + sub-itens expandidos
  const subItens = [];
  for (const [loteNum, items] of Object.entries(subItensMap)) {
    for (const si of items) subItens.push({ ...si, _grupoNum: Number(loteNum) });
  }

  let exportBase;
  if (subItens.length > 0) {
    // Sub-itens do Script 1 têm prioridade; exclui de standalone os que já estão em subItens
    const subItemNums = new Set(subItens.map(si => String(si.numeroItem ?? si.numero)));
    const trueStandalone = standalone.filter(it => !subItemNums.has(String(it.numeroItem ?? it.numero)));
    exportBase = [...trueStandalone, ...subItens];
  } else {
    exportBase = standalone.length > 0
      ? standalone
      : detalheItens.filter(it => Number(it.numeroItem ?? it.numero ?? 0) > 0);
  }

  // Ordena por número do item crescente
  exportBase.sort((a, b) =>
    Number(a.numeroItem ?? a.numero ?? 0) - Number(b.numeroItem ?? b.numero ?? 0)
  );

  // ── Gera XLS (SpreadsheetML) ───────────────────────────────────────────────
  const p = detalheProcesso;

  function fmtCnpj(cnpj) {
    const n = String(cnpj ?? '').replace(/\D/g, '');
    if (n.length !== 14) return cnpj ?? '';
    return n.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
  }

  function buildXls(headers, dataRows) {
    const xmlEsc  = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const isNum   = v => v !== '' && v != null && !isNaN(Number(v));
    const makeRow = cells => '<Row>' + cells.map(v => {
      const t = isNum(v) ? 'Number' : 'String';
      return '<Cell><Data ss:Type="' + t + '">' + xmlEsc(v) + '</Data></Cell>';
    }).join('') + '</Row>\n';
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
      + '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" '
      + 'xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n'
      + '<Worksheet ss:Name="Itens"><Table>\n';
    xml += makeRow(headers);
    for (const r of dataRows) xml += makeRow(r);
    xml += '</Table></Worksheet></Workbook>';
    return xml;
  }

  btnXls.textContent = '⏳ Gerando planilha…';
  const headers  = ['LOTE', 'ITEM', 'REQUISIÇÃO', 'CNPJ', 'EMPRESA', 'QTDE', 'UND', 'VALOR UNIT', 'VALOR TOTAL', 'PRAZO', 'DESCRIÇÃO', 'SITUAÇÃO', 'FORNECEDOR', 'MODELO/VERSAO', 'MARCA'];
  const dataRows = [];

  for (const item of exportBase) {
    const num      = item.numeroItem ?? item.numero ?? '';
    const numStr   = String(num);
    const desc     = descMap[numStr] ?? descMap[num] ?? detalhamentosMap[numStr] ?? detalhamentosMap[num] ?? item.descricaoDetalhada ?? item.descricao ?? '';
    const unidade  = item.unidadeFornecimento ?? item.unidadeMedida ?? '';
    const qtde     = item.quantidadeSolicitada ?? item.quantidade ?? '';
    const winner   = winMap[numStr] ?? winMap[num] ?? (item._grupoNum != null ? (winMap[String(item._grupoNum)] ?? winMap[item._grupoNum]) : null) ?? null;
    const cnpj     = fmtCnpj(winner?.cnpj ?? '');
    const empresa  = winner?.empresa ?? '';
    const vlrUnit  = winner?.vlrUnit  ?? item.valorEstimadoUnitario ?? item.valorEstimado ?? '';
    const vlrTotal = winner?.vlrTotal ?? item.valorEstimadoTotal    ?? (vlrUnit !== '' && qtde ? (Number(vlrUnit) * Number(qtde)).toFixed(2) : '');
    const sit      = situacaoItemLabel(item);
    dataRows.push(['', num, '', cnpj, empresa, qtde, unidade, vlrUnit, vlrTotal, 30, desc, sit, empresa, '', '']);
  }

  const xlsContent = buildXls(headers, dataRows);
  const blob = new Blob([xlsContent], { type: 'application/vnd.ms-excel;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = (p.identificacao || 'processo').replace(/[/\\:*?"<>|]/g, '-') + '.xls';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 3000);

  btnXls.disabled    = false;
  btnXls.textContent = origLabel;
}

// ── XLS — Lista de processos ──────────────────────────────────────────────────

function exportarListaXLS() {
  const items = filtrar();
  if (!items.length) return;

  const xmlEsc  = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const isNum   = v => v !== '' && v != null && !isNaN(Number(v));
  const makeRow = cells => '<Row>' + cells.map(v => {
    const t = isNum(v) ? 'Number' : 'String';
    return '<Cell><Data ss:Type="' + t + '">' + xmlEsc(v) + '</Data></Cell>';
  }).join('') + '</Row>\n';

  const headers = ['Identificação', 'Número', 'Ano', 'Situação', 'Grupo', 'Ação Atual', 'Pendência'];
  const rows    = items.map(it => [
    it.identificacao ?? '',
    it.numero        ?? '',
    it.ano           ?? '',
    it.situacao      ?? '',
    it.agrupamento   ?? '',
    it.acao          ?? '',
    it.possuiPendencia ? 'Sim' : 'Não',
  ]);

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    + '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" '
    + 'xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n'
    + '<Worksheet ss:Name="Processos"><Table>\n';
  xml += makeRow(headers);
  for (const r of rows) xml += makeRow(r);
  xml += '</Table></Worksheet></Workbook>';

  const blob = new Blob([xml], { type: 'application/vnd.ms-excel;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'ComprasNet-Processos-' + new Date().toISOString().slice(0, 10) + '.xls';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

// ── CSV ───────────────────────────────────────────────────────────────────────

function exportCSV() {
  const items = filtrar();
  const rows = [['Identificação', 'Número', 'Ano', 'Situação', 'Grupo', 'Ação', 'Pendência']]
    .concat(items.map(it => [it.identificacao, it.numero, it.ano, it.situacao, it.agrupamento, it.acao, it.possuiPendencia ? 'Sim' : 'Não']));
  const csv = rows.map(r => r.map(c => '"' + String(c || '').replace(/"/g, '""') + '"').join(',')).join('\r\n');
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'ComprasNet-GAP-MN-GAP-DF-' + new Date().toISOString().slice(0, 10) + '.csv';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function setMsg(html) { document.getElementById('msg').innerHTML = html; }

// ── Log de diagnóstico ────────────────────────────────────────────────────────
let _logLines = [];
function addLog(line) {
  const ts = new Date().toLocaleTimeString('pt-BR', { hour12: false });
  _logLines.push(ts + ' ' + line);
  const el   = document.getElementById('sync-log');
  const wrap = document.getElementById('sync-log-wrap');
  if (!el || !wrap) return;
  wrap.style.display = '';
  // Renderiza com coloração por prefixo
  el.innerHTML = _logLines.slice(-300).map(l => {
    const c = l.includes('✅') || l.includes('OK') ? 'log-ok'
            : l.includes('❌') || l.includes('ERRO') || l.includes('HTTP 4') || l.includes('HTTP 5') ? 'log-err'
            : l.includes('⚠') || l.includes('WARN') || l.includes('Sem ') ? 'log-warn'
            : '';
    return c ? '<span class="' + c + '">' + l.replace(/</g, '&lt;') + '</span>' : l.replace(/</g, '&lt;');
  }).join('\n');
  el.scrollTop = el.scrollHeight;
}

document.getElementById('btn-log-copy')?.addEventListener('click', () => {
  navigator.clipboard.writeText(_logLines.join('\n')).then(() => setMsg('📋 Log copiado!')).catch(() => {});
});
document.getElementById('btn-log-clear')?.addEventListener('click', () => {
  _logLines = [];
  const el = document.getElementById('sync-log');
  if (el) el.innerHTML = '';
  document.getElementById('sync-log-wrap').style.display = 'none';
});

/**
 * GAPMN — Anexador de Ordens Bancárias SILOMS
 *
 * Fluxo:
 *  1. Carrega CSV do Google Sheets publicado
 *  2. Índice NF → {OB, data} para matching com SILOMS
 *  3. Lê lista filtrada (Emissão de OB) no SILOMS
 *  4. Para cada linha: Abrir → Ordem de Pagamento → Upload Ordem Bancária
 *     → preenche Assunto (nº OB) → Procurar → gera PDF do dia → anexa → fecha
 */

'use strict';

// ── Configuração — EDITE AQUI ─────────────────────────────────────────────────
var GSHEET_CSV_URL  = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSYIxDW5oNp456_qcsDBiMV9rCrsXXmgPuGK2mqis2_k203qcCUGG1omx7jjZ_JRTZjIQgnj-SHmFaX/pub?gid=1989241909&single=true&output=csv';
var DATA_INICIO_STR = ''; // Definido pelo painel (campo "Data início")
var PDF_NCOLS       = 19;           // Inclui colunas A-S (índices 0–18); última col (T = Movim. Líquido) excluída
var COL_UGE         = 0;            // A — Código UGE (120630 = GAP-MN | 120006 = GAP-BR)
var COL_UNIT        = 1;            // B — Nome da unidade
var COL_DATE        = 2;            // C — Emissão - Dia  (era A)
var COL_OB          = 3;            // D — Documento / nº OB  (era B)
var COL_OBS         = 4;            // E — Doc-Observação, contém "NF XXXXXX"  (era C)

// ── Unidades suportadas ───────────────────────────────────────────────────────
var UGE_GAPMN = '120630';
var UGE_GAPBR = '120006';

// UGE selecionada pelo usuário na primeira abertura (carregada do storage)
var selectedUGE = '';

// ── Chaves de storage ─────────────────────────────────────────────────────────
var STORAGE_KEY   = 'gapmn_ob_state';
var OB_CSV_KEY    = 'gapmn_ob_csv';
var OB_URL_KEY    = 'gapmn_ob_url';
var OB_INICIO_KEY = 'gapmn_ob_inicio';
var OB_UGE_KEY    = 'gapmn_ob_uge';   // '120630' ou '120006'
var PANEL_ID      = '__obPanel__';

// ── State persistence ─────────────────────────────────────────────────────────

function readState() {
  return new Promise(function (res) {
    chrome.storage.local.get(STORAGE_KEY, function (d) { res(d[STORAGE_KEY] || null); });
  });
}
function saveState(s) {
  return new Promise(function (res) {
    var o = {}; o[STORAGE_KEY] = s;
    chrome.storage.local.set(o, res);
  });
}
function clearState() {
  return new Promise(function (res) { chrome.storage.local.remove(STORAGE_KEY, res); });
}
function saveCSV(t) {
  return new Promise(function (res) {
    var o = {}; o[OB_CSV_KEY] = t;
    chrome.storage.local.set(o, res);
  });
}
function loadCSV() {
  return new Promise(function (res) {
    chrome.storage.local.get(OB_CSV_KEY, function (d) { res(d[OB_CSV_KEY] || ''); });
  });
}

// ── CSV parser ────────────────────────────────────────────────────────────────

function parseCSV(text) {
  var rows = [];
  var lines = text.split(/\r?\n/);
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];
    if (!line.trim()) continue;
    var cols = [], cur = '', inQ = false;
    for (var j = 0; j < line.length; j++) {
      var c = line[j];
      if (c === '"') {
        if (inQ && line[j + 1] === '"') { cur += '"'; j++; }
        else { inQ = !inQ; }
      } else if (c === ',' && !inQ) {
        cols.push(cur.trim()); cur = '';
      } else {
        cur += c;
      }
    }
    cols.push(cur.trim());
    rows.push(cols);
  }
  return rows;
}

// Encontra linha de cabeçalho e retorna {headers, rows}
// Detecção flexível: escaneia todas as colunas das primeiras 8 linhas.
// Ao encontrar "Emissão" e "Documento" adjacentes, atualiza os índices globais
// COL_DATE, COL_OB, COL_OBS e COL_UGE para refletir o formato real do CSV.
function parseOBData(csvText) {
  var rows = parseCSV(csvText);
  if (!rows.length) return { headers: [], rows: [] };

  // Log das 3 primeiras linhas para diagnóstico no console
  console.log('[OB-DEBUG] Primeiras 3 linhas do CSV:');
  for (var d = 0; d < Math.min(rows.length, 3); d++) {
    console.log('[OB-DEBUG] row[' + d + '] =', JSON.stringify(rows[d].slice(0, 10)));
  }

  var headerIdx = -1;

  // 1º tenta nas posições esperadas (formato novo: UGE/Unit nas colunas A/B)
  for (var i = 0; i < Math.min(rows.length, 8); i++) {
    if (/emiss/i.test(rows[i][COL_DATE] || '') && /doc/i.test(rows[i][COL_OB] || '')) {
      headerIdx = i;
      console.log('[OB-DEBUG] Cabeçalho encontrado na linha ' + i + ' (formato novo, COL_DATE=' + COL_DATE + ')');
      break;
    }
  }

  // 2º fallback: escaneia qualquer coluna — detecta formato antigo (sem cols UGE/Unit)
  if (headerIdx < 0) {
    for (var i = 0; i < Math.min(rows.length, 8); i++) {
      var row = rows[i];
      var foundDate = -1, foundOB = -1;
      for (var c = 0; c < row.length; c++) {
        if (/emiss/i.test(row[c] || '') && foundDate < 0) foundDate = c;
        if (/^doc/i.test(row[c] || '')  && foundOB  < 0) foundOB  = c;
      }
      if (foundDate >= 0 && foundOB >= 0 && foundOB > foundDate) {
        headerIdx = i;
        // Atualiza índices globais para o formato detectado
        COL_DATE = foundDate;
        COL_OB   = foundOB;
        COL_OBS  = foundOB + 1;
        COL_UGE  = foundDate >= 2 ? foundDate - 2 : -1; // -1 = sem coluna UGE
        console.log('[OB-DEBUG] Cabeçalho detectado na linha ' + i +
          ' — Emissão col=' + COL_DATE + ', OB col=' + COL_OB +
          ', UGE col=' + COL_UGE + ' (formato ' + (COL_UGE < 0 ? 'antigo' : 'novo') + ')');
        break;
      }
    }
  }

  if (headerIdx < 0) {
    console.log('[OB-DEBUG] Cabeçalho NÃO encontrado. row[0]:', JSON.stringify((rows[0] || []).slice(0, 10)));
    return { headers: [], rows: [] };
  }

  var headers = rows[headerIdx].slice(0, PDF_NCOLS);

  // Cols UGE (A) e Data (C) podem estar mescladas no Sheets → vazias no CSV.
  // Propagamos o último valor visto para preencher as linhas do mesmo grupo.
  var lastUGE  = '';
  var lastDate = '';
  var data = [];
  var rawRows = rows.slice(headerIdx + 1);
  for (var i = 0; i < rawRows.length; i++) {
    var r       = rawRows[i];
    var ugeVal  = COL_UGE >= 0 ? (r[COL_UGE]  || '').trim() : '';
    var dateVal = (r[COL_DATE] || '').trim();
    var obVal   = (r[COL_OB]   || '').trim();
    if (ugeVal)  lastUGE  = ugeVal;
    if (dateVal) lastDate = dateVal;
    if (!obVal) continue;
    r = r.slice(); // copia para não mutar o original
    if (COL_UGE >= 0 && !ugeVal  && lastUGE)  r[COL_UGE]  = lastUGE;
    if (!dateVal && lastDate) r[COL_DATE] = lastDate;
    data.push(r);
  }

  return { headers: headers, rows: data };
}

// ── Utilitários de data e NF ──────────────────────────────────────────────────

function parseDate(val) {
  var s = String(val || '').trim();
  var m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
  return null;
}
function dateKey(d) {
  var dd = ('0' + d.getDate()).slice(-2);
  var mm = ('0' + (d.getMonth() + 1)).slice(-2);
  return d.getFullYear() + '-' + mm + '-' + dd;
}
function dateBR(d) {
  var dd = ('0' + d.getDate()).slice(-2);
  var mm = ('0' + (d.getMonth() + 1)).slice(-2);
  return dd + '/' + mm + '/' + d.getFullYear();
}

// Extrai número da NF do texto da coluna C
function extractNF(obsText) {
  var t = String(obsText || '').replace(/\s+/g, ' ');
  var m;
  // "NF 632", "NF-e 632", "NFe632"
  m = t.match(/\bNF[eE]?\s*[-:]?\s*(\d+)/i);
  if (m) return m[1];
  // "Nota Fiscal 632", "Nota Fiscal nº 632"
  m = t.match(/nota\s+fiscal\s*[nN°º#.]?\s*(\d+)/i);
  if (m) return m[1];
  // Número puro com 3+ dígitos (fallback)
  m = t.match(/\b(\d{3,})\b/);
  if (m) return m[1];
  return null;
}
function normNF(s) {
  return String(s || '').replace(/\D/g, '').replace(/^0+/, '') || '0';
}

// Constrói índice: normNF → {obNum, dk, dateBR}
// ugeFilter: '120630' (GAP-MN) ou '120006' (GAP-BR) — vazio = sem filtro
function buildNFIndex(rows, ugeFilter) {
  var inicio = parseDate(DATA_INICIO_STR);
  var idx = {};
  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    if (ugeFilter && COL_UGE >= 0 && String(row[COL_UGE] || '').trim() !== ugeFilter) continue;
    var d   = parseDate(row[COL_DATE]);
    if (!d || (inicio && d < inicio)) continue;
    var nf = extractNF(row[COL_OBS]);
    if (!nf) continue;
    var key = normNF(nf);
    if (!idx[key]) {
      idx[key] = {
        obNum:  String(row[COL_OB] || '').trim(),
        dk:     dateKey(d),
        dateBR: dateBR(d),
      };
    }
  }
  return idx;
}

// Agrupa rows por dateKey para geração de PDF
// ugeFilter: '120630' (GAP-MN) ou '120006' (GAP-BR) — vazio = sem filtro
function groupByDate(rows, ugeFilter) {
  var inicio = parseDate(DATA_INICIO_STR);
  var groups = {};
  for (var i = 0; i < rows.length; i++) {
    if (ugeFilter && COL_UGE >= 0 && String(rows[i][COL_UGE] || '').trim() !== ugeFilter) continue;
    var d = parseDate(rows[i][COL_DATE]);
    if (!d || (inicio && d < inicio)) continue;
    var k = dateKey(d);
    if (!groups[k]) groups[k] = [];
    groups[k].push(rows[i]);
  }
  return groups;
}

// ── Geração de PDF ────────────────────────────────────────────────────────────

function ugeLabel(uge) {
  if (uge === UGE_GAPMN) return 'GAP-MN';
  if (uge === UGE_GAPBR) return 'GAP-BR';
  return uge || 'GAPMN';
}

function generatePDF(dateStrBR, dayRows, headers) {
  // Tenta todas as formas possíveis de acesso ao jsPDF no contexto isolado MV3
  var jspdfLib = null;
  try { if (typeof jspdf   !== 'undefined' && jspdf)   jspdfLib = jspdf;   } catch (_) {}
  try { if (typeof jsPDF   !== 'undefined' && jsPDF)   jspdfLib = jsPDF;   } catch (_) {}
  try { if (!jspdfLib && window.jspdf)  jspdfLib = window.jspdf;  } catch (_) {}
  try { if (!jspdfLib && window.jsPDF)  jspdfLib = window.jsPDF;  } catch (_) {}
  try { if (!jspdfLib && self.jspdf)    jspdfLib = self.jspdf;    } catch (_) {}
  try { if (!jspdfLib && globalThis.jspdf) jspdfLib = globalThis.jspdf; } catch (_) {}
  log('DEBUG jsPDF: jspdf=' + (typeof jspdf) + ' globalThis.jspdf=' + (typeof globalThis.jspdf), 'info');
  if (!jspdfLib) { log('jsPDF nao carregado — recarregue a pagina e tente novamente', 'err'); return null; }
  var JsPDF = jspdfLib.jsPDF || jspdfLib;

  var doc = new JsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

  // Cabeçalho
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('Ordens Bancarias - ' + ugeLabel(selectedUGE) + ' - ' + dateStrBR, 8, 11);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.text('Gerado em: ' + new Date().toLocaleString('pt-BR'), 8, 16);

  // Linha separadora
  doc.setDrawColor(31, 73, 125);
  doc.setLineWidth(0.4);
  doc.line(8, 18, 289, 18);

  var body = dayRows.map(function (r) {
    return r.slice(0, PDF_NCOLS).map(function (c) { return String(c == null ? '' : c); });
  });
  var head = [headers.map(function (h) { return String(h == null ? '' : h); })];

  doc.autoTable({
    head:   head,
    body:   body,
    startY: 21,
    styles: {
      fontSize:    5.5,
      cellPadding: 1.2,
      overflow:    'linebreak',
      lineColor:   [203, 213, 225],
      lineWidth:   0.1,
    },
    headStyles: {
      fillColor:  [31, 73, 125],
      textColor:  255,
      fontStyle:  'bold',
      fontSize:   5.5,
      halign:     'center',
    },
    alternateRowStyles: { fillColor: [235, 242, 250] },
    columnStyles: {
      0: { cellWidth: 13 },   // A - Código UGE
      1: { cellWidth: 18 },   // B - Nome unidade
      2: { cellWidth: 14 },   // C - Emissão-Dia
      3: { cellWidth: 18 },   // D - Documento / nº OB
      4: { cellWidth: 40 },   // E - Doc-Observação (mais larga)
      5: { cellWidth: 24 },   // F - Favorecido
    },
    theme:  'grid',
    margin: { left: 6, right: 6, top: 21 },
  });

  // Rodapé com total de linhas
  var pageCount = doc.internal.getNumberOfPages();
  for (var p = 1; p <= pageCount; p++) {
    doc.setPage(p);
    doc.setFontSize(5.5);
    doc.setTextColor(148, 163, 184);
    doc.text('Total de OBs: ' + dayRows.length + '   |   Pagina ' + p + '/' + pageCount,
      doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 4, { align: 'center' });
  }

  return doc.output('blob');
}

// ── Utilitários DOM (GeneXus / SILOMS) ───────────────────────────────────────

function delay(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

function allDocs() {
  var list = [], visited = [];
  function collect(doc) {
    if (!doc) return;
    for (var v = 0; v < visited.length; v++) { if (visited[v] === doc) return; }
    visited.push(doc); list.push(doc);
    try {
      var fr = doc.querySelectorAll('iframe,frame');
      for (var i = 0; i < fr.length; i++) {
        try { collect(fr[i].contentDocument); } catch (_) {}
      }
    } catch (_) {}
  }
  collect(document);
  return list;
}

function findEl(sel, text, skipPopup) {
  var docs = allDocs();
  for (var di = 0; di < docs.length; di++) {
    var d = docs[di];
    if (skipPopup) {
      try { if (/gxPopupLevel|GxPopup/i.test(d.location.href)) continue; } catch (_) {}
    }
    try {
      var els = d.querySelectorAll(sel);
      for (var ei = 0; ei < els.length; ei++) {
        if (!text) return els[ei];
        var t = (els[ei].value || els[ei].textContent || '');
        if (t.toLowerCase().indexOf(text.toLowerCase()) !== -1) return els[ei];
      }
    } catch (_) {}
  }
  return null;
}

async function waitEl(sel, text, ms, skipPopup) {
  var end = Date.now() + (ms || 12000);
  while (Date.now() < end) {
    var el = findEl(sel, text, skipPopup);
    if (el) return el;
    await delay(150);
  }
  return null;
}

function fill(el, val) {
  try { el.focus(); } catch (_) {}
  try { el.value = val; } catch (_) {}
  ['input', 'change', 'blur'].forEach(function (ev) {
    try { el.dispatchEvent(new Event(ev, { bubbles: true })); } catch (_) {}
  });
}

// Clique via background service worker (bypassa CSP — usa chrome.scripting MAIN world)
// Funciona para qualquer elemento em qualquer frame do tab atual.
function gxClickBg(selector) {
  return new Promise(function (resolve) {
    chrome.runtime.sendMessage({ type: 'GAPMN_CLICK_GX', selector: selector }, function (resp) {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(resp || { ok: false, error: 'sem resposta' });
    });
  });
}

// Converte Blob para base64 (sem o prefixo data:...)
function blobToBase64(blob) {
  return new Promise(function (resolve, reject) {
    var reader = new FileReader();
    reader.onload = function () { resolve(reader.result.split(',')[1]); };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Seta arquivo no input[type=file] via background MAIN world — visível ao GeneXus
function gxSetFileBg(selector, base64, fileName) {
  return new Promise(function (resolve) {
    chrome.runtime.sendMessage(
      { type: 'GAPMN_SET_FILE', selector: selector, base64: base64, fileName: fileName, mimeType: 'application/pdf' },
      function (resp) {
        if (chrome.runtime.lastError) { resolve({ ok: false, error: chrome.runtime.lastError.message }); return; }
        resolve(resp || { ok: false, error: 'sem resposta' });
      }
    );
  });
}

// Clique via injeção de script no contexto da página (dispara listeners GeneXus)
function gxClick(el, doc) {
  var onclick = (el.getAttribute && el.getAttribute('onclick')) || '';
  var href    = (el.getAttribute && el.getAttribute('href'))    || '';
  var code    = onclick || (href.startsWith('javascript:') ? href.slice(11) : '');
  if (code && doc) {
    try {
      var s = doc.createElement('script');
      s.textContent = '(function(){try{' + code + '}catch(e){console.error("[OB]",e);}})();';
      (doc.head || doc.body).appendChild(s);
      try { s.parentNode.removeChild(s); } catch (_) {}
      return;
    } catch (_) {}
  }
  try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); } catch (_) {}
  try { el.click(); } catch (_) {}
}

// Encontra documento pai do elemento
function ownerDoc(el) {
  var docs = allDocs();
  for (var di = 0; di < docs.length; di++) {
    try { if (docs[di].contains(el)) return docs[di]; } catch (_) {}
  }
  return document;
}

// Encontra input[src*="SAIR1.BMP"] pelo número de foco GeneXus — tolerante a espaços (ex: ", 15,")
function findSairBtn(focusId) {
  var re = new RegExp(',\\s*' + focusId + '\\s*[,)]');
  var docs = allDocs();
  for (var di = 0; di < docs.length; di++) {
    var d = docs[di];
    try {
      var btns = d.querySelectorAll('input[src*="SAIR1.BMP"]');
      for (var bi = 0; bi < btns.length; bi++) {
        var fo = btns[bi].getAttribute('onfocus') || '';
        if (re.test(fo)) return btns[bi];
      }
    } catch (_) {}
  }
  return null;
}

// ── Seleção de Unidade (primeira abertura) ────────────────────────────────────

function closePanel() {
  var panel = document.getElementById(PANEL_ID);
  var tab   = document.getElementById('__ob_tab__');
  if (panel) panel.style.display = 'none';
  if (tab)   tab.style.display   = 'flex';
}

function showUGESelection(panel, onConfirm) {
  panel.innerHTML = [
    '<div style="padding:10px 14px 0;display:flex;justify-content:flex-end">',
      '<button id="__ob_uge_close__" style="background:none;border:none;color:#64748b;cursor:pointer;font-size:18px;padding:0 2px;line-height:1">&times;</button>',
    '</div>',
    '<div style="padding:4px 16px 16px">',
      '<div style="font-weight:700;color:#60a5fa;font-size:13px;margin-bottom:4px">Anexador de Ordens Bancárias</div>',
      '<div style="font-size:11px;color:#94a3b8;margin-bottom:16px;line-height:1.6">',
        'Antes de começar, informe a qual <b style="color:#e2e8f0">unidade</b> você pertence.<br>',
        '<span style="color:#fcd34d;font-weight:600">⚠ Esta escolha determina quais OBs serão processadas — confirme com atenção.</span>',
      '</div>',
      '<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px">',
        '<button id="__ob_sel_mn__" style="padding:12px;background:rgba(37,99,235,0.15);border:2px solid #1d4ed8;',
          'color:#93c5fd;border-radius:9px;cursor:pointer;font-size:13px;font-weight:700;text-align:left">',
          '🛩 GAP-MN &nbsp;<span style="font-weight:400;font-size:11px;color:#64748b">Grupamento de Apoio de Manaus (UGE 120630)</span>',
        '</button>',
        '<button id="__ob_sel_br__" style="padding:12px;background:rgba(5,150,105,0.12);border:2px solid #065f46;',
          'color:#6ee7b7;border-radius:9px;cursor:pointer;font-size:13px;font-weight:700;text-align:left">',
          '🛩 GAP-BR &nbsp;<span style="font-weight:400;font-size:11px;color:#64748b">Grupamento de Apoio de Brasília (UGE 120006)</span>',
        '</button>',
      '</div>',
    '</div>',
  ].join('');

  function askConfirm(uge, label, fullName) {
    panel.innerHTML = [
      '<div style="padding:10px 14px 0;display:flex;justify-content:flex-end">',
        '<button id="__ob_conf_close__" style="background:none;border:none;color:#64748b;cursor:pointer;font-size:18px;padding:0 2px;line-height:1">&times;</button>',
      '</div>',
      '<div style="padding:4px 16px 16px">',
        '<div style="font-weight:700;color:#60a5fa;font-size:13px;margin-bottom:12px">Confirmar Unidade</div>',
        '<div style="background:rgba(251,191,36,0.08);border:1px solid rgba(251,191,36,0.3);border-radius:9px;padding:14px;margin-bottom:16px">',
          '<div style="font-size:13px;color:#fcd34d;font-weight:700;margin-bottom:6px">⚠ CONFIRME COM ATENÇÃO</div>',
          '<div style="font-size:12px;color:#e2e8f0;line-height:1.7">',
            'Você selecionou:<br>',
            '<b style="font-size:14px;color:#fff">' + label + '</b><br>',
            '<span style="color:#94a3b8;font-size:11px">' + fullName + ' (UGE ' + uge + ')</span>',
          '</div>',
        '</div>',
        '<div style="font-size:11px;color:#94a3b8;margin-bottom:14px">',
          'O robô irá processar <b style="color:#e2e8f0">apenas as OBs dessa unidade</b>. Esta configuração fica salva no navegador.',
        '</div>',
        '<button id="__ob_conf_sim__" style="width:100%;padding:10px;background:#15803d;color:#fff;border:none;',
          'border-radius:8px;cursor:pointer;font-size:12px;font-weight:700;margin-bottom:8px">',
          '✔ Sim, sou do ' + label + ' — Confirmar',
        '</button>',
        '<button id="__ob_conf_nao__" style="width:100%;padding:8px;background:none;border:1px solid #334155;',
          'color:#94a3b8;border-radius:8px;cursor:pointer;font-size:11px">',
          '← Voltar e escolher outra unidade',
        '</button>',
      '</div>',
    ].join('');

    document.getElementById('__ob_conf_close__').onclick = closePanel;
    document.getElementById('__ob_conf_sim__').onclick = function () {
      selectedUGE = uge;
      var o = {}; o[OB_UGE_KEY] = uge;
      chrome.storage.local.set(o, function () { onConfirm(uge); });
    };
    document.getElementById('__ob_conf_nao__').onclick = function () {
      showUGESelection(panel, onConfirm);
    };
  }

  document.getElementById('__ob_uge_close__').onclick = closePanel;
  document.getElementById('__ob_sel_mn__').onclick = function () {
    askConfirm(UGE_GAPMN, 'GAP-MN', 'Grupamento de Apoio de Manaus');
  };
  document.getElementById('__ob_sel_br__').onclick = function () {
    askConfirm(UGE_GAPBR, 'GAP-BR', 'Grupamento de Apoio de Brasília');
  };
}

// ── Painel UI ─────────────────────────────────────────────────────────────────

var logEl = null;
var obCache = null; // { headers, rows, nfIndex, groups }

function log(msg, lvl) {
  if (!logEl) logEl = document.getElementById('__ob_log__');
  if (!logEl) return;
  var c = { info: '#cbd5e1', ok: '#4ade80', warn: '#fcd34d', err: '#f87171' };
  var d = document.createElement('div');
  d.style.color = c[lvl] || c.info;
  var ts = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  d.textContent = '[' + ts + '] ' + msg;
  logEl.appendChild(d);
  logEl.scrollTop = logEl.scrollHeight;
}

function setSub(t) { var el = document.getElementById('__ob_sub__'); if (el) el.textContent = t; }

function setProgress(cur, total) {
  var pt  = document.getElementById('__ob_pt__');
  var bar = document.getElementById('__ob_bar__');
  if (pt)  pt.textContent = cur + '/' + total;
  if (bar) bar.style.width = (total ? Math.round(cur / total * 100) : 0) + '%';
}

function injectPanel(forceShow) {
  if (document.getElementById(PANEL_ID)) return;
  var vis = !!forceShow;

  var panel = document.createElement('div');
  panel.id = PANEL_ID;
  panel.style.cssText = [
    'position:fixed;bottom:16px;right:16px;width:380px;max-height:90vh',
    'background:#0f172a;color:#e2e8f0',
    'border:1px solid #334155;border-radius:12px',
    'font:12px/1.5 system-ui,sans-serif',
    'z-index:2147483647;box-shadow:0 8px 32px rgba(0,0,0,.85)',
    'overflow:hidden;display:' + (vis ? 'flex' : 'none') + ';flex-direction:column',
  ].join(';');

  panel.innerHTML = [
    // Header
    '<div style="padding:10px 14px;background:#0f172a;border-bottom:1px solid #1e293b;display:flex;justify-content:space-between;align-items:center;flex-shrink:0">',
      '<div>',
        '<div style="font-weight:700;color:#60a5fa;font-size:13px">Anexador de Ordens Banc&aacute;rias</div>',
        '<div style="font-size:10px;color:#475569;margin-top:1px">',
          ugeLabel(selectedUGE) + ' &nbsp;&middot;&nbsp; ',
          '<button id="__ob_trocar_uge__" style="background:none;border:none;color:#475569;cursor:pointer;font-size:10px;text-decoration:underline;padding:0">trocar unidade</button>',
        '</div>',
        '<div id="__ob_sub__" style="font-size:10px;color:#475569">Aguardando&hellip;</div>',
      '</div>',
      '<button id="__ob_close__" style="background:none;border:none;color:#64748b;cursor:pointer;font-size:18px;padding:0 2px;line-height:1">&times;</button>',
    '</div>',

    // Config
    '<div id="__ob_cfg__" style="padding:12px 14px;flex-shrink:0">',
      '<p style="font-size:10px;color:#94a3b8;margin:0 0 5px">URL do CSV publicado (Google Sheets &rarr; Arquivo &rarr; Publicar na web &rarr; CSV):</p>',
      '<input id="__ob_url__" type="text" placeholder="https://docs.google.com/spreadsheets/d/..." ',
        'style="width:100%;box-sizing:border-box;background:rgba(255,255,255,0.06);border:1px solid #334155;',
        'border-radius:6px;color:#e2e8f0;font-size:10px;padding:5px 8px;outline:none;margin-bottom:7px">',
      '<div style="display:flex;gap:6px;margin-bottom:7px;align-items:center">',
        '<div style="flex:1">',
          '<p style="font-size:10px;color:#94a3b8;margin:0 0 3px">Data início (DD/MM/AAAA) — deixe vazio para todas:</p>',
          '<input id="__ob_inicio__" type="text" placeholder="ex: 25/08/2026" maxlength="10" ',
            'style="width:100%;box-sizing:border-box;background:rgba(255,255,255,0.06);border:1px solid #334155;',
            'border-radius:6px;color:#e2e8f0;font-size:10px;padding:5px 8px;outline:none">',
        '</div>',
      '</div>',
      '<button id="__ob_load__" style="width:100%;padding:8px;background:#1d4ed8;color:#fff;border:none;',
        'border-radius:7px;cursor:pointer;font-size:11px;font-weight:600;margin-bottom:6px">',
        '&#8595; Carregar dados da planilha</button>',
      '<div id="__ob_summary__" style="font-size:10px;color:#64748b;min-height:14px;margin-bottom:6px"></div>',
      '<button id="__ob_start__" style="display:none;width:100%;padding:9px;background:#15803d;color:#fff;',
        'border:none;border-radius:7px;cursor:pointer;font-size:12px;font-weight:700">',
        '&#9654; Iniciar automa&ccedil;&atilde;o no SILOMS</button>',
    '</div>',

    // Progresso
    '<div id="__ob_prog__" style="display:none;padding:6px 14px 2px;flex-shrink:0">',
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">',
        '<span id="__ob_pt__" style="font-size:10px;color:#94a3b8">0/0</span>',
        '<button id="__ob_abort__" style="font-size:10px;padding:2px 8px;background:#7f1d1d;color:#fca5a5;border:none;border-radius:4px;cursor:pointer">Abortar</button>',
      '</div>',
      '<div style="background:#1e293b;border-radius:3px;height:4px;overflow:hidden;margin-bottom:6px">',
        '<div id="__ob_bar__" style="height:100%;background:#2563eb;width:0%;transition:width .3s"></div>',
      '</div>',
    '</div>',

    // Log
    '<div id="__ob_log__" style="background:#0a0f1a;border-top:1px solid #1e293b;padding:6px 10px;',
      'min-height:90px;max-height:260px;overflow-y:auto;font-family:monospace;font-size:10px;line-height:1.7;flex:1"></div>',
  ].join('');

  document.body.appendChild(panel);
  logEl = document.getElementById('__ob_log__');

  // Botão flutuante
  var tab = document.createElement('button');
  tab.id = '__ob_tab__';
  tab.textContent = 'OB';
  tab.style.cssText = 'position:fixed;bottom:16px;right:16px;width:42px;height:42px;border-radius:50%;' +
    'background:#1e40af;color:#fff;border:none;cursor:pointer;font-size:12px;font-weight:700;' +
    'z-index:2147483647;box-shadow:0 4px 12px rgba(0,0,0,.5);' +
    'display:' + (vis ? 'none' : 'flex') + ';align-items:center;justify-content:center';
  tab.onmouseenter = function () { tab.style.background = '#1d4ed8'; };
  tab.onmouseleave = function () { tab.style.background = '#1e40af'; };
  tab.onclick = function () { panel.style.display = 'flex'; tab.style.display = 'none'; };
  document.body.appendChild(tab);

  document.getElementById('__ob_close__').onclick = function () {
    panel.style.display = 'none'; tab.style.display = 'flex';
  };

  var trocarUge = document.getElementById('__ob_trocar_uge__');
  if (trocarUge) {
    trocarUge.onclick = function (e) {
      e.stopPropagation();
      showUGESelection(panel, function (uge) {
        panel.remove();
        var oldTab = document.getElementById('__ob_tab__');
        if (oldTab) oldTab.remove();
        injectPanel(false);
        // Exibe painel imediatamente após confirmação
        var np = document.getElementById(PANEL_ID);
        if (np) np.style.display = 'flex';
        var nt = document.getElementById('__ob_tab__');
        if (nt) nt.style.display = 'none';
      });
    };
  }

  // Restaura URL e data início — usa predefinidos se não houver valor salvo
  chrome.storage.local.get([OB_URL_KEY, OB_INICIO_KEY], function (d) {
    var u = d[OB_URL_KEY] || GSHEET_CSV_URL;
    document.getElementById('__ob_url__').value = u;

    // Data início: salvo → '01/09/2026' como padrão
    var ini = (d[OB_INICIO_KEY] !== undefined && d[OB_INICIO_KEY] !== '')
              ? d[OB_INICIO_KEY]
              : '01/09/2026';
    document.getElementById('__ob_inicio__').value = ini;
    DATA_INICIO_STR = ini;

    // Carrega automaticamente ao abrir (usa cache se disponível, faz fetch se não houver)
    setTimeout(function () {
      document.getElementById('__ob_load__').click();
    }, 400);
  });

  document.getElementById('__ob_load__').onclick = async function () {
    var url = (document.getElementById('__ob_url__').value || '').trim();
    if (!url) { log('Cole a URL do CSV antes de carregar', 'warn'); return; }
    DATA_INICIO_STR = (document.getElementById('__ob_inicio__').value || '').trim();
    var saveObj = {}; saveObj[OB_URL_KEY] = url; saveObj[OB_INICIO_KEY] = DATA_INICIO_STR;
    chrome.storage.local.set(saveObj);
    log('Buscando planilha...');
    try {
      var csvText = '';
      try {
        var resp = await fetch(url);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        csvText = await resp.text();
        await saveCSV(csvText);
      } catch (fetchErr) {
        log('Fetch falhou (' + fetchErr.message + ') — usando cache local.', 'warn');
        csvText = await loadCSV();
        if (!csvText) { log('Sem cache disponível. Verifique a conexão.', 'err'); return; }
      }
      var parsed = parseOBData(csvText);
      if (!parsed.rows.length) { log('Nenhuma linha de dados encontrada. Verifique o CSV.', 'err'); return; }
      obCache = {
        headers: parsed.headers,
        rows:    parsed.rows,
        nfIndex: buildNFIndex(parsed.rows, selectedUGE),
        groups:  groupByDate(parsed.rows, selectedUGE),
      };
      var nDates = Object.keys(obCache.groups).length;
      var nNFs   = Object.keys(obCache.nfIndex).length;
      var sumEl  = document.getElementById('__ob_summary__');
      sumEl.style.color = '#4ade80';
      sumEl.textContent = parsed.rows.length + ' OBs | ' + nDates + ' dias | ' + nNFs + ' NFs — ' + ugeLabel(selectedUGE);
      document.getElementById('__ob_start__').style.display = '';
      log(parsed.rows.length + ' linhas lidas, ' + nNFs + ' NFs (' + ugeLabel(selectedUGE) + ') a partir de ' + DATA_INICIO_STR + '.', 'ok');
    } catch (e) {
      log('Erro ao carregar CSV: ' + e.message, 'err');
    }
  };

  document.getElementById('__ob_start__').onclick = async function () {
    if (!obCache) { log('Carregue os dados primeiro', 'warn'); return; }
    await startAutomation();
  };

  document.getElementById('__ob_abort__').onclick = async function () {
    await clearState();
    window.location.reload();
  };
}

// ── Localiza tabela de resultados e índice da coluna Abrir ───────────────────

function findResultsTable() {
  var docs = allDocs();
  for (var di = 0; di < docs.length; di++) {
    var d = docs[di];
    try {
      var tables = d.querySelectorAll('table');
      for (var ti = 0; ti < tables.length; ti++) {
        var tbl = tables[ti];
        // Usa apenas <th> diretos (não de subtabelas) para identificar a tabela certa
        var heads = tbl.querySelectorAll('th');
        if (heads.length < 3) continue;
        var hasAbrir = false, hasNF = false;
        for (var hi = 0; hi < heads.length; hi++) {
          var ht = (heads[hi].textContent || '').trim().toLowerCase();
          if (ht === 'abrir' || ht === 'open') hasAbrir = true;
          if (/nota.?fiscal/i.test(ht)) hasNF = true;
        }
        if (hasAbrir && hasNF) return { tbl: tbl, doc: d };
      }
    } catch (_) {}
  }
  // fallback: tabela com td de header que tenha "Abrir" e "Nota Fiscal"
  for (var di2 = 0; di2 < docs.length; di2++) {
    var d2 = docs[di2];
    try {
      var tables2 = d2.querySelectorAll('table');
      for (var ti2 = 0; ti2 < tables2.length; ti2++) {
        var tbl2 = tables2[ti2];
        var firstRow = tbl2.rows[0];
        if (!firstRow) continue;
        var cells = firstRow.cells;
        var hasAbrir2 = false, hasNF2 = false;
        for (var ci = 0; ci < cells.length; ci++) {
          var ct = (cells[ci].textContent || '').trim().toLowerCase();
          if (ct === 'abrir' || ct === 'open') hasAbrir2 = true;
          if (/nota.?fiscal/i.test(ct)) hasNF2 = true;
        }
        if (hasAbrir2 && hasNF2) return { tbl: tbl2, doc: d2 };
      }
    } catch (_) {}
  }
  return null;
}

function getAbrirColIdx(tbl) {
  var heads = tbl.querySelectorAll('th, thead td');
  for (var i = 0; i < heads.length; i++) {
    var ht = (heads[i].textContent || '').trim().toLowerCase();
    if (ht === 'abrir' || ht === 'open') return i;
  }
  return -1;
}

function getNFColIdx(tbl) {
  var heads = tbl.querySelectorAll('th, thead td');
  for (var i = 0; i < heads.length; i++) {
    if (/nota.?fiscal/i.test(heads[i].textContent || '')) return i;
  }
  var r0 = tbl.rows[0];
  if (r0) {
    for (var ci = 0; ci < r0.cells.length; ci++) {
      if (/nota.?fiscal/i.test(r0.cells[ci].textContent || '')) return ci;
    }
  }
  return 0;
}

function getClickable(cell) {
  if (!cell) return null;
  // Botão Abrir do SILOMS: <img alt="Abrir"> dentro de um <a> ou [onclick]
  var abrirImg = cell.querySelector('img[alt="Abrir"]');
  if (abrirImg) {
    var parent = abrirImg.parentElement;
    if (parent && (parent.tagName === 'A' || parent.getAttribute('onclick'))) return parent;
    return abrirImg;
  }
  var el = cell.querySelector('a, input[type="button"], input[type="image"], input[type="submit"], button, img[onclick], [onclick]');
  if (el) return el;
  if (cell.getAttribute && cell.getAttribute('onclick')) return cell;
  return null;
}

function getRowClickable(row, abrirIdx) {
  if (!row || !row.cells) return null;
  // tenta célula da coluna Abrir primeiro
  var cell = abrirIdx >= 0 ? row.cells[abrirIdx] : row.cells[row.cells.length - 1];
  var el = getClickable(cell);
  if (el) return el;
  // varre todas as células da direita para a esquerda
  for (var ci = row.cells.length - 1; ci >= 0; ci--) {
    el = getClickable(row.cells[ci]);
    if (el) return el;
  }
  // fallback: a própria linha se tiver onclick
  if (row.getAttribute && row.getAttribute('onclick')) return row;
  return null;
}

// ── Lê itens da lista SILOMS (após filtro "Emissão de OB") ────────────────────

// Encontra tabela de DADOS (separada da de cabeçalho em GeneXus)
function findDataTable(headerTbl, doc) {
  var tables = doc.querySelectorAll('table');
  var hIdx = -1;
  for (var i = 0; i < tables.length; i++) {
    if (tables[i] === headerTbl) { hIdx = i; break; }
  }

  // Busca em TODAS as tabelas (prioriza as após o cabeçalho)
  var order = [];
  for (var j = (hIdx >= 0 ? hIdx + 1 : 0); j < tables.length; j++) order.push(j);
  for (var k = 0; k < (hIdx >= 0 ? hIdx : 0); k++) order.push(k);

  for (var si = 0; si < order.length; si++) {
    var tbl = tables[order[si]];
    if (tbl === headerTbl) continue;
    var rows = tbl.rows;
    var nfCount = 0;
    for (var ri = 0; ri < rows.length; ri++) {
      var cells = rows[ri].cells;
      if (!cells || cells.length < 4) continue;
      var nf = (cells[0].textContent || '').replace(/\s+/g, ' ').trim();
      if (isNFValid(nf)) { nfCount++; if (nfCount >= 1) return tbl; }
    }
  }
  return null;
}

function isNFValid(s) {
  if (!s || s.length === 0 || s.length > 25) return false;
  if (!/\d/.test(s)) return false;
  if (/nota.?fiscal/i.test(s)) return false;
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) return false;  // data DD/MM/AAAA
  if (/\d{1,3}[.,]\d{3}/.test(s) && /,\d{2}$/.test(s)) return false; // valor monetário
  return true;
}

async function readListItems() {
  var items = [];
  var seen  = {};
  var res   = findResultsTable();
  if (!res) { log('Tabela de cabeçalho não encontrada.', 'warn'); return items; }

  var abrirIdx  = getAbrirColIdx(res.tbl);
  var nfColIdx  = getNFColIdx(res.tbl);

  // Primeiro tenta ler da tabela de cabeçalho (caso seja tabela única)
  var dataTbl = null;
  var rows = res.tbl.rows;
  for (var ri = 0; ri < rows.length; ri++) {
    var cells = rows[ri].cells;
    if (!cells || cells.length < 4) continue;
    var nfTry = (cells[nfColIdx < cells.length ? nfColIdx : 0].textContent || '').replace(/\s+/g, ' ').trim();
    if (isNFValid(nfTry)) { dataTbl = res.tbl; break; }
  }

  // Se não achou dados na tabela de cabeçalho, procura tabela irmã (padrão GeneXus)
  if (!dataTbl) dataTbl = findDataTable(res.tbl, res.doc);

  if (!dataTbl) {
    var allTbls = res.doc.querySelectorAll('table');
    log('Tabela de dados não encontrada. Total tabelas na página: ' + allTbls.length, 'warn');
    for (var di = 0; di < Math.min(allTbls.length, 8); di++) {
      var r0t = allTbls[di].rows[0];
      var c0txt = r0t && r0t.cells[0] ? (r0t.cells[0].textContent || '').trim().substring(0, 30) : '(vazio)';
      log('  tbl[' + di + ']: ' + allTbls[di].rows.length + ' rows, col0[0]="' + c0txt + '"', 'info');
    }
    return items;
  }

  // Diagnóstico: mostra o que há em cada coluna da primeira linha de dados
  if (dataTbl.rows[0]) {
    var r0cells = dataTbl.rows[0].cells;
    var diagParts = [];
    for (var dc = 0; dc < Math.min(r0cells.length, 10); dc++) {
      diagParts.push('[' + dc + ']:"' + (r0cells[dc].textContent || '').replace(/\s+/g, ' ').trim().substring(0, 15) + '"');
    }
    log('DEBUG cols: ' + diagParts.join(' | '), 'info');
    log('DEBUG nfColIdx=' + nfColIdx + ' abrirIdx=' + abrirIdx, 'info');
  }

  var dataRows = dataTbl.rows;
  for (var ri2 = 0; ri2 < dataRows.length; ri2++) {
    var row    = dataRows[ri2];
    var cells2 = row.cells;
    if (!cells2 || cells2.length < 4) continue;
    var nfCi   = nfColIdx < cells2.length ? nfColIdx : 0;
    var nf2    = (cells2[nfCi].textContent || '').replace(/\s+/g, ' ').trim();
    if (!isNFValid(nf2)) continue;
    if (!seen[nf2]) {
      seen[nf2] = true;
      items.push({ nf: nf2 });
    }
  }

  log('Lista lida: ' + items.length + ' NFs. nfCol=' + nfColIdx + ' abrirCol=' + abrirIdx +
      (dataTbl !== res.tbl ? ' (tabela separada)' : ''));
  return items;
}

// ── Define "Exibir 500 registros" no select de paginação ────────────────────

async function setExibir500() {
  var docs = allDocs();
  for (var di = 0; di < docs.length; di++) {
    var d = docs[di];
    try {
      var selects = d.querySelectorAll('select');
      for (var si = 0; si < selects.length; si++) {
        var sel = selects[si];
        var opts = sel.options;
        if (opts.length < 2) continue;
        // Identifica select de paginação: maioria das opções são números puros
        var numericOpts = [];
        for (var oi = 0; oi < opts.length; oi++) {
          var txt = (opts[oi].text || opts[oi].value || '').trim();
          if (/^\d+$/.test(txt)) numericOpts.push({ idx: oi, val: parseInt(txt, 10) });
        }
        if (numericOpts.length < 2) continue; // não é select de paginação
        // Procura opção >= 500; se não houver, pega a maior disponível
        var target = null;
        for (var ni = 0; ni < numericOpts.length; ni++) {
          if (numericOpts[ni].val >= 500) { target = numericOpts[ni]; break; }
        }
        if (!target) {
          numericOpts.sort(function (a, b) { return b.val - a.val; });
          target = numericOpts[0];
        }
        if (sel.selectedIndex === target.idx) {
          log('Exibir já em ' + opts[target.idx].text + ' registros.', 'info');
          return;
        }
        sel.selectedIndex = target.idx;
        log('Exibir: ' + opts[target.idx].text + ' registros por página.', 'info');
        ['change', 'input'].forEach(function (ev) {
          try { sel.dispatchEvent(new Event(ev, { bubbles: true })); } catch (_) {}
        });
        var onchg = sel.getAttribute('onchange') || '';
        if (onchg) {
          try {
            var sc = d.createElement('script');
            sc.textContent = '(function(){try{' + onchg + '}catch(e){}})();';
            (d.head || d.body).appendChild(sc);
            try { sc.parentNode.removeChild(sc); } catch (_) {}
          } catch (_) {}
        }
        await delay(600);
        return;
      }
    } catch (_) {}
  }
  log('Select de paginação não encontrado.', 'info');
}

// ── Aplica filtro "Emissão de OB" automaticamente ────────────────────────────

async function applyFilter() {
  log('Procurando select de Situação Atual...');
  var situacaoSel = null;
  var situacaoDoc = null;
  var docs = allDocs();

  for (var di = 0; di < docs.length; di++) {
    var d = docs[di];
    try {
      var selects = d.querySelectorAll('select');
      for (var si = 0; si < selects.length; si++) {
        var sel = selects[si];
        for (var oi = 0; oi < sel.options.length; oi++) {
          var optTxt = sel.options[oi].text || '';
          if (/emiss/i.test(optTxt) && /\bOB\b/i.test(optTxt)) {
            situacaoSel = sel;
            situacaoDoc = d;
            break;
          }
        }
        if (situacaoSel) break;
      }
    } catch (_) {}
    if (situacaoSel) break;
  }

  if (!situacaoSel) {
    log('Select de Situação Atual não encontrado (pode já estar filtrado).', 'warn');
    return false;
  }

  // Seleciona opção "Emissão de OB"
  for (var oi2 = 0; oi2 < situacaoSel.options.length; oi2++) {
    var t2 = situacaoSel.options[oi2].text || '';
    if (/emiss/i.test(t2) && /\bOB\b/i.test(t2)) {
      situacaoSel.selectedIndex = oi2;
      log('Opção selecionada: ' + situacaoSel.options[oi2].text);
      break;
    }
  }

  // Dispara eventos e onchange GeneXus
  ['change', 'input', 'blur'].forEach(function (ev) {
    try { situacaoSel.dispatchEvent(new Event(ev, { bubbles: true })); } catch (_) {}
  });
  var onchg = situacaoSel.getAttribute('onchange') || '';
  if (onchg && situacaoDoc) {
    try {
      var sc = situacaoDoc.createElement('script');
      sc.textContent = '(function(){try{' + onchg + '}catch(e){}})();';
      (situacaoDoc.head || situacaoDoc.body).appendChild(sc);
      try { sc.parentNode.removeChild(sc); } catch (_) {}
    } catch (_) {}
  }
  await delay(800);

  // Define "Exibir 500 registros" se disponível
  await setExibir500();

  // Clica no botão de pesquisa
  var searchBtn = findEl('input[type="button"],input[type="submit"],button', 'Pesquisar')
               || findEl('input[type="button"],input[type="submit"],button', 'Filtrar')
               || findEl('input[type="button"],input[type="submit"],button', 'Buscar')
               || findEl('input[type="image"]', null);

  if (searchBtn) {
    log('Clicando Pesquisar...');
    gxClick(searchBtn, ownerDoc(searchBtn));
    log('Aguardando resultados...', 'info');
    await delay(3500);
    log('Filtro aplicado.', 'ok');
    return true;
  }

  log('Botão de pesquisa não encontrado.', 'warn');
  return false;
}

// ── Inicia automação ──────────────────────────────────────────────────────────

async function startAutomation() {
  log('Lendo lista SILOMS...');
  var items = await readListItems();

  if (!items.length) {
    log('Lista vazia — aplicando filtro automaticamente...', 'warn');
    await applyFilter();
    await delay(1500);
    items = await readListItems();
  }

  if (!items.length) {
    log('Nenhuma linha encontrada após filtro. Verifique se há recebimentos com "Emissão de OB".', 'err');
    return;
  }
  log(items.length + ' itens na lista.', 'ok');

  // Monta fila cruzando NF da lista com índice das OBs
  var queue = [];
  for (var i = 0; i < items.length; i++) {
    var rawNF = items[i].nf;
    var obInfo = obCache.nfIndex[normNF(rawNF)];
    if (!obInfo) {
      log('NF ' + rawNF + ' nao encontrada nos dados OB - sera pulada', 'warn');
      continue;
    }
    queue.push({ nf: rawNF, obNum: obInfo.obNum, dk: obInfo.dk, dateBR: obInfo.dateBR });
  }

  if (!queue.length) {
    log('Nenhuma NF da lista corresponde aos dados OB carregados.', 'err');
    log('Dica: verifique se o CSV esta atualizado e se a data inicio esta correta.', 'warn');
    return;
  }

  var state = { running: true, queue: queue, current: 0, results: [], step: 'list' };
  await saveState(state);

  document.getElementById('__ob_cfg__').style.display = 'none';
  document.getElementById('__ob_prog__').style.display = '';
  setProgress(0, queue.length);
  log(queue.length + ' itens para processar. Iniciando...', 'ok');
  await execListPage(state);
}

// ── Página de lista: clica Abrir na linha da NF correta ──────────────────────

async function findAbrirForNF(nf) {
  var endTime = Date.now() + 12000;
  while (Date.now() < endTime) {
    var res = findResultsTable();
    if (res) {
      var abrirIdx = getAbrirColIdx(res.tbl);
      var nfColIdx = getNFColIdx(res.tbl);
      // Tenta tabela única primeiro, depois tabela irmã
      var dataTbl = null;
      var hrows = res.tbl.rows;
      for (var hri = 0; hri < hrows.length; hri++) {
        var hc = hrows[hri].cells;
        if (hc && hc.length >= 4) {
          var nfCi0 = nfColIdx < hc.length ? nfColIdx : 0;
          var hnf = (hc[nfCi0].textContent || '').replace(/\s+/g, ' ').trim();
          if (isNFValid(hnf)) { dataTbl = res.tbl; break; }
        }
      }
      if (!dataTbl) dataTbl = findDataTable(res.tbl, res.doc);

      if (dataTbl) {
        var rows = dataTbl.rows;
        for (var ri = 0; ri < rows.length; ri++) {
          var row   = rows[ri];
          var cells = row.cells;
          if (!cells || cells.length < 4) continue;
          var nfCi  = nfColIdx < cells.length ? nfColIdx : 0;
          var cellNF = (cells[nfCi].textContent || '').replace(/\s+/g, ' ').trim();
          if (cellNF !== nf && normNF(cellNF) !== normNF(nf)) continue;
          var clickable = getRowClickable(row, abrirIdx);
          if (clickable) return clickable;
        }
      }
    }
    await delay(150);
  }
  return null;
}

async function execListPage(state) {
  var item = state.queue[state.current];
  if (!item) { await finalize(state); return; }

  setSub('NF ' + item.nf + ' (' + (state.current + 1) + '/' + state.queue.length + ')');
  setProgress(state.current + 1, state.queue.length);
  log('━━ [' + (state.current + 1) + '/' + state.queue.length + '] NF ' + item.nf + ' | OB ' + item.obNum + ' | ' + item.dateBR);

  // O filtro se mantém ao navegar de volta — não re-aplica a não ser que a NF não seja encontrada
  log('  Procurando botão Abrir na linha da NF ' + item.nf + '...');
  var abrirBtn = await findAbrirForNF(item.nf);
  if (!abrirBtn && state.current > 0) {
    log('  NF nao encontrada — filtro pode ter expirado, re-aplicando...', 'warn');
    await applyFilter();
    await delay(1500);
    abrirBtn = await findAbrirForNF(item.nf);
  }
  if (!abrirBtn) {
    log('  Botão Abrir não encontrado para NF ' + item.nf + ' — pulando', 'warn');
    await skipAndNext(state);
    return;
  }

  log('  Clicando Abrir...');
  // Salva a URL da lista para navegação direta de retorno após o upload
  var stateRecord = Object.assign({}, state, { step: 'record', listUrl: window.location.href });
  await saveState(stateRecord);
  gxClick(abrirBtn, ownerDoc(abrirBtn));
  await delay(300);
  await execRecordPage(stateRecord);
}

// ── Página do registro ────────────────────────────────────────────────────────

async function execRecordPage(state) {
  log('  [registro] Aguardando carregamento...');

  log('  Buscando aba "Ordem de Pagamento" (#tabHeader_6)...');
  var opLink = await waitEl('#tabHeader_6', null, 10000);
  if (!opLink) {
    // fallback por texto caso o ID mude
    opLink = await waitEl('a, td, li, input[type="button"], button, span', 'Ordem de Pagamento', 5000, true);
  }
  if (!opLink) {
    log('  "Ordem de Pagamento" nao encontrado - pulando', 'warn');
    await skipAndNext(state);
    return;
  }

  var stateUpload = Object.assign({}, state, { step: 'upload' });
  await saveState(stateUpload);

  log('  Clicando "Ordem de Pagamento"...');
  gxClick(opLink, ownerDoc(opLink));
  await delay(200);
  await execUploadPage(stateUpload);
}

// ── Página de upload ──────────────────────────────────────────────────────────

async function execUploadPage(state) {
  var item = state.queue[state.current];
  log('  Buscando "Upload Ordem Bancaria" (input[name="BUTTON13"])...');

  var uploadBtn = await waitEl('input[name="BUTTON13"]', null, 10000);
  if (!uploadBtn) {
    uploadBtn = await waitEl('a, td, input[type="button"], button, span', 'Upload Ordem Banc', 5000, true);
  }
  if (!uploadBtn) {
    log('  "Upload Ordem Bancaria" nao encontrado - pulando', 'warn');
    await skipAndNext(state);
    return;
  }

  log('  Clicando "Upload Ordem Bancaria" (via background/main-world)...');
  var btn13Resp = await gxClickBg('input[name="BUTTON13"]');
  log('  BUTTON13: ' + (btn13Resp.result || btn13Resp.error || '?'), 'info');
  if (!btn13Resp.ok || btn13Resp.result === 'not-found-in-frames') {
    // Fallback: gxClick direto (caso background falhe, ex: Firefox)
    gxClick(uploadBtn, ownerDoc(uploadBtn));
  }
  await delay(1800);  // aguarda modal "Inclusão de Documento" carregar completamente

  // ── Gera PDF do dia (antes de preencher o formulário) ─────────────────────
  log('  Gerando PDF para ' + item.dateBR + '...');
  var csvText = await loadCSV();
  var parsed  = parseOBData(csvText);
  var groups  = groupByDate(parsed.rows, selectedUGE);
  var dayRows = groups[item.dk] || [];

  if (!dayRows.length) {
    log('  Nenhuma OB encontrada para ' + item.dateBR, 'err');
    await skipAndNext(state);
    return;
  }

  var pdfBlob = generatePDF(item.dateBR, dayRows, parsed.headers);
  if (!pdfBlob) { await skipAndNext(state); return; }
  log('  PDF gerado: ' + dayRows.length + ' OBs em ' + item.dateBR, 'ok');

  // ── Preenche campo Assunto (número da OB) ─────────────────────────────────
  // O formulário "Inclusão de Documento em Subprocesso" tem o Assunto como <textarea>
  // e está em um iframe GeneXus (gxPopupLevel). Buscamos nele primeiro.
  log('  Preenchendo Assunto: ' + item.obNum);
  var assuntoEl = null;
  var allD = allDocs();
  // Prioriza o iframe da popup GeneXus
  allD.sort(function (a, b) {
    try { return /gxPopupLevel|GxPopup/i.test(b.location.href) ? 1 : -1; } catch (_) { return 0; }
  });
  for (var di = 0; di < allD.length; di++) {
    var d = allD[di];
    try {
      var lbls = d.querySelectorAll('td, th, label, span, b, div');
      for (var li = 0; li < lbls.length; li++) {
        if (!/^assunto:?$/i.test((lbls[li].textContent || '').trim())) continue;
        var parent = lbls[li].parentElement;
        var nextEl = lbls[li].nextElementSibling || (parent && parent.nextElementSibling);
        var inp = nextEl
          ? ((nextEl.tagName === 'TEXTAREA' || nextEl.tagName === 'INPUT') ? nextEl
             : nextEl.querySelector('textarea, input[type="text"]'))
          : null;
        if (inp && !inp.readOnly) { assuntoEl = inp; break; }
      }
      // Fallback: primeira textarea disponível (o campo Assunto é textarea no SILOMS)
      if (!assuntoEl) {
        var areas = d.querySelectorAll('textarea');
        for (var ai = 0; ai < areas.length; ai++) {
          if (!areas[ai].readOnly && !areas[ai].disabled) { assuntoEl = areas[ai]; break; }
        }
      }
    } catch (_) {}
    if (assuntoEl) break;
  }
  if (assuntoEl) { fill(assuntoEl, item.obNum); await delay(150); }
  else log('  Campo Assunto nao encontrado - continuando', 'warn');

  // ── Seta arquivo no input[type=file] via DataTransfer ────────────────────
  log('  Buscando campo de arquivo (#fileInput)...');
  var fileInput = null;
  var docs2 = allDocs();
  for (var di2 = 0; di2 < docs2.length; di2++) {
    var fi = docs2[di2].querySelector('#fileInput') || docs2[di2].querySelector('input[type="file"]');
    if (fi) { fileInput = fi; break; }
  }

  if (!fileInput) {
    var browseBtn = findEl('input[type="button"], button, label, a', 'Escolher', false)
                 || findEl('input[type="button"], button, label, a', 'Selecionar', false);
    if (browseBtn) {
      log('  Clicando "Escolher arquivo"...', 'info');
      try { browseBtn.click(); } catch (_) {}
      await delay(800);
      docs2 = allDocs();
      for (var di3 = 0; di3 < docs2.length; di3++) {
        var fi2 = docs2[di3].querySelector('#fileInput') || docs2[di3].querySelector('input[type="file"]');
        if (fi2) { fileInput = fi2; break; }
      }
    }
  }

  if (!fileInput) {
    log('  input[type=file] nao encontrado - nao foi possivel anexar', 'err');
    await skipAndNext(state);
    return;
  }

  var fileName = 'OB_' + item.dk + '.pdf';
  try {
    var base64PDF = await blobToBase64(pdfBlob);
    var setResp   = await gxSetFileBg('#fileInput', base64PDF, fileName);
    log('  Arquivo ' + fileName + ' setado via main-world: ' + (setResp.result || setResp.error || '?'), setResp.ok ? 'ok' : 'warn');
    if (!setResp.ok || setResp.result === 'not-found') {
      // Fallback: tenta direto do isolated world (pode não funcionar cross-world)
      var pdfFile = new File([pdfBlob], fileName, { type: 'application/pdf' });
      var dt = new DataTransfer();
      dt.items.add(pdfFile);
      fileInput.files = dt.files;
      log('  Fallback: arquivo definido no isolated world (sem change event)', 'warn');
    }
  } catch (e) {
    log('  Erro ao definir arquivo: ' + e.message, 'err');
    await skipAndNext(state);
    return;
  }
  await delay(800);   // aguarda GeneXus reconhecer o arquivo antes de submeter

  // ── Botão verde confirmar (#IMAGE2 / OKAY1.BMP) ────────────────────────────
  // Usa chrome.scripting (background, MAIN world) — bypassa CSP do SILOMS.
  log('  Aguardando #IMAGE2 (ate 8s)...');
  var greenBtn = await waitEl('#IMAGE2', null, 8000);
  if (!greenBtn) greenBtn = findEl('input[src*="OKAY1.BMP"]');

  if (greenBtn) {
    var gbDoc = ownerDoc(greenBtn);
    var docInfo = '?';
    try { docInfo = (gbDoc.location && gbDoc.location.href) || gbDoc.URL || '?'; } catch (_) {}
    log('  #IMAGE2 doc: ...' + docInfo.split('/').slice(-2).join('/'), 'info');

    log('  Clicando confirmar via background/main-world...');
    var confirmResp = await gxClickBg('#IMAGE2');
    var methodUsed = (confirmResp && confirmResp.result) || (confirmResp && confirmResp.error) || '?';
    log('  Metodo confirm: ' + methodUsed, 'info');

    if (methodUsed === 'not-found-in-frames' || !confirmResp.ok) {
      // Fallback: gxClick direto (Firefox ou se scripting falhar)
      gxClick(greenBtn, gbDoc);
    }

    // Se o clique funcionou via main-world, aguarda GeneXus processar (delay fixo).
    // Não esperar IMAGE2 desaparecer — GeneXus pode manter o elemento no DOM mesmo após salvar.
    if (confirmResp.ok && methodUsed !== 'not-found-in-frames') {
      await delay(3500);  // aguarda servidor processar o upload completo
      log('  Confirmado ✓ (main-world ok)', 'ok');
    } else {
      // Fallback: polling para detectar fechamento do popup
      log('  Aguardando popup fechar...', 'info');
      var popupWait = 0;
      while (popupWait < 10000) {
        await delay(500);
        popupWait += 500;
        if (!findEl('#IMAGE2') && !findEl('input[src*="OKAY1.BMP"]')) break;
      }
      if (popupWait >= 10000) {
        log('  Confirm automatico falhou — aguardando confirmacao manual (30s)...', 'warn');
        log('  >> Clique MANUALMENTE no botao verde no SILOMS <<', 'warn');
        var manualWait = 0;
        while (manualWait < 30000) {
          await delay(1000);
          manualWait += 1000;
          if (!findEl('#IMAGE2') && !findEl('input[src*="OKAY1.BMP"]')) break;
        }
        if (manualWait >= 30000) {
          log('  Sem confirmacao apos 40s — pulando NF ' + item.nf, 'err');
          await skipAndNext(state); return;
        }
        log('  Confirmado manualmente ✓', 'ok');
      } else {
        log('  Confirmado ✓ (popup fechou em ~' + popupWait + 'ms)', 'ok');
      }
    }
  } else {
    log('  Botao confirmar nao encontrado', 'warn');
    await delay(2000);
  }
  // ── Marca concluído e avança ──────────────────────────────────────────────
  var newResults = (state.results || []).concat([{
    nf: item.nf, obNum: item.obNum, dateBR: item.dateBR, ok: true
  }]);
  var nextIdx = state.current + 1;

  if (nextIdx >= state.queue.length) {
    var fs = Object.assign({}, state, { running: false, results: newResults, step: 'done' });
    await saveState(fs);
    await finalize(fs);
  } else {
    var ns = Object.assign({}, state, { current: nextIdx, results: newResults, step: 'list' });
    await saveState(ns);
    // Navega diretamente para a URL da lista salva (evita history.back() indo para arquivo local)
    if (ns.listUrl && ns.listUrl.includes('siloms.intraer')) {
      log('  Navegando de volta a lista: ' + ns.listUrl.split('?')[0], 'info');
      window.location.href = ns.listUrl;
      // Contexto JS será destruído na navegação — content script do próximo page retoma via storage (step=list)
    } else {
      // Fallback: IMAGE1 via background main-world
      log('  Voltando a lista (IMAGE1 via main-world)...');
      var voltarResp = await gxClickBg('#IMAGE1');
      log('  IMAGE1: ' + (voltarResp.result || voltarResp.error || '?'), 'info');
      if (!voltarResp.ok || voltarResp.result === 'not-found-in-frames') {
        var voltarBtn = findSairBtn(15)
                     || findEl('input[src*="SAIR1.BMP"]', null, true)
                     || findEl('a, input[type="button"], button, td', 'Voltar', true)
                     || findEl('a, input[type="button"], button, td', 'Gerenciamento de Recebimento', true);
        if (voltarBtn) gxClick(voltarBtn, ownerDoc(voltarBtn));
        else log('  Botao Voltar nao encontrado - navegue manualmente', 'warn');
      }
      await delay(2500);
      await execListPage(ns);
    }
  }
}

// Busca botão por padrão de src (imagem) ou texto
function findBtnByPattern(srcPattern, textPattern) {
  var docs = allDocs();
  for (var di = 0; di < docs.length; di++) {
    var d = docs[di];
    try {
      // Input[type=image] por src
      var imgs = d.querySelectorAll('input[type="image"], img[onclick]');
      for (var ii = 0; ii < imgs.length; ii++) {
        if (srcPattern.test((imgs[ii].src || '').toLowerCase())) return imgs[ii];
      }
      // Botão por texto
      var btns = d.querySelectorAll('input[type="button"], input[type="submit"], button, a');
      for (var bi = 0; bi < btns.length; bi++) {
        var t = (btns[bi].value || btns[bi].textContent || '').trim().toLowerCase();
        if (textPattern.test(t)) return btns[bi];
      }
    } catch (_) {}
  }
  return null;
}

async function skipAndNext(state) {
  var item = state.queue[state.current];
  var newResults = (state.results || []).concat([{
    nf: item.nf, obNum: item.obNum, dateBR: item.dateBR, ok: false
  }]);
  var nextIdx = state.current + 1;
  if (nextIdx >= state.queue.length) {
    var fs = Object.assign({}, state, { running: false, results: newResults, step: 'done' });
    await saveState(fs); await finalize(fs);
  } else {
    var ns = Object.assign({}, state, { current: nextIdx, results: newResults, step: 'list' });
    await saveState(ns);
    if (ns.listUrl && ns.listUrl.includes('siloms.intraer')) {
      window.location.href = ns.listUrl;
      // content script retoma via storage no próximo carregamento
    } else {
      var skipVoltarResp = await gxClickBg('#IMAGE1');
      if (!skipVoltarResp.ok || skipVoltarResp.result === 'not-found-in-frames') {
        var voltarBtn = findSairBtn(15)
                     || findEl('input[src*="SAIR1.BMP"]', null, true)
                     || findEl('a, input[type="button"], button, td', 'Voltar', true)
                     || findEl('a, input[type="button"], button, td', 'Recebimento', true);
        if (voltarBtn) gxClick(voltarBtn, ownerDoc(voltarBtn));
      }
      await delay(2500);
      await execListPage(ns);
    }
  }
}

// ── Finalização ───────────────────────────────────────────────────────────────

async function finalize(state) {
  log('━━ Concluido! ' + (state.results || []).length + ' itens processados.', 'ok');
  setSub('Concluido!');
  document.getElementById('__ob_prog__').style.display = 'none';

  var res = state.results || [];
  var nOk = res.filter(function (r) { return r.ok; }).length;
  var rows = res.map(function (r) {
    return '<tr><td style="padding:2px 5px;color:#94a3b8;font-size:10px">' + r.nf + '</td>' +
           '<td style="padding:2px 5px;color:#64748b;font-size:10px">' + r.obNum + '</td>' +
           '<td style="padding:2px 5px;color:#64748b;font-size:10px">' + r.dateBR + '</td>' +
           '<td style="padding:2px 5px;color:' + (r.ok ? '#4ade80' : '#f87171') + ';font-size:10px">' +
           (r.ok ? 'OK' : 'ERRO') + '</td></tr>';
  }).join('');

  var tbl = document.createElement('div');
  tbl.innerHTML =
    '<div style="color:#4ade80;font-size:11px;margin:6px 0 4px">&#x2705; ' + nOk + '/' + res.length + ' anexados:</div>' +
    '<table style="width:100%;border-collapse:collapse">' +
    '<tr><th style="text-align:left;color:#64748b;font-size:10px;padding:2px 5px">NF</th>' +
    '<th style="text-align:left;color:#64748b;font-size:10px;padding:2px 5px">OB</th>' +
    '<th style="text-align:left;color:#64748b;font-size:10px;padding:2px 5px">Data</th>' +
    '<th style="text-align:left;color:#64748b;font-size:10px;padding:2px 5px">Status</th></tr>' +
    rows + '</table>';
  if (logEl) { logEl.appendChild(tbl); logEl.scrollTop = logEl.scrollHeight; }
  await clearState();
}

// ── Detecta página atual ──────────────────────────────────────────────────────

function detectPage() {
  if (findEl('a, input, button, td, span', 'Upload Ordem Banc', false)) return 'upload';
  if (findEl('a, input, button, td, span', 'Ordem de Pagamento', false)) return 'record';
  if (findEl('option, select, td, th', 'Emissao de OB', false) ||
      findEl('option, select, td, th', 'Emissão de OB', false)) return 'list';
  return 'unknown';
}

// ── Entry point ───────────────────────────────────────────────────────────────

async function main() {
  var state = await readState();

  // Carrega UGE salva (pode ser '' se nunca configurada)
  var storedUGE = await new Promise(function (res) {
    chrome.storage.local.get(OB_UGE_KEY, function (d) { res(d[OB_UGE_KEY] || ''); });
  });
  selectedUGE = storedUGE;

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg.type !== 'GAPMN_OB_TOGGLE') return;
    var panel  = document.getElementById(PANEL_ID);
    var tabBtn = document.getElementById('__ob_tab__');
    if (!panel) { injectPanel(true); return; }
    if (panel.style.display === 'none') {
      panel.style.display = 'flex';
      if (tabBtn) tabBtn.style.display = 'none';
    } else {
      panel.style.display = 'none';
      if (tabBtn) tabBtn.style.display = 'flex';
    }
  });

  // Se não há automação e unidade ainda não foi configurada → seleção obrigatória
  if ((!state || !state.running) && !selectedUGE) {
    // Cria o painel e exibe a tela de seleção de unidade dentro dele
    injectPanel(false);
    var panelEl = document.getElementById(PANEL_ID);
    if (panelEl) {
      panelEl.style.display = 'flex';
      var tabBtn2 = document.getElementById('__ob_tab__');
      if (tabBtn2) tabBtn2.style.display = 'none';
      showUGESelection(panelEl, function (uge) {
        selectedUGE = uge;
        // Reconstrói o painel com a unidade definida
        panelEl.remove();
        var oldTab = document.getElementById('__ob_tab__');
        if (oldTab) oldTab.remove();
        injectPanel(false);
        var newPanel = document.getElementById(PANEL_ID);
        if (newPanel) { newPanel.style.display = 'flex'; }
        var tb = document.getElementById('__ob_tab__');
        if (tb) tb.style.display = 'none';
        log('Unidade configurada: ' + ugeLabel(uge) + ' (UGE ' + uge + ')', 'ok');
      });
    }
    return;
  }

  injectPanel(state && state.running);

  // Se não há automação rodando: carrega cache e mostra painel idle
  if (!state || !state.running) {
    var csvText = await loadCSV();
    if (csvText) {
      var parsed = parseOBData(csvText);
      if (parsed.rows.length) {
        obCache = {
          headers: parsed.headers,
          rows:    parsed.rows,
          nfIndex: buildNFIndex(parsed.rows, selectedUGE),
          groups:  groupByDate(parsed.rows, selectedUGE),
        };
        var sumEl = document.getElementById('__ob_summary__');
        if (sumEl) {
          sumEl.style.color = '#60a5fa';
          sumEl.textContent = parsed.rows.length + ' OBs em cache | ' +
            Object.keys(obCache.groups).length + ' dias | ' + ugeLabel(selectedUGE);
          var startBtn = document.getElementById('__ob_start__');
          if (startBtn) startBtn.style.display = '';
        }
        log('Dados em cache: ' + parsed.rows.length + ' OBs (' + ugeLabel(selectedUGE) + '). Pronto para iniciar.', 'ok');
      }
    } else {
      log('Extensao ativa. Cole o URL do CSV e clique em Carregar.');
    }
    return;
  }

  // Retoma automação interrompida por navegação
  document.getElementById('__ob_cfg__').style.display = 'none';
  document.getElementById('__ob_prog__').style.display = '';
  setProgress(state.current + 1, state.queue.length);

  // Recarrega cache
  var csvText2 = await loadCSV();
  if (csvText2) {
    var parsed2 = parseOBData(csvText2);
    obCache = {
      headers: parsed2.headers,
      rows:    parsed2.rows,
      nfIndex: buildNFIndex(parsed2.rows, selectedUGE),
      groups:  groupByDate(parsed2.rows, selectedUGE),
    };
  }

  var page = detectPage();
  log('Retomando: step=' + state.step + ' | pagina=' + page);

  // Roteamento estrito por state.step — não deixa detecção de página sobrescrever
  // (ex: "Upload Ordem Bancária" aparece no DOM mesmo com a aba fechada)
  if (state.step === 'done') {
    await finalize(state);
  } else if (state.step === 'upload') {
    await delay(500);
    await execUploadPage(state);
  } else if (state.step === 'record') {
    await delay(400);
    await execRecordPage(state);
  } else if (state.step === 'list') {
    if (page === 'list') {
      await delay(300);
      await execListPage(state);
    } else {
      log('Aguardando pagina de lista (step=list, pagina=' + page + ')', 'warn');
    }
  } else {
    log('Aguardando pagina correta (step=' + state.step + ', page=' + page + ')', 'warn');
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', main);
} else {
  setTimeout(main, 800);
}

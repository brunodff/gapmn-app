'use strict';

var OB_CSV_KEY    = 'gapmn_ob_csv';
var OB_URL_KEY    = 'gapmn_ob_url';
var OB_INICIO_KEY = 'gapmn_ob_inicio';

var DEFAULT_URL   = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSYIxDW5oNp456_qcsDBiMV9rCrsXXmgPuGK2mqis2_k203qcCUGG1omx7jjZ_JRTZjIQgnj-SHmFaX/pub?gid=1989241909&single=true&output=csv';
var DEFAULT_INICIO = '01/09/2026';

var urlEl    = document.getElementById('url');
var inicioEl = document.getElementById('inicio');
var statusEl = document.getElementById('status');
var loadBtn  = document.getElementById('load');
var panelBtn = document.getElementById('openPanel');

function setStatus(msg, cls) {
  statusEl.textContent = msg;
  statusEl.className = cls || '';
}

// Restaura valores salvos — usa predefinidos se não houver nada em storage
chrome.storage.local.get([OB_URL_KEY, OB_INICIO_KEY, OB_CSV_KEY], function (d) {
  urlEl.value    = d[OB_URL_KEY]    || DEFAULT_URL;
  inicioEl.value = (d[OB_INICIO_KEY] !== undefined && d[OB_INICIO_KEY] !== '')
                   ? d[OB_INICIO_KEY] : DEFAULT_INICIO;

  if (d[OB_CSV_KEY]) {
    var lines = (d[OB_CSV_KEY].match(/\n/g) || []).length;
    setStatus('Cache: ~' + lines + ' linhas. Clique para atualizar.', 'info');
  } else {
    setStatus('Sem cache. Clique em Carregar (sem VPN).', 'warn');
  }
});

// Carrega CSV via background service worker (evita bloqueio de redirect MV3)
loadBtn.onclick = function () {
  var url = urlEl.value.trim();
  if (!url) { setStatus('Cole a URL do CSV antes de carregar.', 'warn'); return; }

  setStatus('Carregando…', 'info');
  loadBtn.disabled = true;

  chrome.runtime.sendMessage({ type: 'GAPMN_FETCH_CSV', url: url }, function (resp) {
    if (chrome.runtime.lastError || !resp) {
      setStatus('Erro: ' + (chrome.runtime.lastError ? chrome.runtime.lastError.message : 'sem resposta'), 'err');
      loadBtn.disabled = false;
      return;
    }
    if (!resp.ok) {
      setStatus('Erro: ' + resp.error, 'err');
      loadBtn.disabled = false;
      return;
    }
    var csv = resp.text;
    var obj = {};
    obj[OB_CSV_KEY]    = csv;
    obj[OB_URL_KEY]    = url;
    obj[OB_INICIO_KEY] = inicioEl.value.trim();
    chrome.storage.local.set(obj, function () {
      var lines = (csv.match(/\n/g) || []).length;
      setStatus('Salvo! ' + lines + ' linhas em cache.', 'ok');
      loadBtn.disabled = false;
    });
  });
};

// Abre o painel no SILOMS (envia mensagem ao content script)
panelBtn.onclick = function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (!tabs || !tabs[0]) return;
    var url = tabs[0].url || '';
    if (!url.includes('siloms.intraer')) {
      setStatus('Esta aba não é do SILOMS. Navegue até o SILOMS primeiro.', 'warn');
      return;
    }
    chrome.tabs.sendMessage(tabs[0].id, { type: 'GAPMN_OB_TOGGLE' }, function () {
      window.close();
    });
  });
};

// =============================================================
//  GAPMN — OB Diária: Gmail → Google Sheets
//  Cole este arquivo no Apps Script da planilha mestre.
//  NÃO precisa ativar nenhum serviço avançado (Drive, etc).
// =============================================================

var SHEET_NAME     = 'OBs';
var EMAIL_QUERY    = 'subject:OB has:attachment filename:xlsx newer_than:2d';
var PROCESSED_PROP = 'ob_last_processed_id';

// ---------------------------------------------------------------
//  Ponto de entrada — rode manualmente ou via trigger diário
// ---------------------------------------------------------------
function atualizarOBsDiarias() {
  var threads = GmailApp.search(EMAIL_QUERY, 0, 10);
  if (!threads.length) {
    Logger.log('Nenhum e-mail OB encontrado.');
    return;
  }

  var props  = PropertiesService.getScriptProperties();
  var lastId = props.getProperty(PROCESSED_PROP) || '';
  var ss     = SpreadsheetApp.getActiveSpreadsheet();
  var sheet  = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

  var processado = false;

  for (var t = 0; t < threads.length; t++) {
    var messages = threads[t].getMessages();
    var msg   = messages[messages.length - 1]; // mensagem mais recente do thread
    var msgId = msg.getId();

    if (msgId === lastId) {
      Logger.log('E-mail já processado: ' + msgId);
      continue;
    }

    var attachments = msg.getAttachments();
    var xlsxBlob = null;
    for (var a = 0; a < attachments.length; a++) {
      var att  = attachments[a];
      var nome = att.getName().toLowerCase();
      if (nome.endsWith('.xlsx') || nome.endsWith('.xls')) {
        xlsxBlob = att;
        break;
      }
    }

    if (!xlsxBlob) {
      Logger.log('Thread sem anexo xlsx: ' + threads[t].getFirstMessageSubject());
      continue;
    }

    Logger.log('Processando: ' + xlsxBlob.getName());
    var rows = extrairLinhasDoXlsx(xlsxBlob);

    if (!rows || rows.length < 2) {
      Logger.log('Planilha vazia ou sem dados.');
      continue;
    }

    var existingData = sheet.getDataRange().getValues();
    var vazia = existingData.length === 0 ||
                (existingData.length === 1 && existingData[0].every(function(c){ return c === ''; }));

    if (vazia) {
      sheet.clearContents();
      sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
    } else {
      mergeRows(sheet, existingData, rows);
    }

    try {
      sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).setNumberFormat('DD/MM/YYYY');
    } catch(e) {}

    props.setProperty(PROCESSED_PROP, msgId);
    processado = true;
    Logger.log('Concluído. Linhas importadas: ' + (rows.length - 1));
    break; // processa apenas o e-mail mais recente
  }

  if (!processado) Logger.log('Nenhum e-mail novo processado.');
}

// ---------------------------------------------------------------
//  Converte blob xlsx → array de arrays via Drive REST API v3
//  Não requer serviço avançado — usa UrlFetchApp com OAuth token
// ---------------------------------------------------------------
function extrairLinhasDoXlsx(blob) {
  var token    = ScriptApp.getOAuthToken();
  var boundary = 'gapmn_ob_' + Date.now();

  // Metadados: pede conversão para Google Sheets via mimeType
  var meta = JSON.stringify({
    name: 'OB_temp_' + Date.now(),
    mimeType: 'application/vnd.google-apps.spreadsheet'
  });

  // Corpo multipart: [metadata] + [arquivo xlsx]
  var frontStr = '--' + boundary + '\r\n' +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    meta + '\r\n' +
    '--' + boundary + '\r\n' +
    'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n\r\n';
  var endStr = '\r\n--' + boundary + '--';

  // Concatena bytes: header + xlsx + footer
  var body = [].concat(
    Utilities.newBlob(frontStr).getBytes(),
    blob.copyBlob().getBytes(),
    Utilities.newBlob(endStr).getBytes()
  );

  var resp = UrlFetchApp.fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
    {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'multipart/related; boundary=' + boundary
      },
      payload: body,
      muteHttpExceptions: true
    }
  );

  var result = JSON.parse(resp.getContentText());
  if (!result.id) {
    Logger.log('Erro no upload/conversão: ' + resp.getContentText());
    return null;
  }

  var convertedId = result.id;
  try {
    var tempSS     = SpreadsheetApp.openById(convertedId);
    var firstSheet = tempSS.getSheets()[0];
    return firstSheet.getDataRange().getValues();
  } finally {
    try { DriveApp.getFileById(convertedId).setTrashed(true); } catch(e) {}
  }
}

// ---------------------------------------------------------------
//  Merge: adiciona apenas linhas com data+OB ainda não presentes
// ---------------------------------------------------------------
function mergeRows(sheet, existingData, newRows) {
  if (newRows.length < 2) return;

  var existingKeys = {};
  for (var i = 1; i < existingData.length; i++) {
    var r = existingData[i];
    existingKeys[String(r[0]) + '|' + String(r[1])] = true;
  }

  var toAdd = [];
  for (var j = 1; j < newRows.length; j++) {
    var nr  = newRows[j];
    var key = String(nr[0]) + '|' + String(nr[1]);
    if (!existingKeys[key]) toAdd.push(nr);
  }

  if (toAdd.length > 0) {
    var lastRow = sheet.getLastRow();
    sheet.getRange(lastRow + 1, 1, toAdd.length, newRows[0].length).setValues(toAdd);
    Logger.log('Linhas adicionadas: ' + toAdd.length);
  } else {
    Logger.log('Nenhuma linha nova para adicionar.');
  }
}

// ---------------------------------------------------------------
//  Cria trigger diário (rode UMA VEZ manualmente)
// ---------------------------------------------------------------
function criarTriggerDiario() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'atualizarOBsDiarias') {
      ScriptApp.deleteTrigger(triggers[i]);
    }
  }
  ScriptApp.newTrigger('atualizarOBsDiarias')
    .timeBased().everyDays(1).atHour(7).create();
  Logger.log('Trigger diário criado: 07:00 todos os dias.');
}

// ---------------------------------------------------------------
//  Reseta flag para forçar reprocessar o e-mail mais recente
// ---------------------------------------------------------------
function resetarUltimoProcessado() {
  PropertiesService.getScriptProperties().deleteProperty(PROCESSED_PROP);
  Logger.log('Flag resetada. Próxima execução reprocessará o e-mail mais recente.');
}

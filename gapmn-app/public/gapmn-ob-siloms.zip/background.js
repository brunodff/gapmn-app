'use strict';

// Faz fetch de URLs externas pelo service worker (evita bloqueio de redirect no popup MV3)
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg.type !== 'GAPMN_FETCH_CSV') return;
  fetch(msg.url, { credentials: 'omit' })
    .then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    })
    .then(function (text) { sendResponse({ ok: true, text: text }); })
    .catch(function (e)   { sendResponse({ ok: false, error: e.message }); });
  return true; // mantém canal aberto para resposta assíncrona
});

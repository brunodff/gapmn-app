'use strict';

// Faz fetch de URLs externas pelo service worker (evita bloqueio de redirect no popup MV3)
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {

  // ── Fetch CSV ──────────────────────────────────────────────────────────────
  if (msg.type === 'GAPMN_FETCH_CSV') {
    fetch(msg.url, { credentials: 'omit' })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then(function (text) { sendResponse({ ok: true, text: text }); })
      .catch(function (e)   { sendResponse({ ok: false, error: e.message }); });
    return true;
  }

  // ── Clica elemento via chrome.scripting (bypassa CSP do site) ─────────────
  // Roda no MAIN world da página (não no isolated world do content script)
  // → tem acesso a gx.evt.execCliEvt, gx.evt.execEvt, etc.
  if (msg.type === 'GAPMN_CLICK_GX') {
    if (!chrome.scripting) {
      sendResponse({ ok: false, error: 'chrome.scripting nao disponivel' });
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id, allFrames: true },
      world:  'MAIN',
      func:   function (selector) {
        var el = document.querySelector(selector);
        if (!el) return null; // não é este frame

        // Patch gx.evt.jsEvent em window/parent/top → sempre true
        var rests = [];
        function patchW(w) {
          try {
            if (w && w.gx && w.gx.evt && w.gx.evt.jsEvent) {
              var p = w.gx.evt.jsEvent;
              w.gx.evt.jsEvent = function () { return true; };
              rests.push(function () { w.gx.evt.jsEvent = p; });
            }
          } catch (_) {}
        }
        patchW(window);
        try { patchW(parent); } catch (_) {}
        try { patchW(top);    } catch (_) {}

        // Forja window.event com isTrusted=true
        var evtForjado = false;
        try {
          Object.defineProperty(window, 'event', {
            get: function () {
              return { isTrusted: true, type: 'click', target: el, currentTarget: el };
            },
            configurable: true
          });
          evtForjado = true;
        } catch (_) {}

        // Executa onclick com this=el (jsEvent já retorna true)
        var oc = el.getAttribute('onclick') || '';
        var method = 'none';
        try {
          /* jshint ignore:start */
          (new Function(oc)).call(el); // eslint-disable-line no-new-func
          /* jshint ignore:end */
          method = 'onclick-mainworld';
          console.log('[OB] main-world click OK:', selector);
        } catch (e) {
          console.error('[OB] main-world click err:', selector, e);
          try { el.click(); method = 'click-mainworld'; } catch (e2) { method = 'failed'; }
        }

        // Restaura
        rests.forEach(function (r) { try { r(); } catch (_) {} });
        if (evtForjado) { try { delete window.event; } catch (_) {} }

        return method;
      },
      args: [msg.selector]
    }, function (results) {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      var found = (results || []).find(function (r) { return r && r.result; });
      sendResponse({ ok: true, result: found ? found.result : 'not-found-in-frames' });
    });
    return true; // mantém canal aberto para resposta assíncrona
  }

  // ── Seta arquivo em input[type=file] via MAIN world (visível ao GeneXus) ─────
  if (msg.type === 'GAPMN_SET_FILE') {
    if (!chrome.scripting) {
      sendResponse({ ok: false, error: 'chrome.scripting nao disponivel' });
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id, allFrames: true },
      world:  'MAIN',
      func:   function (selector, base64, fileName, mimeType) {
        var el = document.querySelector(selector);
        if (!el) return null;
        var binary = atob(base64);
        var bytes  = new Uint8Array(binary.length);
        for (var i = 0; i < binary.length; i++) { bytes[i] = binary.charCodeAt(i); }
        var blob = new Blob([bytes], { type: mimeType });
        var file = new File([blob], fileName, { type: mimeType });
        var dt   = new DataTransfer();
        dt.items.add(file);
        el.files = dt.files;
        // Não dispara change/input — evita que validaPdf() navegue para documento anterior.
        // GeneXus lê fileInput.files[0] diretamente na submissão via IMAGE2.
        console.log('[OB] file set in main world (silent):', fileName, 'size:', file.size);
        return 'file-set:' + fileName;
      },
      args: [msg.selector, msg.base64, msg.fileName, msg.mimeType]
    }, function (results) {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      var found = (results || []).find(function (r) { return r && r.result; });
      sendResponse({ ok: true, result: found ? found.result : 'not-found' });
    });
    return true;
  }
});

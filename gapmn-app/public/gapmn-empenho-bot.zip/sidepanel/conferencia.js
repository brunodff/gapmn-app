/**
 * Conferência da solicitação na revisão: o que já dá para saber, antes de
 * iniciar, que vai travar o robô no CNET (nível 'erro') ou merece atenção
 * ('aviso'). Só regras sobre os dados lidos — sem acesso a páginas.
 *
 * Cada regra espelha o que a etapa correspondente do robô exige:
 *   Etapa 1 — compra (nº, modalidade, UASG) ou contrato (nº e, de preferência, ano)
 *   Etapa 2 — CNPJ do fornecedor
 *   Etapas 3 e 5 — N.Item, quantidade e valor de cada item
 *   Etapa 4 — linha de crédito: PTRES, Fonte e ND (sem eles pega a linha errada)
 */

const dig = s => String(s ?? '').replace(/\D/g, '');
// "1.234,56" / "1234,56" (BR) ou "1234.5600" (ponto decimal, como vem dos itens)
const num = s => {
  const t = String(s ?? '').trim().replace(/\s/g, '');
  if (!t) return NaN;
  return t.includes(',') ? parseFloat(t.replace(/\./g, '').replace(',', '.')) : parseFloat(t);
};
const fmtV = v => v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function cnpjValido(c) {
  if (!/^\d{14}$/.test(c) || /^(\d)\1{13}$/.test(c)) return false;
  const dv = n => {
    let s = 0, p = n - 7;
    for (let i = 0; i < n; i++) { s += +c[i] * p--; if (p < 2) p = 9; }
    return s % 11 < 2 ? 0 : 11 - (s % 11);
  };
  return dv(12) === +c[12] && dv(13) === +c[13];
}

/** NE no formato do SIAFI (2026NE000552); aceita "NE552" / "552" e completa com o ano. */
export function normalizarNE(s, ano = new Date().getFullYear()) {
  const m = /(?:(\d{4})\s*)?NE\s*0*(\d{1,6})\b|^\s*0*(\d{1,6})\s*$/i.exec(String(s ?? '').trim());
  if (!m) return '';
  return `${m[1] ?? ano}NE${String(m[2] ?? m[3]).padStart(6, '0')}`;
}

/**
 * Reforço / anulação de empenho já emitido: o robô vai direto à minuta da NE
 * (Alterar Empenho) — contrato, fornecedor e linha de crédito não são escolhidos.
 * Valem a NE a alterar, os itens e o valor.
 */
function problemasDaAlteracao(sol) {
  const p = [];
  const erro = texto => p.push({ nivel: 'erro', texto });
  const aviso = texto => p.push({ nivel: 'aviso', texto });
  const itens = sol.itensEmpenho ?? [];
  const nome = sol.operacao === 'anulacao' ? 'anulação' : 'reforço';

  if (!sol.neAlterar) erro(`Informe a NE a ${sol.operacao === 'anulacao' ? 'anular' : 'reforçar'} (ex: 2026NE000552) — ela não vem no PDF`);
  else if (!/^\d{4}NE\d{6}$/.test(sol.neAlterar)) erro(`NE "${sol.neAlterar}" fora do formato (ex: 2026NE000552)`);
  else if (+sol.neAlterar.slice(0, 4) < new Date().getFullYear()) {
    aviso(`A ${sol.neAlterar} é de ${sol.neAlterar.slice(0, 4)} (restos a pagar): a alteração de RP costuma ser feita no SIAFI Web — se o CNET não oferecer o "Tipo Operação", o robô para e avisa`);
  }

  const total = num(sol.total);
  const soma = itens.reduce((s, it) => s + (num(it.valor) || 0), 0);
  if (!(total > 0) && !(soma > 0)) erro(`Valor da ${nome} não encontrado no PDF`);
  const daObs = num(sol.valorOperacao);
  if (daObs > 0 && total > 0 && Math.abs(daObs - total) > 0.01) {
    aviso(`A OBS fala em R$ ${fmtV(daObs)}, mas o TOTAL é R$ ${fmtV(total)} — confira o valor da ${nome}`);
  }
  if (itens.length > 1 && itens.some(it => !dig(it.numeroItem))) {
    erro('Mais de um item: informe o N.Item de cada um (é o "Número" do item na NE)');
  } else if (itens.length === 1 && !dig(itens[0].numeroItem)) {
    aviso('Item sem N.Item: vale se a NE tiver um único item; se tiver mais, o robô para e pede o número');
  }
  if (sol.operacao === 'reforco' && !dig(sol.fornecedorCnpj)) aviso('CNPJ do fornecedor não lido — sem ele as certidões do reforço não são conferidas');
  if (sol._deduzidos?.operacao) aviso(`Tipo (${nome}) deduzido pela OBS — confira`);
  if (!sol.solicitacao) aviso('Número da solicitação não lido');
  return p;
}

/** Lista de { nivel: 'erro' | 'aviso', texto } da solicitação. */
export function problemasDaSolicitacao(sol) {
  const p = [];
  if (!sol?.ok) return p;
  if (sol.operacao) return problemasDaAlteracao(sol);
  const erro = texto => p.push({ nivel: 'erro', texto });
  const aviso = texto => p.push({ nivel: 'aviso', texto });
  const compra = sol.tipoOrigem === 'compra';
  const itens = sol.itensEmpenho ?? [];

  // ── Fornecedor (Etapa 2 escolhe pelo CNPJ) ──
  const cnpj = dig(sol.fornecedorCnpj);
  if (!cnpj) erro('CNPJ do fornecedor não lido no PDF — informe em "Ver / editar campos"');
  else if (!cnpjValido(cnpj)) erro(`CNPJ do fornecedor inválido (${sol.fornecedorCnpj}) — confira`);
  else if (cnpj.startsWith('00394429')) erro('O CNPJ é do Comando da Aeronáutica (o comprador), não do fornecedor — corrija');

  // ── Contrato ou compra (Etapa 1) ──
  if (compra) {
    if (!/^\d{4,6}\/\d{4}$/.test(String(sol.numeroCompra ?? '').trim())) erro('Número da compra não encontrado no PDF (ex: 90063/2025)');
    if (!sol.modalidade) erro('Modalidade da compra não informada');
    else if (sol._deduzidos?.modalidade) aviso(`Modalidade deduzida pelo número da compra (${sol.modalidade}) — confira`);
    if (!String(sol.unidadeCompra ?? '').trim()) erro('Unidade (UASG) da compra não informada');
  } else {
    const c = String(sol.contrato ?? '').trim();
    const n = /^\d+/.exec(c)?.[0];
    if (!n) erro('Número do contrato não encontrado no PDF — informe em Contrato (ex: 028/2024) ou mude o Tipo para Compra');
    else if (!/^\d+\/\d{4}$/.test(c)) {
      aviso(sol.credenciamento
        ? `Credenciamento nº ${n} sem o ano no PDF — o robô pesquisa ${20000 + parseInt(n, 10)}/2 no CNET e escolhe pelo CNPJ do fornecedor; se ele tiver mais de um credenciamento nº ${n}, informe o ano (ex: ${n}/2025)`
        : `Ano do contrato não encontrado no PDF (lido: ${c}) — o robô escolhe pelo CNPJ do fornecedor; se ele tiver mais de um contrato nº ${n}, informe o ano (ex: ${n}/2024)`);
    }
    const k = sol._cnetContrato;
    if (k?.estado === 'erro') erro(`CNET: ${k.texto}`);
  }

  // ── Itens (Etapas 3 e 5) ──
  if (!itens.length) {
    if (compra) erro('Itens não identificados no PDF — informe N.Item, Qtd e valor de cada item');
    else aviso('Itens não identificados no PDF — com um único item no contrato o robô usa o TOTAL; com mais de um, ele para. Informe N.Item e valor');
  } else {
    itens.forEach((it, i) => {
      const rot = dig(it.numeroItem) ? `Item ${it.numeroItem}` : `${i + 1}º item`;
      if (compra) {
        if (!dig(it.numeroItem)) erro(`${rot}: sem N.Item (nº da coluna ITEM do PDF) — numa compra o robô não sabe qual marcar`);
        if (!(num(it.quantidade) > 0) && !(num(it.valor) > 0)) erro(`${rot}: sem quantidade nem valor`);
      } else if (!(num(it.valor) > 0)) {
        erro(`${rot}: sem valor a empenhar`);
      }
    });
    if (!compra && itens.length > 1 && itens.some(it => !dig(it.numeroItem))) erro('Contrato com mais de um item: informe o N.Item de cada um');
    const nums = itens.map(it => parseInt(dig(it.numeroItem), 10)).filter(x => !Number.isNaN(x));
    if (new Set(nums).size < nums.length) aviso('N.Item repetido entre os itens — confira');
    const total = num(sol.total);
    const soma = itens.reduce((s, it) => s + (num(it.valor) || 0), 0);
    // TOTAL tirado da própria soma dos itens: comparar seria a soma com ela mesma
    if (sol._deduzidos?.total) {
      if (sol.itensDaDescricao) erro('TOTAL da solicitação não lido no PDF — não dá para conferir a soma dos itens; preencha o campo Total com o valor do PDF');
    } else if (total > 0 && soma > 0 && Math.abs(soma - total) > 0.01) {
      const msg = `Soma dos itens (R$ ${fmtV(soma)}) diferente do TOTAL (R$ ${fmtV(total)})`;
      // Itens escritos na descrição: a soma TEM de dar o TOTAL; diferença é valor
      // cortado/mal lido no PDF e empenharia errado
      if (sol.itensDaDescricao) erro(`${msg} — itens lidos da descrição (${itens.length}); algum valor pode ter sido cortado no PDF. Corrija os itens`);
      else aviso(`${msg} — confira os itens`);
    }
    if (sol._deduzidos?.itensCalculados) aviso('Valor total de algum item não estava legível; calculei unitário × quantidade — confira');
    if (sol._deduzidos?.itensUnitario) aviso('Na descrição, o valor de cada item é o unitário: calculei o total de cada um (quantidade × unitário; a soma bate com o TOTAL) — confira');
    if (sol._deduzidos?.itensDivergentes?.length) {
      aviso(`Item ${sol._deduzidos.itensDivergentes.join(', ')}: valor total ≠ unitário × quantidade no PDF — confira`);
    }
  }

  // ── Valor ──
  if (!(num(sol.total) > 0) && !itens.some(it => num(it.valor) > 0)) erro('Valor total não encontrado no PDF');
  else if (sol._deduzidos?.total && !sol.itensDaDescricao) aviso('TOTAL não legível no PDF; usei a soma dos itens — confira');

  // ── Linha de crédito (Etapa 4) ──
  const faltam = [['PTRES', sol.ptres], ['Fonte', sol.fonte], ['ND', sol.nd]].filter(([, v]) => !dig(v)).map(([nome]) => nome);
  if (faltam.length) erro(`Linha de crédito incompleta: falta ${faltam.join(', ')} — sem isso o robô pode marcar a linha errada`);
  else if (dig(sol.nd).length !== 6) erro(`ND "${sol.nd}" inválida — precisa de 6 dígitos (ex: 339039)`);
  const semOpcionais = [['PI', sol.pi], ['UG Cred', sol.ugCred]].filter(([, v]) => !String(v ?? '').trim()).map(([nome]) => nome);
  if (semOpcionais.length) aviso(`${semOpcionais.join(' e ')} não lido(s) — a linha de crédito será escolhida sem ${semOpcionais.length > 1 ? 'eles' : 'ele'}; confira`);
  if (sol._deduzidos?.ugCred) aviso(`UG Cred ${sol.ugCred} deduzida (estava longe do rótulo no PDF) — confira`);
  if (sol._deduzidos?.credito) {
    aviso(`Crédito lido de valores separados dos rótulos no PDF (ND ${sol.nd || '—'}, PTRES ${sol.ptres || '—'}, Fonte ${sol.fonte || '—'}, PI ${sol.pi || '—'}) — confira`);
  }

  // ── Demais ──
  if (!dig(sol.subelemento) && !itens.some(it => dig(it.subelemento))) aviso('Subelemento não lido — o CNET fica com o padrão do item');
  if (!sol.solicitacao) aviso('Número da solicitação não lido — a descrição do empenho fica sem a referência');
  if (!sol.pag) aviso('Número do processo (PAG) não lido');
  // Vai para o campo "Local de Entrega" da Etapa 6
  const local = String(sol.localEntrega ?? '').trim();
  if (!local || local.includes(':') || /\d{3,}/.test(local)) aviso(`Local de entrega não identificado no PDF${local ? ` (lido: "${local.slice(0, 40)}")` : ''} — confira`);

  return p;
}

export const temErro = sol => problemasDaSolicitacao(sol).some(p => p.nivel === 'erro');

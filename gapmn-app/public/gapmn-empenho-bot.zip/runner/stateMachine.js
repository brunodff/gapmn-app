/**
 * Máquina de estados — GAPMN Empenho Bot v2.0
 *
 * Dois fluxos:
 *   1. COLETA: Navega no SILOMS, coleta todas as solicitações assinadas (comum a ambos os modos)
 *   2. EMPENHO-CNET: Preenche minuta no Contratos.gov.br (8 etapas existentes)
 *   2b. EMPENHO-SILOMS: (Phase 3 — a implementar)
 *   3. ALTERACAO-CNET: reforço/anulação de NE já emitida e os "irrisórios" que
 *      completam o arredondamento (altStep 0-4; ver runner/steps/alteracao.js)
 *
 * Estado persistido em chrome.storage.local (chave: STORAGE_KEY):
 *   state          = 'idle' | 'running' | 'paused' | 'checkpoint' | 'done' | 'error'
 *   flow           = null | 'coleta' | 'empenho-cnet' | 'empenho-siloms'
 *   mode           = null | 'siloms' | 'contratosgov'   (escolha do usuário)
 *   coletaPhase    = 'navegar' | 'filtrar' | 'lista' | 'detalhe' | 'done'
 *   coletaIndex    = number   (solicitação atual sendo processada)
 *   coletaTotal    = number
 *   solicitacoes   = []       (lista básica da tabela)
 *   solDetalhes    = []       (dados completos de cada uma)
 *   step           = 0-8      (0=pré-navegação minuta→etapa1; 1-8=etapas CNET)
 *   payload        = object   (solicitação atual em empenho)
 *   queue          = []
 *   log            = []
 *   silomsTabId    = number
 *   cnetTabId      = number
 *   dryRun         = boolean
 */

import { step1Runner } from './steps/step1.js';
import { step3Runner } from './steps/step3.js';
import { maximizarTabelasRunner } from './steps/tabelas.js';
import { step4Runner } from './steps/step4.js';
import { step5Runner } from './steps/step5.js';
import { step6Runner } from './steps/step6.js';
import {
  paginaMinutas, buscarNEnaLista, removerFiltros, adicionarAlteracao,
  alteracaoSubelementoRunner, alteracaoPassivo, lerListaAlteracoes, telaSubelementoAlteracao,
} from './steps/alteracao.js';
import {
  step0ClickAdicionarMinuta,
  step0PesquisarContrato,
  step0SelecionarContrato,
} from './steps/step0.js';
import {
  silomsCheckListPage,
  silomsClickMenuEmpenho,
  silomsClickSubmenu,
  silomsSetFiltroEBuscar,
  silomsParseListaSolicitacoes,
  silomsAbrirSolicitacao,
  silomsExtrairDocumento,
  silomsVoltar,
} from './steps/step-siloms-coleta.js';

const STORAGE_KEY = 'empenhoBot';
const COMPRASNET_URL = 'https://contratos.comprasnet.gov.br/empenho/buscacompra';
// Lista de minutas (palpite: o robô prefere o link do menu da própria tela)
const MINUTAS_URL = 'https://contratos.comprasnet.gov.br/empenho/minuta';
// Empenhos emitidos (solicitação → NE), guardados entre execuções
export const REGISTRO_KEY = 'empenhosGerados';
// Painel: "parar para confirmar antes de emitir" (desligado = emite sozinho)
const CONFIRMAR_ANTES_KEY = 'empenhoConfirmarAntes';

// ── Persistência ──────────────────────────────────────────────────────────────

export async function getState() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  return data[STORAGE_KEY] ?? {
    state: 'idle', flow: null, mode: null,
    coletaPhase: null, coletaIndex: 0, coletaTotal: 0,
    solicitacoes: [], solDetalhes: [],
    step: 0, payload: null, queue: [], log: [],
    silomsTabId: null, cnetTabId: null, dryRun: false,
  };
}

export async function setState(patch) {
  const current = await getState();
  await chrome.storage.local.set({ [STORAGE_KEY]: { ...current, ...patch } });
}

export async function appendLog(msg, level = 'info') {
  const s = await getState();
  const log = [...(s.log ?? []), { ts: Date.now(), msg, level }];
  await setState({ log: log.slice(-200) });
}

// Grava no histórico e mostra na hora no painel
async function logVisivel(msg, level = 'info') {
  await appendLog(msg, level);
  notifySidePanel({ type: 'LOG', msg, level });
}

// ── Execução na página ────────────────────────────────────────────────────────

async function execInPage(tabId, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, allFrames: false },
    world: 'MAIN',
    func,
    args,
  });
  return results?.[0]?.result ?? null;
}

async function waitForNavigation(tabId, timeout = 25000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('waitForNavigation timeout'));
    }, timeout);

    function listener(tId, changeInfo) {
      if (tId === tabId && changeInfo.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function delay(ms) { await new Promise(r => setTimeout(r, ms)); }

// ── CNET lento ────────────────────────────────────────────────────────────────
// Sobrecarregado, o CNET leva às vezes bem mais que 20 s para trazer uma tela ou uma
// tabela. O robô não desiste por isso: espera até ESPERA_MAX_CNET, avisa no log a
// cada 20 s e, se a tabela não vier em 2 min, recarrega a tela uma vez (a busca
// AJAX pode ter se perdido).
const ESPERA_MAX_CNET = 5 * 60 * 1000;
const AVISO_CNET_LENTO = 20000;
const segDesde = t => Math.round((Date.now() - t) / 1000);

// A aba ainda está carregando a próxima tela: espera, sem clicar de novo
async function esperarAbaCarregar(tabId, etapa, desde = Date.now(), maxMs = ESPERA_MAX_CNET) {
  let aviso = Date.now() + AVISO_CNET_LENTO;
  for (;;) {
    const aba = await chrome.tabs.get(tabId).catch(() => null);
    if (!aba || aba.status !== 'loading') return true;
    if (Date.now() - desde > maxMs) return false;
    if (Date.now() >= aviso) {
      await logVisivel(`⏳ [Etapa ${etapa}] O CNET está lento — esperando a tela carregar (${segDesde(desde)} s)…`, 'warn');
      aviso += AVISO_CNET_LENTO;
    }
    await delay(1000);
  }
}

// Página (mundo MAIN): a tabela da etapa já tem linhas? "ocioso" = página carregada,
// sem "Processando…" e sem pedido AJAX em andamento
function sondaTabela(tipo) {
  const visivel = e => !!e && e.getClientRects().length > 0 && getComputedStyle(e).display !== 'none';
  const fora = e => !!e.closest('.modal, #inserir_celular_orcamentaria');
  const SEL = {
    etapa1: '#opc_compra, #opc_contrato',
    fornecedores: 'a[selecionar], a[title*="Selecionar"], a[href*="/empenho/item/"]',
    itens: 'table tbody input[type="checkbox"]:not(#selectAll)',
    creditos: 'table tbody tr input[type="radio"]',
    subelementos: 'table tbody tr select',
  };
  const n = Array.from(document.querySelectorAll(SEL[tipo] ?? 'table tbody tr')).filter(e => !fora(e)).length;
  const processando = Array.from(document.querySelectorAll('.dataTables_processing')).some(visivel);
  const vazioTd = Array.from(document.querySelectorAll('td.dataTables_empty')).find(e => !fora(e));
  const carregandoTxt = /carregando|processando|loading|processing|aguarde/i.test(vazioTd?.textContent ?? '');
  const ocioso = document.readyState === 'complete' && !processando && !carregandoTxt && !((window.jQuery || window.$)?.active > 0);
  return { pronto: n > 0 || (!!vazioTd && ocioso), vazio: n === 0, ocioso, url: location.href };
}

// ── Próxima tela ──────────────────────────────────────────────────────────────
// A aba só sai de "carregando" quando TUDO da página termina (imagens, scripts de
// terceiros): no CNET isso chegou a levar 50 s com a tela já pronta. A próxima tela é
// reconhecida pela identidade do documento (performance.timeOrigin muda a cada página)
// e vale assim que o HTML estiver montado.
function idDoDocumento(tabId) {
  return comLimite(execInPage(tabId, () => String(performance.timeOrigin) + '|' + location.href), 3000);
}
function sondaTela() {
  const $ = window.jQuery || window.$;
  return {
    id: String(performance.timeOrigin) + '|' + location.href,
    pronto: document.readyState !== 'loading',
    ocupado: !!($ && $.active > 0),
  };
}
/**
 * Espera a tela trocar depois de um clique; idAntes = documento de antes do clique.
 *   'navegou' — tela nova montada            'aviso'  — aviso de arredondamento aberto (comAviso)
 *   'parado'  — mesma tela, nada carregando há 10 s (o clique não levou a lugar nenhum)
 *   'tempo'   — passou do limite (5 min)
 */
async function esperarNovaTela(tabId, idAntes, etapa, { comAviso = false, desde = Date.now(), maxMs = ESPERA_MAX_CNET } = {}) {
  let aviso = desde + AVISO_CNET_LENTO, paradoDesde = null;
  for (;;) {
    const s = await comLimite(execInPage(tabId, sondaTela), 3000);
    if (s && idAntes && s.id !== idAntes && s.pronto) return 'navegou';
    if (comAviso && s && s.id === idAntes && await comLimite(execInPage(tabId, avisoArredondamentoAberto), 2500) === true) return 'aviso';
    const aba = await chrome.tabs.get(tabId).catch(() => null);
    // Parado: mesma tela (ou página sem resposta, ex.: alert), aba sem carregar e sem AJAX
    const parado = aba?.status !== 'loading' && (!s || (s.id === idAntes && !s.ocupado));
    paradoDesde = parado ? paradoDesde ?? Date.now() : null;
    if (paradoDesde && Date.now() - paradoDesde > (s ? 10000 : 15000)) return 'parado';
    if (Date.now() - desde > maxMs) return 'tempo';
    if (Date.now() >= aviso) {
      await logVisivel(`⏳ [Etapa ${etapa}] O CNET está lento — esperando a próxima tela (${segDesde(desde)} s)…`, 'warn');
      aviso += AVISO_CNET_LENTO;
    }
    await delay(400);
  }
}

// Espera a tabela da etapa ter linhas (ou o CNET dizer que não há nenhuma)
async function esperarTabela(tabId, etapa, tipo, oQue) {
  const ini = Date.now();
  let aviso = ini + AVISO_CNET_LENTO, recarregou = false, ociosoDesde = null, semResposta = null;
  for (;;) {
    const s = await comLimite(execInPage(tabId, sondaTabela, [tipo]), 8000);
    if (s?.pronto) {
      if (Date.now() - ini > AVISO_CNET_LENTO) await logVisivel(`[Etapa ${etapa}] ${oQue} carregaram depois de ${segDesde(ini)} s`, 'info');
      return { ok: true, vazio: s.vazio };
    }
    if (RX_SESSAO.test(s?.url ?? '')) return { ok: false, error: 'a sessão do CNET expirou' };
    // Página parada, sem nada carregando, há 15 s: não vai vir mais nada — a etapa decide
    ociosoDesde = s?.ocioso ? ociosoDesde ?? Date.now() : null;
    if (ociosoDesde && Date.now() - ociosoDesde > 15000) return { ok: true, vazio: true };
    // Sem resposta da página (alert do CNET, ex.: "Ajax error") há 30 s com a aba parada
    const aba = await chrome.tabs.get(tabId).catch(() => null);
    semResposta = !s && aba?.status === 'complete' ? semResposta ?? Date.now() : null;

    const passou = Date.now() - ini;
    if (passou > ESPERA_MAX_CNET) {
      return { ok: false, error: `o CNET não trouxe ${oQue} em ${Math.round(passou / 60000)} min (site sobrecarregado?) — tente esta solicitação de novo mais tarde` };
    }
    if (!recarregou && aba?.url && (passou > 120000 || (semResposta && Date.now() - semResposta > 30000))) {
      recarregou = true;
      await logVisivel(`⚠ [Etapa ${etapa}] ${oQue} não vieram em ${segDesde(ini)} s — recarregando a tela do CNET…`, 'warn');
      const nav = waitForNavigation(tabId, 60000).then(() => true, () => false);
      try { await chrome.tabs.update(tabId, { url: aba.url }); } catch { /* segue esperando */ }
      await nav;
      await esperarAbaCarregar(tabId, etapa);
      ociosoDesde = semResposta = null;
      continue;
    }
    if (Date.now() >= aviso) {
      await logVisivel(`⏳ [Etapa ${etapa}] O CNET está lento — esperando ${oQue} (${segDesde(ini)} s)…`, 'warn');
      aviso += AVISO_CNET_LENTO;
    }
    await delay(1500);
  }
}

// ── API pública ───────────────────────────────────────────────────────────────

/**
 * Inicia o fluxo de COLETA no SILOMS.
 * mode: 'siloms' | 'contratosgov' — determina o que fazer após a coleta.
 */
export async function startColeta(mode, silomsTabId) {
  await setState({
    state: 'running',
    flow: 'coleta',
    mode,
    coletaPhase: 'navegar',
    coletaIndex: 0,
    coletaTotal: 0,
    solicitacoes: [],
    solDetalhes: [],
    silomsTabId,
    log: [],
  });

  runStateMachine().catch(async err => {
    await appendLog(`❌ Erro fatal: ${err.message}`, 'error');
    await setState({ state: 'error' });
    notifySidePanel({ type: 'ERROR', message: err.message });
  });

  return { ok: true, started: true };
}

/**
 * Inicia empenho no CONTRATOSGOV com payload específico (fluxo legado / via gapmn.app).
 */
export async function startEmpenho(payload, tabId, dryRun = false, initialQueue = []) {
  const orfa = await recuperarExecucaoOrfa();
  const s = await getState();

  if (s.state === 'running' || s.state === 'checkpoint') {
    await setState({ queue: [...(s.queue ?? []), payload, ...initialQueue] });
    return { ok: true, queued: true };
  }

  await setState({
    state: 'running', ...estadoInicialDoPayload(payload),
    payload, queue: initialQueue, cnetTabId: tabId, dryRun, log: [],
    inicioFila: new Date().toISOString(), valorEmpenhado: null, valorNaTela: null, arredondado: false, degrauArredondamento: null, falhasSeguidas: 0,
  });
  if (orfa) {
    await appendLog(`⚠ A execução anterior (${orfa}) tinha sido interrompida e foi descartada.`, 'warn');
  }

  runStateMachine().catch(async err => {
    await appendLog(`❌ Erro fatal: ${err.message}`, 'error');
    await setState({ state: 'error' });
    notifySidePanel({ type: 'ERROR', message: err.message });
  });

  return { ok: true, started: true };
}

export async function pauseEmpenho() {
  await setState({ state: 'paused' });
  await appendLog('⏸ Pausado pelo usuário', 'warn');
  notifySidePanel({ type: 'PAUSED' });
}

export async function resumeEmpenho() {
  const s = await getState();
  if (s.state !== 'paused') return { ok: false, error: 'Não está pausado' };
  await setState({ state: 'running' });
  await appendLog('▶ Retomado', 'info');
  runStateMachine().catch(async err => {
    await appendLog(`❌ Erro ao retomar: ${err.message}`, 'error');
    await setState({ state: 'error' });
  });
  return { ok: true };
}

export async function abortEmpenho() {
  await setState({ state: 'idle', step: 0, coletaPhase: null });
  await appendLog('🛑 Abortado pelo usuário', 'warn');
  notifySidePanel({ type: 'ABORTED' });
}

export async function confirmEmissao() {
  const s = await getState();
  if (s.state === 'checkpoint' && s.flow === 'alteracao-cnet' && s.altStep === 4) {
    if (maquinaAtiva) return { ok: false, error: 'O robô ainda está executando' };
    await setState({ state: 'running' });
    maquinaAtiva = true;
    let proximo = false;
    try { proximo = await emitirAlteracao(s.cnetTabId, await getState()); } finally { maquinaAtiva = false; }
    if (proximo) {
      runStateMachine().catch(async err => {
        await appendLog(`❌ Erro fatal: ${err.message}`, 'error');
        await setState({ state: 'error' });
        notifySidePanel({ type: 'ERROR', message: err.message });
      });
    }
    return { ok: true };
  }
  if (s.state !== 'checkpoint' || s.step !== 8) {
    return { ok: false, error: 'Não está no checkpoint da Etapa 8' };
  }
  if (maquinaAtiva) return { ok: false, error: 'O robô ainda está executando' };
  await setState({ state: 'running' });
  // Marca a máquina como ativa: durante a emissão o estado é "running" sem laço, e
  // um GET_STATE do painel nesse meio a trataria como execução órfã.
  maquinaAtiva = true;
  let proximo = false;
  try {
    proximo = await runStep8Confirm(s.cnetTabId, s.payload);
  } finally {
    maquinaAtiva = false;
  }
  if (proximo) {
    runStateMachine().catch(async err => {
      await appendLog(`❌ Erro fatal: ${err.message}`, 'error');
      await setState({ state: 'error' });
      notifySidePanel({ type: 'ERROR', message: err.message });
    });
  }
  return { ok: true };
}

// ── Máquina de estados principal ──────────────────────────────────────────────

// O estado fica no storage e sobrevive a recarregar a extensão ou ao navegador
// encerrar o service worker; o laço que o executava, não. Por isso "running"
// no storage não prova que há algo rodando — este flag, em memória, prova.
let maquinaAtiva = false;

/**
 * Se o storage diz "running" mas nenhum laço está ativo, a execução ficou órfã:
 * marca como pausada (o usuário pode Retomar da mesma etapa ou Abortar).
 * Retorna a identificação da execução órfã, ou null.
 */
export async function recuperarExecucaoOrfa() {
  const s = await getState();
  if (s.state !== 'running' || maquinaAtiva) return null;
  const id = s.flow === 'coleta'
    ? 'coleta do SILOMS'
    : s.flow === 'alteracao-cnet'
      ? `${s.alteracao?.operacao ?? 'alteração'} da ${s.alteracao?.ne ?? 'NE'}, ${ROTULO_ALT[s.altStep] ?? ''}`
      : `${s.payload?.numeroSolicitacao ?? 'solicitação'}, Etapa ${s.step}`;
  await setState({ state: 'paused' });
  await appendLog(`⚠ Execução interrompida (${id}) — a extensão foi recarregada ou o navegador a encerrou. Use Retomar ou Abortar.`, 'warn');
  return id;
}

async function runStateMachine() {
  // Um laço por vez: um laço pausado continua vivo aguardando, e Retomar não
  // pode abrir um segundo que executaria as mesmas etapas em paralelo.
  if (maquinaAtiva) return;
  maquinaAtiva = true;
  try {
    await laçoDaMaquina();
  } finally {
    maquinaAtiva = false;
  }
}

async function laçoDaMaquina() {
  while (true) {
    const s = await getState();
    if (s.state === 'paused') { await delay(1000); continue; }
    if (s.state !== 'running') break;

    if (s.flow === 'coleta') {
      const shouldContinue = await runColetaStep(s);
      if (!shouldContinue) break;
    } else if (s.flow === 'empenho-cnet') {
      const shouldContinue = await runEmpenhoStep(s);
      if (!shouldContinue) break;
    } else if (s.flow === 'alteracao-cnet') {
      const shouldContinue = await runAlteracaoStep(s);
      if (!shouldContinue) break;
    } else {
      break;
    }
  }
}

// ── Fluxo COLETA ──────────────────────────────────────────────────────────────

async function runColetaStep(s) {
  const { coletaPhase, silomsTabId: tabId } = s;

  switch (coletaPhase) {

    case 'navegar': {
      await appendLog('🔍 Verificando página do SILOMS…', 'info');
      notifySidePanel({ type: 'LOG', msg: '🔍 Verificando página do SILOMS…', level: 'info' });

      let check = null;
      try { check = await execInPage(tabId, silomsCheckListPage); } catch {}

      if (!check) {
        await appendLog('❌ Não foi possível acessar o SILOMS. Abra o SILOMS na aba ativa.', 'error');
        await setState({ state: 'paused' });
        notifySidePanel({ type: 'PAUSED', error: 'Aba do SILOMS não acessível. Confirme que está logado.' });
        return false;
      }

      if (!check.onListPage) {
        await appendLog('📂 Navegando para Empenho → Solicitação de Empenho (Recebidas)…', 'info');
        notifySidePanel({ type: 'LOG', msg: '📂 Abrindo menu Empenho…', level: 'info' });

        const r1 = await execInPage(tabId, silomsClickMenuEmpenho);
        if (!r1?.ok) {
          await appendLog(`❌ ${r1?.error ?? 'Menu Empenho não encontrado'}`, 'error');
          await setState({ state: 'paused' });
          notifySidePanel({ type: 'PAUSED', error: r1?.error ?? 'Menu Empenho não encontrado' });
          return false;
        }

        await delay(700);
        const r2 = await execInPage(tabId, silomsClickSubmenu);
        if (!r2?.ok) {
          await appendLog(`❌ ${r2?.error ?? 'Submenu não encontrado'}`, 'error');
          await setState({ state: 'paused' });
          notifySidePanel({ type: 'PAUSED', error: r2?.error ?? 'Submenu não encontrado' });
          return false;
        }

        await appendLog('⏳ Aguardando página de solicitações…', 'info');
        try { await waitForNavigation(tabId, 30000); } catch { await delay(3000); }
        await delay(800);
      } else {
        await appendLog('✅ Já está na página de solicitações.', 'info');
      }

      await setState({ coletaPhase: 'filtrar' });
      return true;
    }

    case 'filtrar': {
      await appendLog('🔎 Filtrando por "Assinada OD UGCred" e buscando…', 'info');
      notifySidePanel({ type: 'LOG', msg: '🔎 Aplicando filtro e buscando…', level: 'info' });

      const r = await execInPage(tabId, silomsSetFiltroEBuscar);
      if (!r?.ok) {
        await appendLog(`❌ ${r?.error ?? 'Erro ao filtrar'}`, 'error');
        await setState({ state: 'paused' });
        notifySidePanel({ type: 'PAUSED', error: r?.error ?? 'Erro ao filtrar' });
        return false;
      }

      await appendLog('⏳ Aguardando resultados…', 'info');
      try { await waitForNavigation(tabId, 30000); } catch { await delay(3000); }
      await delay(800);
      await setState({ coletaPhase: 'lista' });
      return true;
    }

    case 'lista': {
      await appendLog('📋 Lendo lista de solicitações…', 'info');
      notifySidePanel({ type: 'LOG', msg: '📋 Lendo lista de solicitações…', level: 'info' });

      const r = await execInPage(tabId, silomsParseListaSolicitacoes);
      if (!r?.ok) {
        await appendLog('❌ Erro ao ler lista', 'error');
        await setState({ state: 'paused' });
        notifySidePanel({ type: 'PAUSED', error: 'Erro ao ler lista de solicitações' });
        return false;
      }

      if (r.count === 0) {
        await appendLog('ℹ Nenhuma solicitação "Assinada OD UGCred" encontrada.', 'warn');
        await setState({ state: 'done', coletaPhase: 'done', solDetalhes: [] });
        notifySidePanel({ type: 'COLETA_DONE', solicitacoes: [], mode: s.mode });
        return false;
      }

      await appendLog(`✅ ${r.count} solicitações encontradas. Iniciando coleta de detalhes…`, 'info');
      notifySidePanel({ type: 'LOG', msg: `✅ ${r.count} solicitação(ões) encontrada(s)`, level: 'success' });
      notifySidePanel({ type: 'COLETA_TOTAL', total: r.count });

      await setState({
        coletaPhase: 'detalhe',
        coletaIndex: 0,
        coletaTotal: r.count,
        solicitacoes: r.solicitacoes,
        solDetalhes: [],
      });
      return true;
    }

    case 'detalhe': {
      const { solicitacoes: sols, coletaIndex: idx, solDetalhes: detalhes } = s;

      if (idx >= sols.length) {
        // Todas coletadas
        await appendLog(`🎉 Coleta concluída! ${detalhes.length} solicitação(ões) prontas para empenho.`, 'success');
        await setState({ state: 'checkpoint', coletaPhase: 'done' });
        notifySidePanel({
          type: 'COLETA_DONE',
          solicitacoes: detalhes,
          mode: s.mode,
        });
        return false;
      }

      const current = sols[idx];
      await appendLog(`📄 [${idx + 1}/${sols.length}] Abrindo solicitação ${current.numero}…`, 'info');
      notifySidePanel({
        type: 'COLETA_PROGRESS',
        current: idx + 1,
        total:   sols.length,
        numero:  current.numero,
      });

      // Abre a solicitação
      const r1 = await execInPage(tabId, silomsAbrirSolicitacao, [current.numero]);
      if (!r1?.ok) {
        await appendLog(`⚠ ${r1?.error ?? 'Não encontrou link'} — pulando.`, 'warn');
        await setState({ coletaIndex: idx + 1 });
        return true;
      }

      try { await waitForNavigation(tabId, 20000); } catch { await delay(2000); }
      await delay(600);

      // Extrai dados do documento
      const doc = await execInPage(tabId, silomsExtrairDocumento);
      const detalhe = doc?.ok
        ? { ...current, ...doc }
        : { ...current, ok: false, error: doc?.error ?? 'Falha ao extrair' };

      await appendLog(
        doc?.ok
          ? `  ✓ ${current.numero} — ${doc.fornecedorNome} — R$ ${doc.total}`
          : `  ⚠ ${current.numero} — erro ao extrair: ${doc?.error}`,
        doc?.ok ? 'success' : 'warn'
      );

      // Volta para a lista
      await execInPage(tabId, silomsVoltar);
      try { await waitForNavigation(tabId, 20000); } catch { await delay(2000); }
      await delay(600);

      await setState({
        coletaIndex: idx + 1,
        solDetalhes: [...detalhes, detalhe],
      });
      return true;
    }

    default:
      return false;
  }
}

// ── Fluxo EMPENHO-CNET (8 etapas — existente) ─────────────────────────────────

// Identifica a tela atual (caminho + título). Com tempo limite: um alert() do
// CNET bloqueia a página e o executeScript ficaria esperando para sempre.
async function impressaoDaPagina(tabId) {
  const ler = execInPage(tabId, () => {
    const visivel = e => e && e.offsetParent !== null && (e.textContent ?? '').trim();
    // Também os avisos que o CNET devolve na própria tela (.flash-message: "Compra não
    // encontrada…", "serviço externo instável…") e a lista de erros de validação
    // (.callout-danger). Sem eles, a Etapa 1 parecia "sem erro" e o robô clicava de novo.
    const erros = [...new Set(Array.from(document.querySelectorAll(
      '.flash-message .alert, .callout-danger li, .alert-danger, .has-error .help-block, .invalid-feedback, .swal2-html-container, .toast-message, .error'
    )).filter(visivel).map(e => e.textContent.replace(/\s+/g, ' ').trim()))].slice(0, 3);
    const titulo = (document.querySelector('.content-header h1, section.content-header, h1')?.textContent ?? '')
      .replace(/\s+/g, ' ').trim().slice(0, 80);
    return { caminho: location.pathname, titulo, erros, oculta: document.visibilityState === 'hidden' };
  }).catch(() => null);
  const limite = new Promise(r => setTimeout(() => r({ bloqueada: true }), 6000));
  return (await Promise.race([ler, limite])) ?? { bloqueada: true };
}

// Por que a página não respondeu, em palavras do usuário (para o log)
function motivoSemResposta(tela) {
  if (!tela || tela.bloqueada) return 'a página do CNET não responde: há um aviso aberto nela, ou o navegador parou a aba por estar em segundo plano — deixe a aba do CNET visível e feche avisos';
  if (tela.oculta) return `a aba do CNET está em segundo plano e o navegador desacelera a página — deixe-a visível durante a execução (tela: ${tela.titulo || tela.caminho || '?'})`;
  return `tela: ${tela.titulo || tela.caminho || '?'}`;
}

// Mensagens do CNET que pedem só para repetir (instabilidade, não dado errado)
const RX_TENTE_DE_NOVO = /tente\s+(?:novamente|de\s+novo|mais\s+tarde)|erro\s+ao\s+validar\s+os\s+dados|erro\s+inesperado/i;

// Clica "Próxima Etapa" de novo na mesma tela e espera a resposta (tela nova ou
// aviso de arredondamento, que é tratado aqui)
async function clicarProximaDeNovo(tabId, step) {
  const idAntesDeNovo = await idDoDocumento(tabId);
  const nav = idAntesDeNovo ? null : waitForNavigation(tabId, 25000).then(() => true, () => false);
  await execInPage(tabId, () => {
    const b = document.querySelector('button.submeter') ||
      Array.from(document.querySelectorAll('button, a.btn')).find(x => /pr[óo]xima/i.test(x.textContent ?? ''));
    b?.click();
    return !!b;
  }).catch(() => null);
  const clicouDeNovo = Date.now();
  const e2 = idAntesDeNovo
    ? await esperarNovaTela(tabId, idAntesDeNovo, step, { comAviso: true, desde: clicouDeNovo })
    : await esperarNavegacaoOuAviso(tabId, 25000, nav);
  if (e2 === 'aviso') {
    const r3 = await handleRoundingModal(tabId);
    if (r3?.handled) {
      const degrau = await concluirArredondamento(tabId, r3);
      const st = await getState();
      await setState({ arredondado: true, degrauArredondamento: Math.round(((st.degrauArredondamento ?? 0) + degrau) * 100) / 100 || null });
    }
  } else {
    if (e2 === 'tempo' && !idAntesDeNovo) await esperarAbaCarregar(tabId, step, clicouDeNovo);
    await delay(e2 === 'navegou' ? 300 : 800);
  }
}

async function runEmpenhoStep(s) {
  const { step, payload, cnetTabId: tabId, dryRun } = s;
  await appendLog(`━ Iniciando Etapa ${step}`, 'info');
  notifySidePanel({ type: 'STEP', step });
  // Etapas 1–7 terminam clicando "Próxima"; guardo a tela para conferir o avanço
  const antes = step >= 1 && step <= 7 ? await impressaoDaPagina(tabId) : null;
  // Etapa 1: o documento antes do envio — outro documento na mesma tela depois do clique
  // é a resposta do servidor (formulário devolvido), não um clique que não pegou
  const idAntesDaEtapa = step === 1 ? await idDoDocumento(tabId) : null;

  try {
    let result;
    switch (step) {
      case 0: result = await runStep0(tabId, payload); break;
      case 1: result = await runStep1(tabId, payload); break;
      case 2: result = await runStep2(tabId, payload); break;
      case 3: result = await runStep3(tabId, payload); break;
      case 4: result = await runStep4(tabId, payload); break;
      case 5: result = await runStep5(tabId, payload); break;
      case 6: result = await runStep6(tabId, payload); break;
      case 7: result = await runStep7(tabId); break;
      case 8: result = await runStep8(tabId, payload, dryRun); break;
      default:
        await setState({ state: 'done' });
        notifySidePanel({ type: 'DONE' });
        return false;
    }
    // Etapas 1–7 acabaram de clicar "Próxima": a tela ainda é a desta etapa
    const clicouEm = Date.now();
    const idDaEtapa = step >= 1 && step <= 7 && result?.ok ? await idDoDocumento(tabId) : null;

    // Problema desta solicitação: registra o motivo e segue para a próxima
    if (!result.ok) return pularSolicitacao(tabId, step, result.error, { url: result.urlMinuta ?? null });

    if (result.checkpoint) {
      await setState({ state: 'checkpoint', step: 8 });
      notifySidePanel({ type: 'CHECKPOINT', step: 8, summary: result.summary });
      return false;
    }

    // Etapa 8 conferida: emite, finaliza, registra a NE e segue a fila
    if (result.emitir) {
      const r = await emitirEFinalizar(tabId, payload);
      if (!r.ok) return pularSolicitacao(tabId, 8, r.error, { status: r.talvezEmitido ? 'conferir' : 'falhou', url: r.url ?? null });
      return depoisDoEmpenho(tabId, payload, r);
    }

    await appendLog(`✅ Etapa ${step} concluída`, 'info');

    if (step === 8) {
      // Só no modo simulação (sem checkpoint): segue para o próximo da fila
      notifySidePanel({ type: 'DONE', ne: result.ne });
      if (await prepararProximoDaFila(tabId)) return true;
      await setState({ state: 'done' });
      return false;
    }

    await setState({ step: step + 1 });

    if (step === 0) {
      // Após step 0 (navegação para buscacompra), aguarda select2 e jQuery inicializarem
      // (a Etapa 1 ainda espera o formulário aparecer)
      await delay(600);
    } else if (step > 0 && step < 8) {
      await appendLog('⏳ Aguardando carregamento da próxima etapa…', 'info');
      // Segue assim que a tela nova estiver montada (não espera imagens e scripts de
      // terceiros). Depois da Etapa 5 o aviso de arredondamento pode abrir na própria
      // tela: olha por ele junto. CNET lento: continua esperando, sem clicar de novo.
      const espera = idDaEtapa
        ? await esperarNovaTela(tabId, idDaEtapa, step, { comAviso: step === 5, desde: clicouEm })
        : step === 5 ? await esperarNavegacaoOuAviso(tabId, 25000)
        : await waitForNavigation(tabId, 25000).then(() => 'navegou', () => 'tempo');
      if (espera === 'navegou') await delay(300);
      else if (espera === 'tempo' && !idDaEtapa && await esperarAbaCarregar(tabId, step, clicouEm)) await delay(800);

      // Verifica modal de arredondamento (aparece após Etapa 5 em alguns casos)
      const rounding = await handleRoundingModal(tabId);
      if (rounding?.handled) {
        // O valor exato que falta sai do Valor Total da Etapa 8; aqui, a conta pelo aviso
        const falta = faltaDoArredondamento(rounding, payload.itensEmpenho, valorSolicitadoDe(payload));
        await logVisivel(textoArredondamento(rounding, falta, 'reforço irrisório'), 'warn');
        const degrau = await concluirArredondamento(tabId, rounding);
        await setState({ valorEmpenhado: rounding.totalEmpenhado || null, arredondado: true,
          degrauArredondamento: degrau > 0 ? Math.round(degrau * 100) / 100 : null });
      }

      // "Próxima" clicado não prova avanço: com um campo inválido o CNET fica na
      // mesma tela e a etapa seguinte rodaria na tela errada, também "com sucesso".
      if (antes && !antes.bloqueada) {
        let depois = await impressaoDaPagina(tabId);
        const naMesmaTela = d => !d.bloqueada && d.caminho === antes.caminho && d.titulo === antes.titulo;
        // Etapa 1 devolvida pelo CNET (documento novo, mesma tela): o formulário volta
        // zerado, com "Contrato" marcado. Clicar "Próxima" de novo enviava esse formulário
        // vazio, e o motivo real (ex.: "Compra não encontrada") sumia atrás de "O campo
        // Contrato é obrigatório quando Tipo é Contrato" (13/10, todas as compras)
        if (step === 1 && idAntesDaEtapa && naMesmaTela(depois)) {
          const idAgora = await idDoDocumento(tabId);
          if (idAgora && idAgora !== idAntesDaEtapa) {
            const msg = (depois.erros ?? []).join(' | ').replace(/[.\s]+$/, '');
            const st = await getState();
            const vezes = st.refazerEtapa1 ?? 0;
            if (RX_TENTE_DE_NOVO.test(msg) && vezes < 2) {
              await logVisivel(`⚠ [Etapa 1] CNET: "${msg.slice(0, 120)}" — preenchendo a Etapa 1 de novo (${vezes + 1}/2)…`, 'warn');
              await setState({ step: 1, refazerEtapa1: vezes + 1 });
              await delay(5000 * (vezes + 1));
              return true;   // o laço roda a Etapa 1 outra vez
            }
            return pularSolicitacao(tabId, 1, (msg ? `o CNET recusou a Etapa 1: ${msg}` : 'o CNET devolveu a Etapa 1 sem dizer o motivo')
              + (st.diagEtapa1 ? ` [formulário enviado: ${st.diagEtapa1}]` : ''));
          }
        }
        // Ficou na mesma tela sem erro do CNET: o aviso de arredondamento pode ter voltado,
        // ou o clique não pegou — trata o aviso ou clica "Próxima" mais uma vez
        if (naMesmaTela(depois) && !depois.erros?.length) {
          const r2 = await handleRoundingModal(tabId);
          if (r2?.handled) {
            await logVisivel(textoArredondamento(r2, faltaDoArredondamento(r2, payload.itensEmpenho, valorSolicitadoDe(payload)), 'reforço irrisório'), 'warn');
            const degrau = await concluirArredondamento(tabId, r2);
            const st = await getState();
            await setState({ arredondado: true, degrauArredondamento: Math.round(((st.degrauArredondamento ?? 0) + degrau) * 100) / 100 || null });
          } else {
            await logVisivel(`⚠ [Etapa ${step}] A página não avançou — clicando "Próxima Etapa" mais uma vez…`, 'warn');
            await clicarProximaDeNovo(tabId, step);
          }
          depois = await impressaoDaPagina(tabId);
        }
        // Erro passageiro do CNET ("Ocorreu um erro ao validar os dados. Por favor, tente
        // novamente"): os campos continuam preenchidos — espera e clica "Próxima" de novo
        for (let t = 1; t <= 2 && naMesmaTela(depois) && RX_TENTE_DE_NOVO.test((depois.erros ?? []).join(' ')); t++) {
          await logVisivel(`⚠ [Etapa ${step}] CNET: "${depois.erros.join(' | ').slice(0, 90)}" — tentando de novo (${t}/2)…`, 'warn');
          await delay(4000 * t);
          await clicarProximaDeNovo(tabId, step);
          depois = await impressaoDaPagina(tabId);
        }
        const parada = depois.bloqueada
          ? 'a página está bloqueada por um aviso (alert) do CNET'
          : naMesmaTela(depois)
            ? `a página não avançou${depois.erros?.length ? ` — CNET: ${depois.erros.join(' | ').replace(/[.\s]+$/, '')}` : ' (nem tentando de novo; sem mensagem do CNET na tela)'}`
            : null;
        if (parada) {
          const diag = step === 1 ? (await getState()).diagEtapa1 : null;
          return pularSolicitacao(tabId, step, `cliquei em "Próxima", mas ${parada}${diag ? ` [formulário enviado: ${diag}]` : ''}`);
        }
      }
    }

    return true;

  } catch (err) {
    // Na Etapa 8 a exceção pode ter vindo depois do clique em Emitir: conferir no CNET
    return pularSolicitacao(tabId, step, `Exceção: ${err.message}`, { status: step === 8 ? 'conferir' : 'falhou' });
  }
}

// ── Problema numa solicitação: registra o motivo e segue a fila ──────────────

// Instruções de "Retomar" não servem no relatório: a fila já seguiu
function limparMotivo(m) {
  return String(m ?? '')
    .replace(/\s*(?:—|-)\s*escolha[^.]*?use Retomar\.?/gi, '')
    .replace(/\s*Volte à Etapa[^.]*\.?/gi, '')
    .replace(/\s*Aborte,[^.]*\.?/gi, '')
    .replace(/[,;\s—-]*(?:e\s+)?(?:depois\s+)?use Retomar[^.]*\.?/gi, '')
    .replace(/\s+/g, ' ').replace(/[\s,;—-]+$/, '').trim();
}

// Falha "do sistema" (aba, sessão, CNET fora do ar) e não da solicitação: se
// repetir, pular só criaria uma falha atrás da outra na fila inteira
const RX_SISTEMICO = /Script não retornou|Exceção|timeout|não carregaram|não trouxe|não achei a lista de Minutas|bloqueada por um aviso|Não consegui ler a tela|sem resposta|sessão expirou/i;
const RX_SESSAO = /\/login\b|acesso\.gov\.br|\bsso\./i;
const LIMITE_FALHAS_SISTEMA = 3;

/**
 * A solicitação atual não deu para empenhar: grava no registro (status 'falhou',
 * ou 'conferir' se a emissão pode ter acontecido) com etapa e motivo e segue a
 * fila. Pausa só em sessão expirada ou falhas de sistema repetidas.
 */
async function pularSolicitacao(tabId, etapa, erro, { status = 'falhou', url = null } = {}) {
  const s = await getState();
  const payload = s.payload ?? {};
  const sol = payload.numeroSolicitacao ?? '';

  const aba = await chrome.tabs.get(tabId).catch(() => null);
  if (RX_SESSAO.test(aba?.url ?? '')) {
    const msg = `A sessão do CNET expirou (${sol || 'solicitação'}, Etapa ${etapa}). Entre de novo no CNET e use Retomar — o robô recomeça esta solicitação.`;
    await appendLog(`❌ ${msg}`, 'error');
    await setState({ state: 'paused', step: 0 });
    notifySidePanel({ type: 'PAUSED', error: msg, step: 0 });
    return false;
  }

  const motivo = limparMotivo(erro) || 'erro sem descrição';
  await registrarEmpenho({
    id:          `${Date.now()}-${sol}`,
    data:        new Date().toISOString(),
    solicitacao: sol,
    ne:          null,
    status,
    etapa,
    motivo,
    url,
    fornecedor:  payload.fornecedorNome ?? '',
    cnpj:        String(payload.fornecedorCnpj ?? payload.fornecedorCNPJ ?? '').replace(/\D/g, ''),
    origem:      payload.tipoOrigem === 'compra' ? `Compra ${payload.numeroCompra ?? ''}` : (payload.contrato ?? ''),
    pag:         payload.pag ?? '',      // para o subprocesso no SILOMS
    ugCred:      payload.ugCred ?? '',
    operacao:    payload.operacao || undefined,
    neAlterar:   payload.neAlterar || undefined,
    valorSolicitado: valorSolicitadoDe(payload),
    valorEmpenhado:  0,
    verificacaoFornecedor: payload.verificacaoFornecedor?.resumo ?? '',
  });
  await logVisivel(
    `${status === 'conferir' ? '⚠' : '⛔'} ${sol || 'Solicitação'} ${status === 'conferir' ? 'precisa ser conferida no CNET' : 'NÃO empenhada'} (Etapa ${etapa}): ${motivo}${s.queue?.length ? ' — seguindo para a próxima' : ''}`,
    'error',
  );
  notifySidePanel({ type: 'SKIPPED', numero: sol, etapa, motivo, status });

  const falhas = RX_SISTEMICO.test(erro ?? '') ? (s.falhasSeguidas ?? 0) + 1 : (s.falhasSeguidas ?? 0);
  await setState({ falhasSeguidas: falhas });
  if (falhas >= LIMITE_FALHAS_SISTEMA && s.queue?.length) {
    await prepararProximoDaFila(tabId);
    const msg = `${falhas} falhas de sistema seguidas (aba, sessão ou CNET fora do ar) — confira o CNET e use Retomar para seguir com a próxima.`;
    await appendLog(`⏸ ${msg}`, 'warn');
    await setState({ state: 'paused', falhasSeguidas: 0 });
    notifySidePanel({ type: 'PAUSED', error: msg, step: 0 });
    return false;
  }
  return seguirFila(tabId);
}

// ── Implementações de etapas CNET ─────────────────────────────────────────────

// As listas do CNET mostram 10 linhas por padrão; o que estiver na página 2 não
// existe para o robô. Toda etapa que procura linha numa tabela chama isto antes.
async function maximizarTabelas(tabId, etapa, esperaMs = 8000) {
  // Com limite: o script espera dentro da página; página saindo ou parada não responde
  const r = await comLimite(execInPage(tabId, maximizarTabelasRunner, [esperaMs]), esperaMs + 40000);
  if (r?.ajustes?.length) await appendLog(`[Etapa ${etapa}] Tabela ampliada (${r.ajustes.join(', ')})`, 'info');
  else if (!r) await appendLog(`[Etapa ${etapa}] A página não respondeu ao ampliar a tabela — seguindo`, 'warn');
}

async function runStep0(tabId, payload) {
  // Nova minuta SEMPRE pela lista de Minutas → "Adicionar Minuta de Empenho", como o
  // usuário faz. Antes valia o primeiro link "buscacompra" da tela em que o CNET
  // estivesse — ou a própria tela, se já fosse o formulário. Depois de uma solicitação
  // que falhou, essa tela é a Etapa 1 de uma minuta que ficou aberta: as compras
  // seguintes caíam nela e o CNET respondia "O campo Contrato é obrigatório quando Tipo
  // é Contrato" (13/10, cinco seguidas). Aberto pelo endereço logo depois de um empenho,
  // o formulário também pode vir preso à minuta anterior (Número/Ano bloqueado).
  // Ir para a lista também tira da frente um alert() que tenha ficado aberto.
  await appendLog('[Pré] Abrindo a lista de Minutas de Empenho…', 'info');
  await setState({ refazerEtapa1: 0, diagEtapa1: null });
  await navegarPara(tabId, MINUTAS_URL);
  const lista = await esperarListaMinutas(tabId, MINUTAS_URL);
  const idAntes = await idDoDocumento(tabId);
  const r = lista?.naLista ? await comLimite(execInPage(tabId, step0ClickAdicionarMinuta), 8000) : null;
  if (r?.ok) {
    await appendLog('[Pré] Abrindo nova minuta ("Adicionar Minuta de Empenho")…', 'info');
    notifySidePanel({ type: 'LOG', msg: '[Pré] Abrindo nova minuta…', level: 'info' });
    const clicouEm = Date.now();
    if (idAntes) await esperarNovaTela(tabId, idAntes, 0, { desde: clicouEm });
    else { try { await waitForNavigation(tabId, 25000); } catch { await esperarAbaCarregar(tabId, 0, clicouEm); await delay(1500); } }
    await delay(500);
    return { ok: true };
  }

  // Sem a lista ou sem o botão: abre o formulário novo pelo endereço
  await appendLog('[Pré] Botão "Adicionar Minuta" não está nesta tela — abrindo o formulário pelo endereço…', 'warn');
  const navegou = waitForNavigation(tabId, 30000).catch(() => {});
  const abriuEm = Date.now();
  try { await chrome.tabs.update(tabId, { url: COMPRASNET_URL }); } catch {}
  await navegou;
  await esperarAbaCarregar(tabId, 0, abriuEm);
  await delay(800);
  return { ok: true };
}

async function runStep1(tabId, payload) {
  await appendLog('[Etapa 1] Preenchendo Contrato/Compra…', 'info');
  const alvo = payload.tipoOrigem === 'compra'
    ? `compra ${payload.numeroCompra} (${payload.modalidade}, unidade ${payload.unidadeCompra})`
    : `contrato ${payload.contrato ?? '—'}`;
  notifySidePanel({ type: 'LOG', msg: `[Etapa 1] Preenchendo ${alvo}…`, level: 'info' });

  const pronta = await esperarTabela(tabId, 1, 'etapa1', 'o formulário da Etapa 1');
  if (!pronta.ok) return { ok: false, error: `Etapa 1: ${pronta.error}` };
  const result = await execInPage(tabId, step1Runner, [payload]);
  if (!result) return { ok: false, error: 'Script não retornou — aba pode ter recarregado ou sessão expirou' };
  if (result.ok) {
    // Campos enviados: entram no motivo se o CNET recusar a Etapa 1
    await setState({ diagEtapa1: result.diag || null });
    await appendLog('[Etapa 1] Preenchido ✓' + (result.diag ? ` (enviado: ${result.diag})` : ''), 'info');
    notifySidePanel({ type: 'LOG', msg: `[Etapa 1] ${payload.tipoOrigem === 'compra' ? 'Compra' : 'Contrato'} selecionado ✓`, level: 'success' });
  }
  return result;
}

async function runStep2(tabId, payload) {
  await appendLog('[Etapa 2] Selecionando fornecedor…', 'info');
  notifySidePanel({ type: 'LOG', msg: '[Etapa 2] Selecionando fornecedor…', level: 'info' });

  // Verifica se a navegação chegou na página correta
  const pageUrl = await execInPage(tabId, () => window.location.href);
  if (!(pageUrl ?? '').includes('/empenho/fornecedor')) {
    return {
      ok: false,
      error: payload.tipoOrigem === 'compra'
        ? `Etapa 1 não concluída — CNET está em "${pageUrl ?? '?'}". Verifique: (1) a compra ${payload.numeroCompra} existe na modalidade "${payload.modalidade}" para a unidade ${payload.unidadeCompra}, (2) sessão não expirou.`
        : `Etapa 1 não concluída — CNET está em "${pageUrl ?? '?'}". Verifique: (1) contrato "${payload.contrato}" existe no CNET com saldo, (2) sessão não expirou, (3) há minutas anteriores abertas para o mesmo contrato.`,
    };
  }

  const pronta = await esperarTabela(tabId, 2, 'fornecedores', 'os fornecedores');
  if (!pronta.ok) return { ok: false, error: `Fornecedores: ${pronta.error}` };
  await maximizarTabelas(tabId, 2, 1500);
  const cnpjRaw = (payload.fornecedorCnpj ?? '').replace(/\D/g, '');

  const escolherFornecedor = () => execInPage(tabId, (cnpj, tipoOrigem) => {
    // Todos os botões "Selecionar este fornecedor" (attr selecionar ou title)
    const btns = Array.from(document.querySelectorAll(
      'a[selecionar], a[title*="elecionar"], button[title*="elecionar"], a[href*="/empenho/item/"]'
    ));
    if (!btns.length) {
      // Diz o porquê: lista vazia do CNET ("Nenhum registro encontrado") ou tela sem a lista
      const vazio = (document.querySelector('td.dataTables_empty')?.textContent ?? '').replace(/\s+/g, ' ').trim();
      const avisos = Array.from(document.querySelectorAll('.alert, .callout, .swal2-html-container, .invalid-feedback'))
        .map(e => e.textContent.replace(/\s+/g, ' ').trim()).filter(Boolean).slice(0, 2).join(' | ');
      const linhas = document.querySelectorAll('table tbody tr').length;
      const oQue = tipoOrigem === 'compra' ? 'esta compra' : 'este contrato';
      return {
        ok: false, semBotoes: true,
        error: vazio && !/carregando|processando/i.test(vazio)
          ? `O CNET não listou nenhum fornecedor para ${oQue} ("${vazio}") — confira no CNET se ${oQue} tem fornecedor com saldo e vigência${avisos ? `. CNET: ${avisos}` : ''}`
          : `A lista de fornecedores não trouxe o botão "Selecionar" (${linhas} linha(s) na tabela${avisos ? `; CNET: ${avisos}` : ''}) — confira a tela do CNET`,
      };
    }

    // Localiza a linha do CNPJ correto
    let target = null;
    if (cnpj) {
      for (const btn of btns) {
        const row = btn.closest('tr');
        const rowText = (row?.textContent ?? '').replace(/\D/g, '');
        if (rowText.includes(cnpj)) { target = btn; break; }
      }
    }
    if (!target) {
      // Só aceita "o único da lista"; com vários, escolher um ao acaso
      // empenharia no fornecedor errado.
      const linhas = new Set(btns.map(b => b.closest('tr')));
      if (linhas.size === 1) target = btns[0];
      else return {
        ok: false,
        error: cnpj
          ? `Fornecedor CNPJ ${cnpj} não está entre os ${linhas.size} fornecedores listados — confira o CNPJ na revisão.`
          : `Solicitação sem CNPJ e há ${linhas.size} fornecedores na lista — informe o CNPJ na revisão.`,
      };
    }

    // Navega diretamente pelo href (evita problema com event handlers do CNET)
    if (target.href) {
      window.location.href = target.href;
      return { ok: true, href: target.href };
    }
    target.click();
    return { ok: true };
  }, [cnpjRaw, payload.tipoOrigem]);

  let result = await escolherFornecedor();
  // Lista sem nenhum botão: recarrega a tela uma vez (a busca pode ter se perdido com
  // o CNET lento) antes de desistir
  if (result?.semBotoes) {
    await logVisivel('⚠ [Etapa 2] A lista de fornecedores veio sem fornecedor — recarregando a tela do CNET…', 'warn');
    const aba = await chrome.tabs.get(tabId).catch(() => null);
    const nav = waitForNavigation(tabId, 60000).then(() => true, () => false);
    try { if (aba?.url) await chrome.tabs.update(tabId, { url: aba.url }); } catch { /* segue */ }
    await nav;
    await esperarAbaCarregar(tabId, 2);
    await esperarTabela(tabId, 2, 'fornecedores', 'os fornecedores');
    await maximizarTabelas(tabId, 2, 1500);
    result = await escolherFornecedor();
  }

  if (!result?.ok) return { ok: false, error: result?.error ?? 'Erro na Etapa 2' };
  await appendLog(`[Etapa 2] Navegando para ${result.href ?? 'item'}…`, 'info');
  return { ok: true };
}

async function runStep3(tabId, payload) {
  const itensEmpenho = payload.itensEmpenho ?? [];
  await appendLog('[Etapa 3] Aguardando carregamento dos itens (AJAX)…', 'info');
  notifySidePanel({ type: 'LOG', msg: '[Etapa 3] Aguardando itens carregarem…', level: 'info' });

  const pronta = await esperarTabela(tabId, 3, 'itens', 'os itens');
  if (!pronta.ok) return { ok: false, error: `Itens não carregaram: ${pronta.error}` };
  await maximizarTabelas(tabId, 3, 1500);
  const result = await execInPage(tabId, step3Runner, [itensEmpenho, payload.tipoOrigem]);

  if (!result?.ok) return { ok: false, error: result?.error ?? 'Erro na Etapa 3' };
  // Item do contrato achado pelo valor unitário/descrição: o nº vai para a Etapa 5
  if (result.escolhas?.length) {
    const itens = itensEmpenho.map(it => ({ ...it }));
    for (const e of result.escolhas) {
      itens[e.indice].numeroItem = e.numero;
      await logVisivel(`[Etapa 3] Item do contrato ${e.numero} escolhido ${e.motivo}: ${e.desc}` +
        (e.unit > 0 ? ` (unit. R$ ${fmtR$(e.unit)})` : '') + (e.pdf ? ` — o PDF dizia ${e.pdf}` : ''), 'info');
    }
    const st = await getState();
    await setState({ payload: { ...st.payload, itensEmpenho: itens } });
  }
  await appendLog('[Etapa 3] Itens selecionados ✓', 'info');
  return { ok: true };
}

async function runStep4(tabId, payload) {
  await appendLog('[Etapa 4] Buscando linha de crédito orçamentário…', 'info');
  notifySidePanel({ type: 'LOG', msg: '[Etapa 4] Selecionando crédito…', level: 'info' });
  const pronta = await esperarTabela(tabId, 4, 'creditos', 'as linhas de crédito');
  if (!pronta.ok) return { ok: false, error: `Crédito: ${pronta.error}` };
  // Sem isto, crédito na página 2 levava a cadastrar uma célula orçamentária duplicada
  await maximizarTabelas(tabId, 4, 1500);

  // Antes de marcar a linha, atualiza o crédito dela (⟳): o valor guardado no CNET
  // pode estar velho e barrar um empenho que cabe no crédito real
  await logVisivel('[Etapa 4] Atualizando o crédito da linha (⟳)…', 'info');
  const nav = waitForNavigation(tabId, 90000).then(() => true, () => false);
  const at = await comLimite(execInPage(tabId, step4Runner, [payload, 'atualizar', valorSolicitadoDe(payload)]), 75000);
  if (!at || at.navegando) {
    // O botão recarregou a página (ou o script caiu): espera a tela voltar
    const aba = await chrome.tabs.get(tabId).catch(() => null);
    const navegou = aba?.status === 'loading' || at?.navegando ? await nav : await Promise.race([nav, delay(1500).then(() => false)]);
    if (navegou) {
      await esperarAbaCarregar(tabId, 4);
      await delay(800);
      await esperarTabela(tabId, 4, 'creditos', 'as linhas de crédito');
      await maximizarTabelas(tabId, 4, 1500);
      await logVisivel('[Etapa 4] Crédito da linha atualizado (o CNET recarregou a página)', 'info');
    } else {
      await logVisivel('⚠ [Etapa 4] Não consegui confirmar a atualização do crédito — seguindo com o valor da tela', 'warn');
    }
  } else if (at.semLinha) {
    await logVisivel('[Etapa 4] A linha de crédito ainda não existe no CNET — cadastrando a célula orçamentária', 'info');
  } else {
    for (const m of at.msgs ?? []) await logVisivel(`${m.level === 'warn' ? '⚠ ' : ''}[Etapa 4] ${m.msg}`, m.level);
  }

  const result = await execInPage(tabId, step4Runner, [payload]);

  for (const f of result?.feitos ?? []) await logVisivel(`[Etapa 4] ${f}`, 'info');
  if (!result?.ok) return { ok: false, error: result?.error ?? 'Erro na Etapa 4' };
  await appendLog('[Etapa 4] Crédito selecionado ✓', 'info');
  return { ok: true };
}

async function runStep5(tabId, payload) {
  await appendLog('[Etapa 5] Preenchendo subelemento e valores…', 'info');
  notifySidePanel({ type: 'LOG', msg: '[Etapa 5] Preenchendo subelemento e valores…', level: 'info' });
  const pronta = await esperarTabela(tabId, 5, 'subelementos', 'os itens da Etapa 5');
  if (!pronta.ok) return { ok: false, error: `Etapa 5: ${pronta.error}` };
  await maximizarTabelas(tabId, 5, 1500);

  const result = await execInPage(tabId, step5Runner, [payload]);

  if (!result?.ok) return { ok: false, error: result?.error ?? 'Erro na Etapa 5' };
  for (const f of result.feitos ?? []) await logVisivel(`[Etapa 5] ${f}`, 'info');
  await appendLog('[Etapa 5] Subelemento e valores preenchidos ✓', 'info');
  return { ok: true };
}

async function runStep6(tabId, payload) {
  await appendLog('[Etapa 6] Preenchendo dados do empenho…', 'info');
  notifySidePanel({ type: 'LOG', msg: '[Etapa 6] Preenchendo dados…', level: 'info' });

  const result = await execInPage(tabId, step6Runner, [payload]);

  for (const f of result?.feitos ?? []) await logVisivel(`[Etapa 6] ${f}`, 'info');
  if (!result?.ok) return { ok: false, error: result?.error ?? 'Erro na Etapa 6' };
  await appendLog('[Etapa 6] Dados preenchidos ✓', 'info');
  return { ok: true };
}

// Detecta e trata o modal "Diferença de arredondamento identificada": escolhe a
// opção "para menos" de cada item (pelo texto; sem ele, a de menor valor — ex.:
// "Quantidade: 0,02873 = Valor calculado: R$ 22.984,00") e clica "Corrigir agora",
// que troca o valor do item pelo escolhido. "Avançar e ajustar depois" (só se não
// houver o outro botão) segue com o valor digitado e o SIAFI recusa (ER0462: valor ≠
// quantidade × unitário). A escolha é um clique de verdade (marcar `checked` antes do
// clique não dispara o "change").
async function handleRoundingModal(tabId) {
  // Com limite: página saindo ou parada não responde ao script
  return comLimite(execInPage(tabId, () => {
    const bodyText = document.body?.textContent ?? '';
    if (!bodyText.toLowerCase().includes('arredondamento')) return { handled: false };

    // Só o modal aberto: um modelo escondido na página não conta
    const caixas = Array.from(document.querySelectorAll('.modal, .swal2-popup, [role="dialog"]'))
      .filter(m => /arredondamento/i.test(m.textContent ?? ''));
    const caixa = caixas.find(m => m.offsetParent !== null || getComputedStyle(m).display !== 'none');
    if (caixas.length && !caixa) return { handled: false };
    const radios = Array.from((caixa ?? document).querySelectorAll('input[type="radio"]')).filter(r => !r.disabled);
    if (!radios.length) return { handled: false };

    const textoDe = r => {
      const l = r.closest('label') ?? (r.id ? document.querySelector(`label[for="${CSS.escape(r.id)}"]`) : null) ?? r.parentElement;
      return (l?.textContent ?? '').replace(/\s+/g, ' ').trim();
    };
    const valorDe = r => {
      const m = /R\$\s*([\d.,]+)/.exec(textoDe(r));
      return m ? (parseFloat(m[1].replace(/\./g, '').replace(',', '.')) || 0) : null;
    };
    const grupos = new Map();
    for (const r of radios) {
      const key = r.name || `g_${r.closest('[data-item]')?.dataset?.item ?? r.id}`;
      if (!grupos.has(key)) grupos.set(key, []);
      grupos.get(key).push(r);
    }

    // Nº do item do grupo ("Item 00001"): no bloco que só tem os radios dele, ou no
    // título logo antes; com um item só, o único "Item NNNNN" do aviso
    const raiz = caixa ?? document.body;
    const itemDoGrupo = grupo => {
      const nome = grupo[0].name;
      for (let el = grupo[0].parentElement; el && el !== raiz.parentElement; el = el.parentElement) {
        const nomes = new Set(Array.from(el.querySelectorAll('input[type="radio"]')).map(r => r.name));
        if (nomes.size > 1 || (nome && !nomes.has(nome))) break;
        const m = /Item\s+(\d{1,6})/i.exec(el.textContent ?? '');
        if (m) return m[1];
      }
      let bloco = grupo[0];
      while (bloco.parentElement && bloco.parentElement !== raiz) bloco = bloco.parentElement;
      for (let s = bloco.previousElementSibling; s; s = s.previousElementSibling) {
        if (s.querySelector?.('input[type="radio"]')) break;
        const m = /Item\s+(\d{1,6})/i.exec(s.textContent ?? '');
        if (m) return m[1];
      }
      const todos = (raiz.textContent ?? '').match(/Item\s+\d{1,6}/gi) ?? [];
      return grupos.size === 1 && todos.length === 1 ? /\d+/.exec(todos[0])[0] : null;
    };

    const escolhidos = [], escolhas = [], itens = [];
    let totalMais = 0;
    for (const grupo of grupos.values()) {
      const comValor = grupo.filter(r => valorDe(r) !== null).sort((x, y) => valorDe(x) - valorDe(y));
      const menos = grupo.find(r => /\bmenos\b|\bmenor\b|abaixo|inferior/i.test(textoDe(r)) && !/\bmais\b|\bmaior\b/i.test(textoDe(r)))
        ?? comValor[0] ?? grupo[0];
      // Maior opção do grupo ("para mais"): a distância até ela é o degrau do
      // arredondamento — o irrisório nunca passa disso
      if (comValor.length) totalMais += valorDe(comValor[comValor.length - 1]);
      const jaMarcado = menos.checked;
      if (!jaMarcado) menos.click();
      if (!menos.checked) { menos.checked = true; menos.dispatchEvent(new Event('change', { bubbles: true })); }
      else if (jaMarcado) menos.dispatchEvent(new Event('change', { bubbles: true }));
      escolhidos.push(menos);
      escolhas.push(textoDe(menos).slice(0, 60));
      itens.push({ numeroItem: itemDoGrupo(grupo), menos: valorDe(menos), mais: comValor.length ? valorDe(comValor[comValor.length - 1]) : null });
    }
    const valores = escolhidos.map(valorDe).filter(v => v !== null);
    const totalEmpenhado = valores.reduce((s, v) => s + v, 0);

    const botoes = Array.from((caixa ?? document).querySelectorAll('button, a.btn, input[type="button"]'));
    const rotulo = b => String(b.textContent || b.value || '');
    const btnCorrigir = botoes.find(b => /corrigir/i.test(rotulo(b)));
    const btnAvancar = botoes.find(b => /avan[cç]ar/i.test(rotulo(b)));
    const btn = btnCorrigir ?? btnAvancar;
    if (btn) btn.click();

    return { handled: true, totalEmpenhado, totalMais, count: escolhidos.length, escolhas, itens,
      acao: btnCorrigir ? 'corrigir' : btnAvancar ? 'avancar' : null };
  }), 15000);
}

// O aviso de arredondamento está aberto na tela? (função da página)
function avisoArredondamentoAberto() {
  const visivel = e => { const cs = getComputedStyle(e); return cs.display !== 'none' && cs.visibility !== 'hidden' && e.getClientRects().length > 0; };
  const caixas = Array.from(document.querySelectorAll('.modal, .swal2-popup, [role="dialog"], .bootbox'));
  if (caixas.some(m => /arredondamento/i.test(m.textContent ?? '') && visivel(m))) return true;
  return !caixas.length && /Diferen[çc]a de arredondamento identificada/i.test(document.body?.innerText ?? '');
}

// Depois de "Próxima Etapa": a página muda OU o aviso de arredondamento abre na
// própria tela. Antes o robô esperava a navegação até o tempo limite (25 s) para só
// então olhar o aviso. `navPronta`: espera de navegação já ligada antes do clique.
async function esperarNavegacaoOuAviso(tabId, ms, navPronta = null) {
  let acabou = false;
  const nav = (navPronta ?? waitForNavigation(tabId, ms).then(() => true, () => false)).then(ok => (ok ? 'navegou' : 'tempo'));
  const olhar = (async () => {
    const fim = Date.now() + ms;
    await delay(600);
    while (!acabou && Date.now() < fim) {
      if (await comLimite(execInPage(tabId, avisoArredondamentoAberto), 2500) === true) return 'aviso';
      await delay(600);
    }
    return 'tempo';
  })();
  const r = await Promise.race([nav, olhar]);
  acabou = true;
  return r;
}

// Quanto falta depois do "para menos": para cada item do aviso, o valor pedido na
// solicitação − o corrigido; sem o nº do item, com um item só, total pedido − corrigido
function faltaDoArredondamento(rounding, itensPedidos, totalPedido) {
  const num = s => parseFloat(String(s ?? '').replace(',', '.'));
  const numItem = n => parseInt(String(n ?? '').replace(/\D/g, ''), 10);
  let falta = 0;
  const itens = rounding.itens ?? [];
  const todosAchados = itens.length > 0 && itens.every(it => {
    const ped = (itensPedidos ?? []).find(p => numItem(p.numeroItem) === numItem(it.numeroItem));
    if (!ped || !(num(ped.valor) > 0) || it.menos == null) return false;
    falta += num(ped.valor) - it.menos;
    return true;
  });
  if (!todosAchados) {
    if (rounding.count === 1 && (itensPedidos?.length ?? 0) <= 1 && totalPedido > 0) falta = totalPedido - rounding.totalEmpenhado;
    else return null;
  }
  falta = Math.round(falta * 100) / 100;
  return falta >= 0.005 ? falta : null;
}

// Linha do log no "Corrigir agora": o valor de cada item e o que falta para o irrisório
function textoArredondamento(rounding, falta, complemento) {
  const itens = (rounding.itens ?? []).filter(i => i.menos != null);
  const descr = itens.length
    ? itens.map(i => `${i.numeroItem ? `item ${i.numeroItem}` : 'item'} → R$ ${fmtR$(i.menos)}`).join('; ')
    : (rounding.escolhas?.join('; ') || `${rounding.count} item(ns)`);
  const botao = rounding.acao === 'corrigir' ? 'Corrigir agora' : 'Avançar e ajustar depois';
  return `⚠ Arredondamento "para menos" (${descr}) + "${botao}"`
    + (falta ? ` — faltam R$ ${fmtR$(falta)}, que vão de ${complemento} logo depois da emissão` : ` — o que faltar vai de ${complemento} logo depois da emissão`);
}

// Depois do aviso de arredondamento. "Corrigir agora" troca o valor do item pelo
// escolhido e fecha o aviso: a etapa pode avançar sozinha ou ficar na tela — aí o
// robô clica "Próxima Etapa" de novo (o aviso pode voltar para outro item). Devolve o
// degrau somado de todos os avisos tratados (limite do irrisório).
async function concluirArredondamento(tabId, rounding, tentativa = 1) {
  const degrau = r => (r.totalMais > r.totalEmpenhado ? r.totalMais - r.totalEmpenhado : 0);
  const soma = degrau(rounding);
  // Tela do aviso (a Etapa 5); a próxima é qualquer outra. Não espera a aba terminar
  // de carregar: com um recurso de fora demorando, a tela seguinte já aparece e um
  // "Próxima" clicado nela pularia a Etapa 6.
  const idAviso = await idDoDocumento(tabId);
  if (!idAviso) {
    // Sem como identificar a tela: só espera (nunca clica às cegas)
    try { await waitForNavigation(tabId, 20000); } catch {}
    await delay(800);
    return soma;
  }
  if (rounding.acao !== 'corrigir') {
    await esperarNovaTela(tabId, idAviso, 5);
    await delay(300);
    return soma;
  }
  // "Corrigir agora" é na própria tela: se em 2,5 s não trocou de tela, segue com "Próxima"
  for (const fim = Date.now() + 2500; Date.now() < fim;) {
    const t = await comLimite(execInPage(tabId, sondaTela), 2000);
    if (t && t.id !== idAviso && t.pronto) { await delay(300); return soma; }
    await delay(400);
  }
  // Clica só se ainda for a tela do aviso (a conferência é feita na própria página)
  const clicou = await comLimite(execInPage(tabId, id => {
    if (String(performance.timeOrigin) + '|' + location.href !== id) return 'navegou';
    const btn = document.querySelector('button.submeter') ||
      Array.from(document.querySelectorAll('button, a.btn')).find(b => /pr[óo]xima/i.test(b.textContent ?? ''));
    if (!btn) return 'sem-botao';
    btn.click();
    return 'ok';
  }, [idAviso]), 4000) ?? 'navegou';
  if (clicou === 'ok') {
    await logVisivel('[Arredondamento] Valor corrigido — clicando "Próxima Etapa" de novo…', 'info');
    const r = await esperarNovaTela(tabId, idAviso, 5, { comAviso: true });
    if (r === 'navegou') { await delay(300); return soma; }
    // o aviso voltou (outro item)
    if (r === 'aviso' && tentativa < 3) {
      const r2 = await handleRoundingModal(tabId);
      if (r2?.handled) return soma + await concluirArredondamento(tabId, r2, tentativa + 1);
    }
  } else if (clicou === 'navegou') {
    await esperarNovaTela(tabId, idAviso, 5);
  }
  await delay(800);
  return soma;
}

// Passivo Anterior: normalmente só avançar. Se a tela exigir alguma escolha, a
// conferência de avanço em runEmpenhoStep para e mostra a mensagem do CNET.
async function runStep7(tabId) {
  await appendLog('[Etapa 7] Passivo Anterior — avançando…', 'info');
  notifySidePanel({ type: 'LOG', msg: '[Etapa 7] Passivo Anterior — avançando…', level: 'info' });
  const r = await execInPage(tabId, () => {
    const btn =
      document.querySelector('button.submeter') ||
      Array.from(document.querySelectorAll('button')).find(b => b.textContent?.trim().includes('Próxima'));
    if (!btn) return { ok: false, error: 'Botão "Próxima Etapa" não encontrado na Etapa 7' };
    btn.click();
    return { ok: true };
  });
  return r ?? { ok: false, error: 'Script não retornou na Etapa 7' };
}

async function runStepStub(tabId, step) {
  await appendLog(`[Etapa ${step}] ⚠ HTML pendente — pausando`, 'warn');
  return {
    ok: false,
    error: `Etapa ${step} ainda não implementada. Compartilhe o HTML desta etapa para adicionar os seletores.`,
  };
}

// ── Etapa 8: conferência, emissão no SIAFI e finalização ─────────────────────

const RX_JA_ENVIADO = /PROCESSAMENTO|EMITID|EMPENHAD|ENVIAD|SUCESSO/i;
const RX_ERRO_SIAFI = /ERRO|REJEIT|RECUSAD|FALH|CANCELAD|INVALID/i;
const extrairNE = s => (String(s ?? '').match(/\d{4}NE\d{6}(?!\d)/) ?? [null])[0];
const numBR = s => {
  const t = String(s ?? '').replace(/[^\d,.-]/g, '');
  if (!t) return null;
  const n = parseFloat(t.includes(',') ? t.replace(/\./g, '').replace(',', '.') : t);
  return Number.isFinite(n) ? n : null;
};
const fmtR$ = v => v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Valor pedido na solicitação: soma dos itens, senão o total
function valorSolicitadoDe(payload) {
  const itens = payload.itensEmpenho ?? [];
  if (itens.length) return itens.reduce((s, it) => s + (parseFloat(String(it.valor).replace(',', '.')) || 0), 0);
  return numBR(payload.total) ?? 0;
}

// Resumo da tela da Etapa 8 (função serializada — autocontida)
function lerEtapa8() {
  const norm = s => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toUpperCase();
  const limpa = s => String(s ?? '').replace(/\s+/g, ' ').trim();
  const valorDe = (...rotulos) => {
    const alvos = rotulos.map(norm);
    for (const tr of document.querySelectorAll('tr')) {
      const c = tr.querySelectorAll('th, td');
      if (c.length >= 2 && alvos.includes(norm(c[0].textContent))) return limpa(c[1].textContent);
    }
    for (const r of document.querySelectorAll('dt, label, strong, b')) {
      if (!alvos.includes(norm(r.textContent))) continue;
      const v = r.nextElementSibling?.textContent ?? r.parentElement?.nextElementSibling?.textContent;
      if (v != null) return limpa(v);
    }
    return null;
  };
  const botao = re => Array.from(document.querySelectorAll('button, a.btn, input[type="submit"]'))
    .find(b => re.test(limpa(b.textContent || b.value)));
  const emitir = botao(/Emitir\s+Empenho/i);
  return {
    url: location.href.split('#')[0],
    situacao:  valorDe('Situação'),
    mensagem:  valorDe('Mensagem SIAFI'),
    numero:    valorDe('Número Empenho', 'Número do Empenho', 'Nº Empenho', 'N° Empenho', 'Número da NE', 'Nota de Empenho', 'Número NE'),
    valor:     valorDe('Valor Total'),
    tipo:      valorDe('Tipo de Empenho', 'Tipo Empenho'),
    descricao: valorDe('Descrição', 'Descricao'),
    temEmitir: !!emitir,
    emitirHabilitado: !!emitir && !emitir.disabled && !emitir.classList.contains('disabled'),
  };
}

// Clica o botão cujo texto casa com `fonte` (regex) e retorna logo: se a página
// navegar em seguida, o script já terminou (função serializada — autocontida)
function clicarBotaoEtapa8(fonte) {
  const re = new RegExp(fonte, 'i');
  const btn = Array.from(document.querySelectorAll('button, a.btn, input[type="submit"]'))
    .find(b => re.test(String(b.textContent || b.value || '').replace(/\s+/g, ' ')));
  if (!btn) return { ok: false, error: `botão não encontrado (${fonte})` };
  if (btn.disabled || btn.classList.contains('disabled')) return { ok: false, desabilitado: true, error: 'botão desabilitado' };
  // confirm()/alert() nativos travariam a página até alguém responder: aceitam sozinhos,
  // mas o texto fica guardado (um erro do CNET aparece no relatório em vez de sumir)
  const conf = window.confirm, al = window.alert;
  window.__gapmnAvisos = [];
  window.confirm = m => { window.__gapmnAvisos.push(String(m ?? '')); return true; };
  window.alert = m => { window.__gapmnAvisos.push(String(m ?? '')); };
  setTimeout(() => { window.confirm = conf; window.alert = al; }, 60000);
  btn.click();
  return { ok: true };
}

// Avisos que o CNET mostrou depois do clique: alert/confirm guardados e mensagens de
// erro visíveis na tela (SweetAlert, toast, alerta)
function lerAvisosEmissao() {
  const visivel = e => e && getComputedStyle(e).display !== 'none' && e.getClientRects().length > 0;
  const tela = Array.from(document.querySelectorAll('.swal2-html-container, .swal2-title, .toast-message, .alert-danger, .alert-warning, .invalid-feedback'))
    .filter(visivel).map(e => e.textContent.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const emitir = Array.from(document.querySelectorAll('button, a.btn, input[type="submit"]'))
    .find(b => /Emitir\s+Empenho/i.test(String(b.textContent || b.value || '')));
  return {
    avisos: [...new Set([...(window.__gapmnAvisos ?? []), ...tela])].filter(t => !/^deseja|confirma/i.test(t)).slice(0, 4),
    emitirHabilitado: !!emitir && !emitir.disabled && !emitir.classList.contains('disabled'),
  };
}

// Aceita a confirmação em modal (SweetAlert / Bootstrap), se aparecer
async function confirmarModalEtapa8() {
  for (let t = 0; t < 8; t++) {
    await new Promise(r => setTimeout(r, 250));
    const ok = Array.from(document.querySelectorAll('.swal2-confirm, .modal.show .btn-primary, .modal.show .btn-success, .modal.in .btn-primary, .bootbox .btn-primary'))
      .find(b => b.offsetParent !== null);
    if (ok) { ok.click(); return { confirmou: String(ok.textContent).trim() }; }
  }
  return { confirmou: null };
}

// Clica e aceita a confirmação. A página recarregar logo após o clique não é falha.
async function clicarEConfirmar(tabId, fonte) {
  const navegou = e => /destroyed|navigat|unload|removed|no frame|closed/i.test(String(e?.message ?? e));
  let r;
  try {
    // Com limite: página bloqueada (aviso aberto) não responde. Sem resposta, o clique
    // pode ter acontecido depois: quem chama trata como "conferir", nunca como "falhou"
    // (a corrida mantém o erro de "página navegou", que aqui significa clique feito)
    r = await Promise.race([execInPage(tabId, clicarBotaoEtapa8, [fonte]), new Promise(res => setTimeout(() => res(null), 30000))]);
  } catch (e) {
    return navegou(e) ? { ok: true, navegou: true } : { ok: false, error: e.message };
  }
  if (!r) return { ok: false, semResposta: true, error: `a página não respondeu ao clique (${motivoSemResposta(await impressaoDaPagina(tabId))})` };
  if (!r?.ok) return r;
  await delay(300);
  // Com limite: se a página navegar enquanto procura o modal, o script não responde
  await comLimite(execInPage(tabId, confirmarModalEtapa8).catch(() => null), 8000);
  return r;
}

/** Confere a tela; sem divergência (e sem confirmação manual ligada), segue para emitir */
async function runStep8(tabId, payload, dryRun) {
  if (dryRun) {
    await appendLog('[DRY-RUN] Simulação completa. Emissão NÃO foi efetuada.', 'warn');
    return { ok: true, ne: 'DRY-RUN', summary: { dryRun: true } };
  }
  const tela = await comLimite(execInPage(tabId, lerEtapa8).catch(() => null), 20000);
  if (!tela) return { ok: false, error: 'Não consegui ler a tela da Etapa 8' };

  const motivos = [];
  if (!tela.temEmitir && !RX_JA_ENVIADO.test(tela.situacao ?? '')) motivos.push('botão "Emitir Empenho SIAFI" não encontrado');
  // Compara com o pedido na solicitação. O arredondamento "para menos" deixa a tela
  // alguns centavos abaixo (dentro da tolerância); a diferença vira reforço irrisório.
  const esperado = valorSolicitadoDe(payload);
  const naTela = numBR(tela.valor);
  await setState({ valorNaTela: naTela });
  // Com o aviso de arredondamento tratado ("Corrigir agora"), a tela fica até um degrau
  // abaixo (ex.: R$ 178,50 de R$ 179,52) — a diferença vira o reforço irrisório
  const st8 = await getState();
  const folgaArred = st8.arredondado && naTela !== null && naTela < esperado ? (st8.degrauArredondamento ?? LIMITE_IRRISORIO) + 0.01 : 0;
  if (naTela !== null && esperado > 0 && Math.abs(naTela - esperado) > Math.max(1, esperado * 0.005, folgaArred)) {
    motivos.push(`valor na tela R$ ${fmtR$(naTela)} ≠ solicitado R$ ${fmtR$(esperado)}`
      + (naTela < esperado ? ' (o CNET pode ter limitado ao saldo do item/contrato, ou um item não foi preenchido — confira a minuta)' : ''));
  }
  // Sem ler o valor não há conferência: pede confirmação em vez de emitir no escuro
  if (naTela === null) motivos.push('não consegui ler o Valor Total na tela');
  const semAcento = x => String(x ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase();
  if (payload.tipoEmpenho && tela.tipo && !semAcento(tela.tipo).includes(semAcento(payload.tipoEmpenho))) {
    motivos.push(`tipo de empenho na tela "${tela.tipo}" ≠ escolhido "${payload.tipoEmpenho}"`);
  }
  const sol = String(payload.numeroSolicitacao ?? '').toUpperCase();
  if (sol && tela.descricao && !tela.descricao.toUpperCase().includes(sol)) motivos.push(`a descrição não cita a solicitação ${sol}`);

  // Confirmação manual ligada no painel: para em toda solicitação. Desligada, uma
  // divergência não trava a fila: a minuta fica pronta no CNET, sem emitir, e vai
  // para o relatório com o motivo.
  const { [CONFIRMAR_ANTES_KEY]: confirmarAntes } = await chrome.storage.local.get(CONFIRMAR_ANTES_KEY);
  if (confirmarAntes) {
    const motivo = motivos.length ? `Conferência automática: ${motivos.join('; ')} — confira e confirme` : 'Confirmação manual ligada no painel';
    await appendLog(`[Etapa 8] ⚠ CHECKPOINT — ${motivo}`, 'warn');
    return { ok: true, checkpoint: true, summary: { ...tela, payload, motivo } };
  }
  if (motivos.length) {
    return { ok: false, error: `conferência antes de emitir: ${motivos.join('; ')} — minuta ficou pronta no CNET, sem emitir`, urlMinuta: tela.url };
  }
  await logVisivel(`[Etapa 8] Conferido: valor R$ ${fmtR$(naTela ?? esperado)}${sol ? `, solicitação ${sol}` : ''}`, 'info');
  return { ok: true, emitir: true };
}

/** Guarda o empenho (solicitação → NE) na lista permanente da extensão */
async function registrarEmpenho(registro) {
  const data = await chrome.storage.local.get(REGISTRO_KEY);
  const lista = [...(data[REGISTRO_KEY] ?? []), registro];
  await chrome.storage.local.set({ [REGISTRO_KEY]: lista.slice(-1000) });
}

// Solicitação que já tem esta NE registrada (outra que não `solicitacao`), ou null.
// Uma NE nunca vale para duas solicitações: se a tela mostrar uma assim, não é desta.
async function donoDaNE(ne, solicitacao) {
  const data = await chrome.storage.local.get(REGISTRO_KEY);
  const r = (data[REGISTRO_KEY] ?? []).find(x => x.ne === ne && x.solicitacao !== solicitacao && (x.status ?? 'emitido') === 'emitido');
  return r ? (r.solicitacao || '?') : null;
}

async function lerRegistro(id) {
  const data = await chrome.storage.local.get(REGISTRO_KEY);
  return (data[REGISTRO_KEY] ?? []).find(r => r.id === id) ?? null;
}

async function atualizarRegistro(id, patch) {
  const data = await chrome.storage.local.get(REGISTRO_KEY);
  const lista = (data[REGISTRO_KEY] ?? []).map(r => (r.id === id ? { ...r, ...patch } : r));
  await chrome.storage.local.set({ [REGISTRO_KEY]: lista });
}

// Recarrega a minuta por GET (nunca reenvia formulário) e lê a tela
async function recarregarMinuta(tabId, url) {
  try { await navegarPara(tabId, url, 8, 35000); } catch { return null; }
  return comLimite(execInPage(tabId, lerEtapa8).catch(() => null), 15000);
}

/**
 * Emite no SIAFI (se ainda não foi), espera o número da NE, finaliza e registra.
 * Retorna { ok, status } — status: 'emitido' | 'pendente' | 'erro'.
 */
async function emitirEFinalizar(tabId, payload) {
  const antes = await comLimite(execInPage(tabId, lerEtapa8).catch(() => null), 20000);
  if (!antes) return { ok: false, error: 'Não consegui ler a tela da Etapa 8' };
  const url = antes.url;

  if (RX_JA_ENVIADO.test(antes.situacao ?? '')) {
    // Retomar depois da emissão: nunca emite duas vezes
    await logVisivel(`[Etapa 8] Já enviado ao SIAFI (situação: ${antes.situacao}) — não emito de novo`, 'warn');
  } else if (!antes.emitirHabilitado) {
    return { ok: false, url, error: `"Emitir Empenho SIAFI" ${antes.temEmitir ? 'está desabilitado' : 'não foi encontrado'} (situação: ${antes.situacao || '—'}) — confira no CNET` };
  } else {
    await logVisivel('[Etapa 8] Emitindo empenho no SIAFI…', 'info');
    const r = await clicarEConfirmar(tabId, 'Emitir\\s+Empenho');
    if (!r?.ok) return { ok: false, url, talvezEmitido: !!r?.semResposta, error: `Não consegui clicar em "Emitir Empenho SIAFI": ${r?.error ?? 'sem resposta'}` };
  }

  // O SIAFI devolve o número depois ("EM PROCESSAMENTO"): relê a minuta por ~1,5 min.
  // Sem nenhuma mudança (situação ainda "EM ANDAMENTO", botão ativo, sem aviso de erro),
  // o clique não pegou: clica Emitir mais uma vez.
  let ne = null, situacao = antes.situacao, mensagem = null, erro = false;
  const ignoradas = new Set();
  const avisosCnet = [];
  let tentouDeNovo = false;
  for (let i = 1; i <= 12 && !ne && !erro; i++) {
    await delay(4000);
    if (i === 1 || i === 7) {
      const a = await comLimite(execInPage(tabId, lerAvisosEmissao), 4000);
      for (const t of a?.avisos ?? []) if (!avisosCnet.includes(t)) avisosCnet.push(t);
      if (avisosCnet.length) await logVisivel(`⚠ [Etapa 8] O CNET avisou: ${avisosCnet.join(' | ').slice(0, 300)}`, 'warn');
      if (i === 7 && !tentouDeNovo && !avisosCnet.length && a?.emitirHabilitado && !RX_JA_ENVIADO.test(situacao ?? '')) {
        tentouDeNovo = true;
        await logVisivel('⚠ [Etapa 8] O CNET não registrou o "Emitir" (situação ainda ' + (situacao || '—') + ') — clicando de novo…', 'warn');
        await clicarEConfirmar(tabId, 'Emitir\\s+Empenho');
        continue;
      }
    }
    const r = i % 2 === 0
      ? await recarregarMinuta(tabId, url)
      : await comLimite(execInPage(tabId, lerEtapa8).catch(() => null), 15000);
    if (!r) continue;
    situacao = r.situacao ?? situacao;
    mensagem = r.mensagem || mensagem;
    // Só o número do campo da própria minuta ou da mensagem do SIAFI: a página mostra
    // NEs de outros empenhos, e "qualquer NE nova na tela" já anotou a de outra solicitação
    ne = extrairNE(r.numero) ?? extrairNE(r.mensagem);
    if (ne) {
      const dono = await donoDaNE(ne, payload.numeroSolicitacao ?? '');
      if (dono) {
        if (!ignoradas.has(ne)) await logVisivel(`⚠ A tela mostrou a NE ${ne}, já registrada para ${dono} — ignorada`, 'warn');
        ignoradas.add(ne);
        ne = null;
      }
    }
    // erro só depois de reler a minuta (uma situação "ERRO" antiga ainda pode estar na tela)
    erro = !ne && i >= 3 && RX_ERRO_SIAFI.test(situacao ?? '');
  }
  const status = ne ? 'emitido' : erro ? 'erro' : 'pendente';
  // Sem número e sem situação de envio, a emissão não aconteceu: não finaliza
  if (status === 'pendente' && !RX_JA_ENVIADO.test(situacao ?? '')) {
    return { ok: false, url, talvezEmitido: true, error: `cliquei em Emitir${tentouDeNovo ? ' (duas vezes)' : ''}, mas o CNET não mostrou a emissão (situação: ${situacao || '—'})`
      + (avisosCnet.length ? ` — o CNET avisou: ${avisosCnet.join(' | ').slice(0, 300)}` : '') + ' — confira a minuta antes de empenhar de novo' };
  }

  // Finaliza a minuta (não quando o SIAFI recusou: ela precisa ser corrigida)
  if (status !== 'erro') {
    const f = await clicarEConfirmar(tabId, '\\bFinalizar\\b');
    if (f?.ok) {
      await logVisivel('[Etapa 8] Minuta finalizada ✓', 'info');
      try { await waitForNavigation(tabId, 15000); } catch {}
    } else {
      await logVisivel(`⚠ [Etapa 8] Não finalizei a minuta (${f?.error ?? 'sem resposta'}) — finalize no CNET depois`, 'warn');
    }
  }

  // Empenhado = Valor Total da minuta (lido na tela); o que faltar para o
  // solicitado é o reforço irrisório
  const st = await getState();
  const valorSolicitado = valorSolicitadoDe(payload);
  const valorEmpenhado = numBR(antes.valor) ?? st.valorNaTela ?? st.valorEmpenhado ?? valorSolicitado;
  const falta = Math.round((valorSolicitado - valorEmpenhado) * 100) / 100;
  const reforco = falta >= 0.01 ? falta : 0;
  const registro = {
    id:          `${Date.now()}-${payload.numeroSolicitacao ?? ''}`,
    data:        new Date().toISOString(),
    solicitacao: payload.numeroSolicitacao ?? '',
    ne,
    status,
    situacao:    situacao ?? '',
    mensagem:    mensagem ?? '',
    url,
    fornecedor:  payload.fornecedorNome ?? '',
    cnpj:        String(payload.fornecedorCnpj ?? payload.fornecedorCNPJ ?? '').replace(/\D/g, ''),
    origem:      payload.tipoOrigem === 'compra' ? `Compra ${payload.numeroCompra ?? ''}` : (payload.contrato ?? ''),
    pag:         payload.pag ?? '',      // para o subprocesso no SILOMS
    ugCred:      payload.ugCred ?? '',
    valorSolicitado,
    valorEmpenhado,
    reforco,
    reforcoStatus: reforco && status !== 'erro' ? 'a-fazer' : undefined,
    arredondado: !!st.arredondado,
    motivo:      status === 'erro' ? `SIAFI recusou${mensagem ? `: ${mensagem}` : ''}` : '',
    verificacaoFornecedor: payload.verificacaoFornecedor?.resumo ?? "",
  };
  await registrarEmpenho(registro);
  // Chegou ao SIAFI: a sequência de falhas de sistema acabou
  await setState({ falhasSeguidas: 0 });

  const resumo = status === 'emitido' ? `NE ${ne}`
    : status === 'erro' ? `ERRO SIAFI${mensagem ? `: ${mensagem}` : ''}`
    : 'NE em processamento no SIAFI — o número será buscado no fim da fila';
  await appendLog(
    `${status === 'emitido' ? '✅' : status === 'erro' ? '❌' : '⏳'} ${registro.solicitacao || 'Solicitação'} → ${resumo} | Empenhado: R$ ${fmtR$(valorEmpenhado)}`,
    status === 'emitido' ? 'success' : status === 'erro' ? 'error' : 'warn',
  );
  if (reforco && status !== 'erro') {
    await logVisivel(`⚠ ${registro.solicitacao || 'Solicitação'}: faltou R$ ${fmtR$(reforco)} para o solicitado (R$ ${fmtR$(valorSolicitado)} pedido, R$ ${fmtR$(valorEmpenhado)} empenhado) — reforço irrisório`, 'warn');
  }
  notifySidePanel({ type: 'DONE', ne, status, mensagem, payload, valorEmpenhado, valorSolicitado, reforco });
  return { ok: true, status, ne, reforco, registroId: registro.id };
}

/**
 * Revisita as minutas que ficaram "em processamento" e anota o número da NE.
 * `desde` (ISO) limita aos registros desta fila; null = todos os pendentes.
 */
async function resolverPendentes(tabId, desde = null) {
  const data = await chrome.storage.local.get(REGISTRO_KEY);
  const pendentes = (data[REGISTRO_KEY] ?? []).filter(r => r.status === 'pendente' && r.url && (!desde || r.data >= desde));
  if (!pendentes.length) return { achadas: 0, restantes: 0 };
  await appendLog(`🔎 Buscando o número de ${pendentes.length} NE(s) que ficaram em processamento…`, 'info');
  notifySidePanel({ type: 'LOG', msg: `🔎 Buscando ${pendentes.length} NE(s) em processamento…`, level: 'info' });
  let achadas = 0;
  for (const reg of pendentes) {
    const r = await recarregarMinuta(tabId, reg.url);
    if (!r) continue;
    let ne = extrairNE(r.numero) ?? extrairNE(r.mensagem);
    // Alteração (reforço/anulação) fica com o número da própria NE alterada
    if (reg.neAlterar) { if (ne !== reg.neAlterar || !/EMITID|SUCESSO/i.test(r.situacao ?? '')) ne = null; }
    else if (ne && await donoDaNE(ne, reg.solicitacao)) ne = null;
    if (ne) {
      achadas++;
      await atualizarRegistro(reg.id, { ne, status: 'emitido', situacao: r.situacao ?? '', mensagem: r.mensagem ?? '' });
      await logVisivel(`✅ ${reg.solicitacao} → NE ${ne}`, 'success');
      // Finaliza se tinha ficado aberta
      await clicarEConfirmar(tabId, '\\bFinalizar\\b');
      try { await waitForNavigation(tabId, 10000); } catch {}
    } else if (RX_ERRO_SIAFI.test(r.situacao ?? '')) {
      await atualizarRegistro(reg.id, { status: 'erro', situacao: r.situacao ?? '', mensagem: r.mensagem ?? '' });
      await logVisivel(`❌ ${reg.solicitacao} → ERRO SIAFI${r.mensagem ? `: ${r.mensagem}` : ''}`, 'error');
    }
  }
  return { achadas, restantes: pendentes.length - achadas };
}

/** Botão do painel: busca as NEs pendentes (só com o robô parado) */
export async function resolverPendentesAgora(tabId) {
  if (maquinaAtiva) return { ocupado: true };
  maquinaAtiva = true;
  try {
    return await resolverPendentes(tabId, null);
  } finally {
    maquinaAtiva = false;
  }
}

/** Se há solicitação na fila: abre o formulário de nova minuta e a põe para rodar */
async function prepararProximoDaFila(tabId) {
  const s = await getState();
  if (!s.queue?.length) return false;
  const [next, ...rest] = s.queue;
  await appendLog(`▶ Próxima da fila: ${next.numeroSolicitacao}${rest.length ? ` (depois dela, mais ${rest.length})` : ''}`, 'info');
  // A Etapa 0 abre a nova minuta (botão "Adicionar Minuta de Empenho" na tela atual)
  await delay(1000);
  await setState({ state: 'running', ...estadoInicialDoPayload(next), payload: next, queue: rest, valorEmpenhado: null, valorNaTela: null, arredondado: false, degrauArredondamento: null });
  notifySidePanel({ type: 'NEXT_AVAILABLE', numero: next.numeroSolicitacao, payload: next, restantes: rest.length });
  return true;
}

/** Depois de um empenho: próximo da fila, ou fim (buscando as NEs pendentes) */
async function seguirFila(tabId) {
  if (await prepararProximoDaFila(tabId)) return true;
  const s = await getState();
  const r = await resolverPendentes(tabId, s.inicioFila ?? null);
  if (r.restantes) {
    await logVisivel(`⏳ ${r.restantes} NE(s) ainda em processamento — use "Buscar pendentes" na lista de empenhos gerados mais tarde`, 'warn');
  }
  await setState({ state: 'done' });
  // Resumo da fila: empenhadas, reforço irrisório e as que tiveram problema
  const data = await chrome.storage.local.get(REGISTRO_KEY);
  const daFila = (data[REGISTRO_KEY] ?? []).filter(r => !s.inicioFila || r.data >= s.inicioFila);
  const emitidas = daFila.filter(r => r.status === 'emitido' || r.status === 'pendente');
  // Reforço irrisório que o robô não conseguiu fazer (os feitos não contam)
  const comReforco = emitidas.filter(r => (r.reforco ?? 0) > 0 && r.reforcoStatus !== 'feito');
  const problemas = daFila.filter(r => ['falhou', 'erro', 'conferir'].includes(r.status));
  const totalReforco = comReforco.reduce((t, r) => t + r.reforco, 0);
  await logVisivel(
    `🏁 Fila concluída: ${emitidas.length} empenhada(s)` +
    (comReforco.length ? ` · ${comReforco.length} com irrisório a fazer (R$ ${fmtR$(totalReforco)})` : '') +
    (problemas.length ? ` · ${problemas.length} com problema` : ''),
    'success',
  );
  notifySidePanel({ type: 'QUEUE_DONE', inicioFila: s.inicioFila ?? null });
  return false;
}

/** Emite depois da confirmação manual no checkpoint; true se o próximo da fila ficou pronto */
async function runStep8Confirm(tabId, payload) {
  await appendLog('[Etapa 8] Usuário confirmou — emitindo empenho…', 'info');
  const r = await emitirEFinalizar(tabId, payload);
  if (!r.ok) return pularSolicitacao(tabId, 8, r.error, { status: r.talvezEmitido ? 'conferir' : 'falhou', url: r.url ?? null });
  return depoisDoEmpenho(tabId, payload, r);
}

// ── Fluxo ALTERAÇÃO: reforço, anulação e irrisórios ──────────────────────────
// Reforço e anulação vêm de solicitações ("Anulação Ident/OC …"); a NE a alterar
// o usuário informa na revisão. Os irrisórios completam o arredondamento "para
// menos": depois de um empenho novo ou de um reforço → REFORÇO IRRISÓRIO; depois
// de uma anulação → ANULAÇÃO SALDO IRRISÓRIO (o que faltou anular).

const OPERACAO_CNET = { reforco: 'REFORÇO', anulacao: 'ANULAÇÃO' };
const COMPLEMENTO_CNET = { reforco: 'REFORÇO IRRISÓRIO', anulacao: 'ANULAÇÃO SALDO IRRISÓRIO' };
const ROTULO_ALT = ['A1 busca da NE', 'A2 Adicionar Alteração', 'A3 Subelemento', 'A4 Passivo Anterior', 'A5 emissão'];
const STEP_PAINEL_ALT = [1, 2, 5, 7, 8];   // pontos do indicador de etapas do painel
// A diferença do arredondamento nunca passa de um "degrau" (para mais − para menos,
// lido no modal): acima disso algum valor está errado e o robô não faz sozinho.
// Sem o degrau, vale este teto.
const LIMITE_IRRISORIO = 10;
const limiteIrrisorio = degrau => (degrau > 0 ? degrau + 0.01 : LIMITE_IRRISORIO);

// Lista "Alteração do empenho": quantas emitidas / com erro (para achar a nova)
const RX_EMITIDA = /EMITID|EMPENHAD/i;
const resumoLista = l => ({
  total: l.linhas.length,
  emitidos: l.linhas.filter(x => RX_EMITIDA.test(x.situacao)).length,
  erros: l.linhas.filter(x => RX_ERRO_SIAFI.test(x.situacao)).length,
});
// Compara com a lista de antes de "Adicionar Alteração": uma emitida a mais = a nossa
function avaliarLista(lista, antes, ne) {
  const agora = resumoLista(lista);
  if (antes && agora.emitidos > antes.emitidos) {
    const nes = lista.linhas.filter(x => RX_EMITIDA.test(x.situacao)).map(x => extrairNE(x.mensagem)).filter(Boolean);
    return { ne: nes.includes(ne) ? ne : (nes[nes.length - 1] ?? ne), situacao: 'EMPENHO EMITIDO' };
  }
  if (antes && agora.erros > antes.erros) {
    const l = lista.linhas.filter(x => RX_ERRO_SIAFI.test(x.situacao)).pop();
    return { erro: true, situacao: l.situacao, mensagem: l.mensagem };
  }
  const proc = lista.linhas.find(x => /PROCESSAMENTO|ENVIAD|AGUARD/i.test(x.situacao));
  return { situacao: proc?.situacao ?? null, semReferencia: !antes };
}
const comLimite = (p, ms = 10000) => Promise.race([Promise.resolve(p).catch(() => null), new Promise(r => setTimeout(() => r(null), ms))]);

// NE de ano anterior = restos a pagar: o CNET pode não oferecer a alteração dela
function dicaRestosAPagar(ne) {
  const ano = parseInt(String(ne ?? '').slice(0, 4), 10);
  return ano && ano < new Date().getFullYear()
    ? ` — a ${ne} é de ${ano} (restos a pagar): a alteração de RP costuma ser feita no SIAFI Web, não no CNET`
    : '';
}

function estadoInicialDoPayload(payload) {
  if (!payload?.operacao) return { flow: 'empenho-cnet', step: 0, altStep: null, alteracao: null, altValorFeito: null, altDegrau: null, altRestos: null };
  return {
    flow: 'alteracao-cnet', step: 0, altStep: 0, altValorFeito: null, altDegrau: null, altRestos: null,
    alteracao: {
      ne: payload.neAlterar, tipo: payload.operacao, operacao: OPERACAO_CNET[payload.operacao],
      operacaoIrrisoria: COMPLEMENTO_CNET[payload.operacao],
      valor: valorSolicitadoDe(payload), itens: payload.itensEmpenho ?? [],
      origem: 'solicitacao', solicitacao: payload.numeroSolicitacao ?? '',
    },
  };
}

/**
 * Abre um endereço na aba e espera o DOCUMENTO NOVO montar. Não usa o "complete" da
 * aba: no CNET ele chega 30–50 s depois (recursos de fora) e o "complete" atrasado da
 * tela ANTERIOR, chegando logo após o clique, fazia o robô seguir antes da tela nova;
 * o script seguinte caía na página que estava saindo e nunca respondia (o robô parava
 * em "Alteração do empenho aberta" sem erro). Ver esperarNovaTela.
 */
async function navegarPara(tabId, url, etapa = 'A', maxMs = 90000) {
  const idAntes = await idDoDocumento(tabId);
  const desde = Date.now();
  const nav = idAntes ? null : waitForNavigation(tabId, 30000).catch(() => {});
  await chrome.tabs.update(tabId, { url });
  if (idAntes) await esperarNovaTela(tabId, idAntes, etapa, { desde, maxMs });
  else await nav;
  await delay(600);
}

/** Depois de um clique que navega: espera o documento novo (idAntes = antes do clique) */
async function esperarTelaDoClique(tabId, idAntes, etapa, maxMs = 90000) {
  if (!idAntes) { try { await waitForNavigation(tabId, 20000); } catch {} await delay(800); return 'tempo'; }
  const r = await esperarNovaTela(tabId, idAntes, etapa, { maxMs });
  await delay(r === 'navegou' ? 300 : 800);
  return r;
}

// Clique que pode navegar: a página sumir junto com o script não é falha
async function execQuePodeNavegar(tabId, func, args = []) {
  try {
    return await execInPage(tabId, func, args);
  } catch (e) {
    if (/destroyed|navigat|unload|removed|no frame|closed/i.test(String(e?.message ?? e))) return { ok: true, navegou: true };
    throw e;
  }
}

async function runAlteracaoStep(s) {
  const { altStep: passo = 0, alteracao: a, cnetTabId: tabId } = s;
  notifySidePanel({ type: 'STEP', step: STEP_PAINEL_ALT[passo] ?? 8 });
  await appendLog(`━ ${a.operacao} da ${a.ne} — ${ROTULO_ALT[passo]}`, 'info');
  const antes = passo === 2 || passo === 3 ? await impressaoDaPagina(tabId) : null;
  const etiqueta = ROTULO_ALT[passo].split(' ')[0];   // A1…A5, para os avisos de CNET lento
  try {
    let r;
    if (passo === 0) r = await altAbrirNE(tabId, a);
    else if (passo === 1) r = await altAdicionar(tabId);
    else if (passo === 2) r = await altSubelemento(tabId, a);
    else if (passo === 3) r = await altPassivo(tabId);
    else return await altFinalizar(tabId, s);
    if (!r?.ok) return falhaAlteracao(tabId, s, passo, r?.error ?? 'sem resposta da página');

    await setState({ altStep: passo + 1, ...(r.patch ?? {}) });
    if (r.esperarNavegacao) {
      await appendLog('⏳ Aguardando a próxima tela…', 'info');
      // A tela seguinte é o documento novo depois do clique em "Próxima" (r.idAntes);
      // na tela do Subelemento o aviso de arredondamento pode abrir nela mesma. O CNET
      // valida o formulário por AJAX antes de enviar: enquanto valida, não é "parado".
      if (r.idAntes) {
        const e = await esperarNovaTela(tabId, r.idAntes, etiqueta, { comAviso: passo === 2, maxMs: 180000 });
        await delay(e === 'navegou' ? 500 : 800);
      } else if (passo === 2) {
        if (await esperarNavegacaoOuAviso(tabId, 25000) === 'navegou') await delay(800);
      } else {
        try { await waitForNavigation(tabId, 25000); } catch {}
        await delay(800);
      }
    }
    if (passo === 2) {
      // O robô já digitou o "para menos". Se o CNET ainda abrir o modal de
      // arredondamento: "para menos" de novo; o que faltar vira o irrisório logo
      // depois da emissão
      const rounding = await handleRoundingModal(tabId);
      if (rounding?.handled) {
        await logVisivel(textoArredondamento(rounding, faltaDoArredondamento(rounding, a.itens, a.valor), COMPLEMENTO_CNET[a.tipo]), 'warn');
        const degrauModal = await concluirArredondamento(tabId, rounding);
        const st = await getState();
        await setState({ altValorFeito: rounding.totalEmpenhado || null, altRestos: null,
          altDegrau: Math.round(((st.altDegrau ?? 0) + degrauModal) * 100) / 100 || null });
      }
    }
    if (antes && !antes.bloqueada && r.esperarNavegacao) {
      const depois = await impressaoDaPagina(tabId);
      const parada = depois.bloqueada
        ? motivoSemResposta(depois)
        : (depois.caminho === antes.caminho && depois.titulo === antes.titulo)
          ? `a página não avançou${depois.erros?.length ? ` — CNET: ${depois.erros.join(' | ').replace(/[.\s]+$/, '')}` : ''}`
          : null;
      if (parada) return falhaAlteracao(tabId, s, passo, `cliquei em "Próxima", mas ${parada}`);
    }
    return true;
  } catch (err) {
    return falhaAlteracao(tabId, s, passo, `Exceção: ${err.message}`, { status: passo === 4 ? 'conferir' : 'falhou' });
  }
}

// CNET lento: a lista de Minutas (título, botão e tabela) monta depois do
// carregamento — olha por até 45 s e recarrega uma vez no meio (se souber o endereço)
async function esperarListaMinutas(tabId, url) {
  let p = null;
  for (let t = 0; t < 45000; t += 1500) {
    if (t === 21000 && url) {
      await logVisivel('A lista de Minutas de Empenho ainda não apareceu — recarregando a página…', 'warn');
      await navegarPara(tabId, url, 'A1');
    }
    p = await comLimite(execInPage(tabId, paginaMinutas).catch(() => null), 6000);
    if (p?.naLista) return p;
    await delay(1500);
  }
  return p;
}

/** A1: lista de minutas → pesquisa a NE → "Alterar Empenho" */
async function altAbrirNE(tabId, a) {
  if (!/^\d{4}NE\d{6}$/.test(a.ne ?? '')) return { ok: false, error: `NE a alterar inválida ("${a.ne ?? ''}") — informe na revisão (ex: 2026NE000552)` };
  // Depois de emitir, o CNET fica na lista de alterações desta NE: o irrisório começa dali
  const aqui = await comLimite(execInPage(tabId, lerListaAlteracoes));
  if (aqui?.naLista && aqui.linhas.some(x => extrairNE(x.mensagem) === a.ne)) {
    await logVisivel(`[Alteração] ${a.ne}: já na lista de alterações ✓`, 'info');
    return { ok: true };
  }
  let p = await comLimite(execInPage(tabId, paginaMinutas).catch(() => null), 6000);
  if (!p?.naLista) {
    const url = p?.menuHref || MINUTAS_URL;
    await logVisivel('[Alteração] Abrindo a lista de Minutas de Empenho…', 'info');
    await navegarPara(tabId, url, 'A1');
    p = await esperarListaMinutas(tabId, url);
    if (!p?.naLista) {
      const aba = await chrome.tabs.get(tabId).catch(() => null);
      const ondeFicou = p?.titulo ? `a tela ficou em "${p.titulo.slice(0, 60)}"` : `a tela ficou em ${aba?.url ?? '?'}`;
      return { ok: false, error: `não achei a lista de Minutas de Empenho em 45 s (abri ${url}; ${ondeFicou}) — abra Gestão Orçamentária › Minuta Empenho › Minutas no CNET e use Retomar` };
    }
  }
  // A busca é no servidor e espera dentro da página (até 20 s): com limite
  const buscar = () => comLimite(execInPage(tabId, buscarNEnaLista, [a.ne]).catch(e => ({ ok: false, error: e.message })), 45000);
  await logVisivel(`[Alteração] Pesquisando a ${a.ne} nas minutas…`, 'info');
  let idAntes = await idDoDocumento(tabId);
  let r = await buscar();
  if (!r?.ok && r?.removerFiltros) {
    await logVisivel('[Alteração] A NE não apareceu — removendo os filtros da lista e pesquisando de novo…', 'warn');
    const idFiltro = await idDoDocumento(tabId);
    const f = await comLimite(execQuePodeNavegar(tabId, removerFiltros), 15000);
    if (f?.href) await navegarPara(tabId, f.href, 'A1');
    else await esperarTelaDoClique(tabId, idFiltro, 'A1', 30000);
    await esperarListaMinutas(tabId, f?.href ?? null);
    idAntes = await idDoDocumento(tabId);
    r = await buscar();
  }
  if (!r) return { ok: false, error: `a lista de minutas não respondeu à pesquisa (${motivoSemResposta(await impressaoDaPagina(tabId))})` };
  if (!r.ok) return { ok: false, error: (r.error ?? 'sem resposta da lista de minutas') + dicaRestosAPagar(a.ne) };
  if (r.href) await navegarPara(tabId, r.href, 'A1');
  else await esperarTelaDoClique(tabId, idAntes, 'A1');
  const tela = await impressaoDaPagina(tabId);
  if (!/altera/i.test(`${tela.titulo ?? ''} ${tela.caminho ?? ''}`)) {
    return { ok: false, error: `cliquei em "Alterar Empenho", mas a tela é "${tela.titulo || tela.caminho || '?'}"${tela.bloqueada || tela.oculta ? ` (${motivoSemResposta(tela)})` : ''}` };
  }
  await logVisivel(`[Alteração] ${a.ne}: "Alteração do empenho" aberta ✓`, 'info');
  return { ok: true };
}

/**
 * A2: "Adicionar Alteração do empenho". Confere que o formulário do Subelemento abriu
 * (no CNET ele tem o mesmo título da lista, "Alteração do empenho"); se a tela ficou na
 * lista, volta e clica mais uma vez.
 */
async function altAdicionar(tabId) {
  // A lista de antes: depois de emitir, a alteração nova é a linha emitida a mais
  const lista = await comLimite(execInPage(tabId, lerListaAlteracoes));
  const patch = lista?.naLista ? { altListaAntes: resumoLista(lista), altListaUrl: lista.url } : { altListaAntes: null, altListaUrl: null };
  const urlLista = lista?.url ?? (await chrome.tabs.get(tabId).catch(() => null))?.url ?? null;
  let tela = null;
  for (let tentativa = 1; tentativa <= 2; tentativa++) {
    await logVisivel(`[Alteração] Clicando em "Adicionar Alteração do empenho"${tentativa > 1 ? ' (segunda tentativa)' : ''}…`, 'info');
    const idAntes = await idDoDocumento(tabId);
    const r = await comLimite(execQuePodeNavegar(tabId, adicionarAlteracao), 15000);
    if (r && !r.ok) return r;
    if (r?.href) await navegarPara(tabId, r.href, 'A2');
    else if (r) await esperarTelaDoClique(tabId, idAntes, 'A2');
    tela = await comLimite(execInPage(tabId, telaSubelementoAlteracao).catch(() => null), 10000);
    if (tela?.ok) {
      await logVisivel('[Alteração] Formulário do Subelemento aberto ✓', 'info');
      return { ok: true, patch };
    }
    if (tentativa === 1 && urlLista) {
      const porque = r ? `a tela ficou em "${tela?.titulo || tela?.url || 'sem resposta'}"` : motivoSemResposta(await impressaoDaPagina(tabId));
      await logVisivel(`⚠ [Alteração] O formulário do Subelemento não abriu (${porque}) — reabrindo a lista e tentando de novo…`, 'warn');
      await navegarPara(tabId, urlLista, 'A2');
    }
  }
  const final = tela ? `a tela ficou em "${tela.titulo || tela.url || '?'}"` : motivoSemResposta(await impressaoDaPagina(tabId));
  return { ok: false, error: `cliquei em "Adicionar Alteração do empenho" duas vezes, mas o formulário do Subelemento não abriu (${final})` };
}

/**
 * A3: Tipo Operação + valor/quantidade + Próxima Etapa. O valor que não fecha com
 * quantidade (5 casas) × unitário já vai "para menos"; a diferença (e o degrau,
 * que limita o irrisório) fica no estado para o irrisório logo depois da emissão.
 * O script espera dentro da página (itens por AJAX): com limite. Sem resposta, a tela
 * é recarregada (o script preso morre com ela) e o robô tenta mais uma vez.
 */
async function altSubelemento(tabId, a) {
  await logVisivel('[Alteração] Preenchendo Tipo Operação e valor…', 'info');
  const rodar = async () => {
    await maximizarTabelas(tabId, 'da alteração');
    const idAntes = await idDoDocumento(tabId);
    const r = await comLimite(
      execInPage(tabId, alteracaoSubelementoRunner, [a]).catch(e => ({ ok: false, error: `erro ao rodar na tela da alteração: ${e.message}` })),
      90000,
    );
    return { r, idAntes };
  };
  let { r, idAntes } = await rodar();
  if (!r) {
    const tela = await impressaoDaPagina(tabId);
    const aba = await chrome.tabs.get(tabId).catch(() => null);
    await logVisivel(`⚠ [Alteração] A tela da alteração não respondeu (${motivoSemResposta(tela)}) — recarregando e tentando de novo…`, 'warn');
    if (aba?.url) await navegarPara(tabId, aba.url, 'A3');
    ({ r, idAntes } = await rodar());
    if (!r) return { ok: false, error: `a tela da alteração não respondeu (duas tentativas; ${motivoSemResposta(await impressaoDaPagina(tabId))})` };
  }
  if (!r.ok) return { ...r, error: `${r.error}${r.semOperacao ? dicaRestosAPagar(a.ne) : ''}` };
  for (const f of r.feitos ?? []) await logVisivel(`[Alteração] ${f}`, 'info');
  if (r.arredondou) {
    await logVisivel(`⚠ [Alteração] R$ ${fmtR$(a.valor)} não fecha com quantidade × unitário: ${a.operacao} de R$ ${fmtR$(r.digitado)} ("para menos") e, logo depois da emissão, ${COMPLEMENTO_CNET[a.tipo]} de R$ ${fmtR$(Math.round((a.valor - r.digitado) * 100) / 100)}`, 'warn');
  }
  const patch = {
    altValorDigitado: r.digitado,
    altValorFeito: r.arredondou ? r.digitado : null,
    altDegrau: r.degrau > 0 ? r.degrau : null,
    altRestos: r.restos?.length ? r.restos : null,
  };
  return { ok: true, esperarNavegacao: true, patch, idAntes };
}

/** A4: Passivo Anterior (pula se a tela já é a de emitir) */
async function altPassivo(tabId) {
  const idAntes = await idDoDocumento(tabId);
  const r = await comLimite(execQuePodeNavegar(tabId, alteracaoPassivo), 15000);
  if (!r) return { ok: false, error: `o Passivo Anterior não respondeu (${motivoSemResposta(await impressaoDaPagina(tabId))})` };
  if (!r.ok) return r;
  if (r.jaNoFinal) return { ok: true };
  await logVisivel('[Alteração] Passivo Anterior — avançando…', 'info');
  return { ok: true, esperarNavegacao: true, idAntes };
}

/** A5: confere e emite (ou para no checkpoint, se a confirmação manual estiver ligada) */
async function altFinalizar(tabId, s) {
  const a = s.alteracao;
  if (s.dryRun) {
    await logVisivel(`[DRY-RUN] ${a.operacao} da ${a.ne} preenchido — emissão NÃO feita`, 'warn');
    return seguirFila(tabId);
  }
  const tela = await comLimite(execInPage(tabId, lerEtapa8).catch(() => null), 20000);
  if (!tela) return falhaAlteracao(tabId, s, 4, `Não consegui ler a tela de emissão da alteração (${motivoSemResposta(await impressaoDaPagina(tabId))})`);
  // Com arredondamento, a tela mostrando ainda o valor pedido = o "para menos" não
  // pegou, e o SIAFI recusaria (ER0462): não emite
  const naTela = numBR(tela.valor);
  if (s.altValorFeito && naTela !== null && Math.abs(naTela - a.valor) < 0.005 && Math.abs(naTela - s.altValorFeito) >= 0.01) {
    return falhaAlteracao(tabId, s, 4, `o CNET ficou com R$ ${fmtR$(naTela)}, não com o "para menos" R$ ${fmtR$(s.altValorFeito)} — o SIAFI recusaria (ER0462); não emiti`, { url: tela.url });
  }
  const valorFeito = s.altValorFeito || a.valor;
  const { [CONFIRMAR_ANTES_KEY]: confirmarAntes } = await chrome.storage.local.get(CONFIRMAR_ANTES_KEY);
  if (confirmarAntes) {
    const motivo = `${a.operacao} de R$ ${fmtR$(valorFeito)} na ${a.ne}${s.altValorFeito ? ` ("para menos" de R$ ${fmtR$(a.valor)}; a diferença vai de ${COMPLEMENTO_CNET[a.tipo]} em seguida)` : ''} — confira e confirme`;
    await appendLog(`[Alteração] ⚠ CHECKPOINT — ${motivo}`, 'warn');
    await setState({ state: 'checkpoint' });
    notifySidePanel({ type: 'CHECKPOINT', step: 8, summary: { ...tela, payload: s.payload, motivo } });
    return false;
  }
  return emitirAlteracao(tabId, s);
}

/**
 * Emite a alteração no SIAFI, espera a confirmação (a Mensagem SIAFI traz o número
 * da própria NE), finaliza, registra e — se o arredondamento deixou diferença —
 * emenda o irrisório. Retorna true se a máquina deve continuar.
 */
async function emitirAlteracao(tabId, s) {
  const a = s.alteracao;
  const payload = s.payload ?? {};
  const antes = await comLimite(execInPage(tabId, lerEtapa8).catch(() => null), 20000);
  if (!antes) return falhaAlteracao(tabId, s, 4, `Não consegui ler a tela de emissão da alteração (${motivoSemResposta(await impressaoDaPagina(tabId))})`);
  const url = antes.url;

  if (RX_JA_ENVIADO.test(antes.situacao ?? '')) {
    await logVisivel(`[Alteração] Já enviada ao SIAFI (situação: ${antes.situacao}) — não emito de novo`, 'warn');
  } else if (!antes.emitirHabilitado) {
    return falhaAlteracao(tabId, s, 4, `"Emitir Empenho SIAFI" ${antes.temEmitir ? 'está desabilitado' : 'não foi encontrado'} (situação: ${antes.situacao || '—'}) — confira no CNET`, { url });
  } else {
    await logVisivel(`[Alteração] Emitindo ${a.operacao} de R$ ${fmtR$(s.altValorFeito || a.valor)} na ${a.ne} no SIAFI…`, 'info');
    const r = await clicarEConfirmar(tabId, 'Emitir\\s+Empenho');
    // Sem resposta, o clique pode ter pegado depois: "conferir", para ninguém emitir de novo às cegas
    if (!r?.ok) return falhaAlteracao(tabId, s, 4, `Não consegui clicar em "Emitir Empenho SIAFI": ${r?.error ?? 'sem resposta'}`, { url, status: r?.semResposta ? 'conferir' : 'falhou' });
  }

  // O SIAFI responde depois ("EM PROCESSAMENTO"): relê por ~1,5 min. O CNET pode
  // ficar na tela da alteração ou voltar para a lista "Alteração do empenho" — aí a
  // nossa é a linha emitida (ou com erro) a mais que a lista de antes
  let ne = null, situacao = antes.situacao, mensagem = null, erro = false, naLista = false;
  for (let i = 1; i <= 15 && !ne && !erro; i++) {
    await delay(4000);
    let lista = await comLimite(execInPage(tabId, lerListaAlteracoes));
    if (lista?.naLista) {
      naLista = true;
      if (i % 3 === 0) {   // relê do servidor
        await comLimite(navegarPara(tabId, lista.url, 'A5', 30000), 35000);
        const nova = await comLimite(execInPage(tabId, lerListaAlteracoes));
        if (nova?.naLista) lista = nova;
      }
      const v = avaliarLista(lista, s.altListaAntes, a.ne);
      if (v.ne) { ne = v.ne; situacao = v.situacao; }
      else if (v.erro) { erro = true; situacao = v.situacao; mensagem = v.mensagem; }
      else if (v.situacao) situacao = v.situacao;
    } else {
      const r = i % 2 === 0 ? await comLimite(recarregarMinuta(tabId, url), 40000) : await comLimite(execInPage(tabId, lerEtapa8));
      if (!r) continue;
      situacao = r.situacao ?? situacao;
      mensagem = r.mensagem || mensagem;
      const lido = extrairNE(r.numero) ?? extrairNE(r.mensagem);
      if (lido === a.ne || (lido && /EMITID|SUCESSO/i.test(situacao ?? ''))) ne = lido;
      erro = !ne && i >= 3 && RX_ERRO_SIAFI.test(situacao ?? '');
    }
    if (i % 4 === 0 && !ne && !erro) await logVisivel(`⏳ [Alteração] Aguardando o SIAFI… (situação: ${situacao || '—'})`, 'info');
  }
  if (ne) await logVisivel(`[Alteração] SIAFI: ${a.operacao} emitida na ${ne} ✓${naLista ? ' (lista de alterações)' : ''}`, 'info');
  const status = ne ? 'emitido' : erro ? 'erro' : 'pendente';
  if (status === 'pendente' && !RX_JA_ENVIADO.test(situacao ?? '')) {
    return falhaAlteracao(tabId, s, 4, `cliquei em Emitir, mas o CNET não mostrou a emissão (situação: ${situacao || '—'}) — confira a alteração antes de fazer de novo`, { status: 'conferir', url });
  }
  if (ne && ne !== a.ne) await logVisivel(`⚠ A alteração voltou com a ${ne}, não a ${a.ne} — confira`, 'warn');

  // De volta à lista de alterações, o CNET já fechou a alteração: não há "Finalizar"
  const naListaAgora = (await comLimite(execInPage(tabId, lerListaAlteracoes)))?.naLista;
  if (status !== 'erro' && naListaAgora) {
    await logVisivel('[Alteração] O CNET voltou para a lista de alterações — finalizada ✓', 'info');
  } else if (status !== 'erro') {
    const f = await clicarEConfirmar(tabId, '\\bFinalizar\\b');
    if (f?.ok) { await logVisivel('[Alteração] Finalizada ✓', 'info'); try { await waitForNavigation(tabId, 15000); } catch {} }
    else await logVisivel(`⚠ [Alteração] Não finalizei (${f?.error ?? 'sem resposta'}) — finalize no CNET depois`, 'warn');
  }

  // O que o arredondamento deixou de fora (valor do modal "para menos")
  const valorFeito = s.altValorFeito || a.valor;
  const falta = Math.round((a.valor - valorFeito) * 100) / 100;
  const complemento = a.origem === 'solicitacao' && falta >= 0.01 ? falta : 0;
  const id = `${Date.now()}-${a.solicitacao}`;

  if (a.origem === 'solicitacao') {
    await registrarEmpenho({
      id, data: new Date().toISOString(), solicitacao: a.solicitacao, ne: ne ?? a.ne, status,
      operacao: a.tipo, neAlterar: a.ne, situacao: situacao ?? '', mensagem: mensagem ?? '', url,
      fornecedor: payload.fornecedorNome ?? '', cnpj: String(payload.fornecedorCnpj ?? '').replace(/\D/g, ''),
      origem: payload.contrato ?? '', pag: payload.pag ?? '', ugCred: payload.ugCred ?? '',
      valorSolicitado: a.valor, valorEmpenhado: valorFeito,
      reforco: complemento, reforcoStatus: complemento && status !== 'erro' ? 'a-fazer' : undefined,
      arredondado: !!s.altValorFeito,
      motivo: status === 'erro' ? `SIAFI recusou${mensagem ? `: ${mensagem}` : ''}` : '',
      verificacaoFornecedor: payload.verificacaoFornecedor?.resumo ?? '',
    });
  } else if (a.registroId) {
    await atualizarRegistro(a.registroId, {
      reforcoStatus: status === 'emitido' ? 'feito' : status, reforcoEm: new Date().toISOString(),
      reforcoMensagem: mensagem ?? '', reforcoOperacao: a.operacao,
    });
  }
  await setState({ falhasSeguidas: 0 });

  const resumo = status === 'emitido' ? `emitido na ${ne}` : status === 'erro' ? `ERRO SIAFI${mensagem ? `: ${mensagem}` : ''}` : 'em processamento no SIAFI — confira depois';
  await logVisivel(`${status === 'emitido' ? '✅' : status === 'erro' ? '❌' : '⏳'} ${a.solicitacao || ''} ${a.operacao} de R$ ${fmtR$(valorFeito)} → ${resumo}`,
    status === 'emitido' ? 'success' : status === 'erro' ? 'error' : 'warn');
  if (a.origem !== 'solicitacao' && a.registroId && status === 'emitido') {
    // Irrisório feito: a solicitação está completa — o painel deixa de mostrar "falta"
    const reg = await lerRegistro(a.registroId);
    const base = Number(reg?.valorEmpenhado ?? 0);
    const pedido = Number(reg?.valorSolicitado ?? 0);
    const total = Math.round((base + a.valor) * 100) / 100;
    const oQue = a.tipo === 'anulacao' ? 'Anulação completa' : a.origem === 'complemento' ? 'Reforço completo' : 'Empenho completo';
    await logVisivel(`✅ ${a.solicitacao || ''}: ${oQue} na ${ne} — R$ ${fmtR$(base)} + ${a.operacao.toLowerCase()} R$ ${fmtR$(a.valor)} = R$ ${fmtR$(total)}`
      + (pedido > 0 && Math.abs(total - pedido) < 0.01 ? ' (o valor solicitado)' : pedido > 0 ? ` (solicitado R$ ${fmtR$(pedido)})` : ''), 'success');
    notifySidePanel({ type: 'DONE', ne, status, mensagem, payload, valorEmpenhado: total, valorSolicitado: pedido || total, reforco: 0,
      irrisorio: { base, valor: a.valor, operacao: a.operacao, tipo: a.tipo } });
  } else {
    notifySidePanel({ type: 'DONE', ne: ne ?? a.ne, status, mensagem, payload, valorEmpenhado: valorFeito, valorSolicitado: a.valor, reforco: complemento });
  }

  // Arredondamento deixou diferença: emenda o irrisório na mesma NE
  if (complemento && status !== 'erro') {
    if (complemento > limiteIrrisorio(s.altDegrau)) {
      await logVisivel(`⚠ Faltaram R$ ${fmtR$(complemento)} — mais que o arredondamento explica; confira e faça o ${COMPLEMENTO_CNET[a.tipo]} no CNET`, 'warn');
      return seguirFila(tabId);
    }
    // Resto de cada item (do arredondamento do robô); sem ele, o item único
    const restos = (s.altRestos ?? []).filter(x => x.valor >= 0.01);
    const somaRestos = restos.reduce((t, x) => t + x.valor, 0);
    const item = restos.length && restos.every(x => x.numeroItem) && Math.abs(somaRestos - complemento) < 0.01
      ? restos.map(x => ({ numeroItem: String(x.numeroItem), valor: String(x.valor) }))
      : a.itens?.length === 1 ? [{ numeroItem: a.itens[0].numeroItem, valor: String(complemento) }] : [];
    await setState({
      altStep: 0, altValorFeito: null, altDegrau: null, altRestos: null,
      alteracao: { ne: ne ?? a.ne, tipo: a.tipo, operacao: COMPLEMENTO_CNET[a.tipo], valor: complemento, itens: item,
        irrisorio: true, origem: 'complemento', registroId: id, solicitacao: a.solicitacao },
    });
    await logVisivel(`▶ Agora o ${COMPLEMENTO_CNET[a.tipo]} de R$ ${fmtR$(complemento)} na ${ne ?? a.ne} (o que o arredondamento deixou de fora)`, 'info');
    return true;
  }
  return seguirFila(tabId);
}

/**
 * Depois de um empenho novo: arredondamento "para menos" deixou diferença →
 * REFORÇO IRRISÓRIO na NE recém-emitida (precisa do número dela).
 */
async function depoisDoEmpenho(tabId, payload, r) {
  const s = await getState();
  const falta = r.reforco ?? 0;
  if (falta >= 0.01 && r.status !== 'erro' && !s.dryRun) {
    const sol = payload.numeroSolicitacao ?? '';
    if (!s.arredondado) {
      // Diferença sem arredondamento não é caso de irrisório: fica no relatório
      await logVisivel(`⚠ ${sol}: faltaram R$ ${fmtR$(falta)} sem arredondamento no CNET — confira (o robô não faz reforço irrisório nesse caso)`, 'warn');
    } else if (r.status !== 'emitido' || !r.ne) {
      await atualizarRegistro(r.registroId, { reforcoStatus: 'pendente-ne' });
      await logVisivel(`⚠ ${sol}: o reforço irrisório de R$ ${fmtR$(falta)} fica para depois — a NE ainda está em processamento no SIAFI`, 'warn');
    } else if (falta > limiteIrrisorio(s.degrauArredondamento)) {
      await logVisivel(`⚠ ${sol}: faltaram R$ ${fmtR$(falta)} — mais que o arredondamento explica; confira e faça o reforço no CNET`, 'warn');
    } else {
      const itens = payload.itensEmpenho ?? [];
      await setState({
        flow: 'alteracao-cnet', altStep: 0, altValorFeito: null, altDegrau: null, altRestos: null,
        alteracao: { ne: r.ne, tipo: 'reforco', operacao: 'REFORÇO IRRISÓRIO', valor: falta,
          itens: itens.length === 1 ? [{ numeroItem: itens[0].numeroItem, valor: String(falta) }] : [],
          irrisorio: true, origem: 'irrisorio', registroId: r.registroId, solicitacao: sol },
      });
      await logVisivel(`▶ ${sol}: fazendo o REFORÇO IRRISÓRIO de R$ ${fmtR$(falta)} na ${r.ne}…`, 'info');
      return true;
    }
  }
  return seguirFila(tabId);
}

/**
 * Falha na alteração. Da solicitação (reforço/anulação): registra e segue a fila,
 * como no empenho. Do irrisório: o principal já foi feito — anota no registro dele.
 */
async function falhaAlteracao(tabId, s, passo, erro, { status = 'falhou', url = null } = {}) {
  const a = s.alteracao ?? {};
  if (a.origem === 'solicitacao') return pularSolicitacao(tabId, ROTULO_ALT[passo] ?? passo, erro, { status, url });

  const aba = await chrome.tabs.get(tabId).catch(() => null);
  if (RX_SESSAO.test(aba?.url ?? '')) {
    const msg = `A sessão do CNET expirou (${a.operacao} da ${a.ne}). Entre de novo no CNET e use Retomar — o robô recomeça o irrisório.`;
    await appendLog(`❌ ${msg}`, 'error');
    await setState({ state: 'paused', altStep: 0 });
    notifySidePanel({ type: 'PAUSED', error: msg, step: 0 });
    return false;
  }
  const motivo = limparMotivo(erro) || 'erro sem descrição';
  if (a.registroId) {
    await atualizarRegistro(a.registroId, { reforcoStatus: status === 'conferir' ? 'conferir' : 'falhou', reforcoMotivo: `${ROTULO_ALT[passo]}: ${motivo}` });
  }
  await logVisivel(`⛔ ${a.operacao} de R$ ${fmtR$(a.valor ?? 0)} na ${a.ne} NÃO feito (${ROTULO_ALT[passo]}): ${motivo} — faça no CNET`, 'error');
  return seguirFila(tabId);
}


// ── Comunicação com Side Panel ────────────────────────────────────────────────

let sidePanelPort = null;

export function setSidePanelPort(port) { sidePanelPort = port; }

function notifySidePanel(msg) {
  if (sidePanelPort) {
    try { sidePanelPort.postMessage(msg); } catch { sidePanelPort = null; }
  }
}

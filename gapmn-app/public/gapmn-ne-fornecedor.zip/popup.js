import * as pdfjsLib from './pdf.min.mjs';

const SUPABASE_URL = 'https://fychrtyyqbzlfbzbvzqp.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ5Y2hydHl5cWJ6bGZiemJ2enFwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA5Mzk5NzcsImV4cCI6MjA4NjUxNTk3N30.i27qaCYX9qZ6liL9iXaOtYgddWgKyiM5eoobIN1loFw';

// Firefox usa namespace "browser", Chrome usa "chrome"
const _ext = typeof browser !== 'undefined' ? browser : chrome;
const _rt  = _ext.runtime;
pdfjsLib.GlobalWorkerOptions.workerSrc = _rt.getURL('pdf.worker.min.mjs');

const $body   = document.getElementById('body');
const $footer = document.getElementById('footer');
const $file   = document.getElementById('file-input');

let currentFile = null;
let pdfBase64   = null;
let fields = { ne_numero: '', cnpj: '', email: '', favorecido_nome: '', om_nome: '', contato: '' };

// ── Render helpers ──────────────────────────────────────────────────────────

function renderIdle() {
  $body.innerHTML = `
    <div class="drop-zone" id="dz">
      <div class="icon">📄</div>
      <div class="label">Arraste o PDF da NE aqui</div>
      <div class="sub">ou clique para selecionar o arquivo</div>
    </div>
    <div style="text-align:center;margin-top:4px;">
      <button id="btn-test-email" style="background:none;border:none;color:#64748b;font-size:11px;cursor:pointer;text-decoration:underline;padding:4px 0;">
        📧 Enviar e-mail de teste
      </button>
    </div>`;
  $footer.innerHTML = '';

  const dz = document.getElementById('dz');
  dz.addEventListener('click', () => $file.click());
  dz.addEventListener('dragover',  e => { e.preventDefault(); dz.classList.add('drag'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag'));
  dz.addEventListener('drop', e => {
    e.preventDefault();
    dz.classList.remove('drag');
    const f = e.dataTransfer.files[0];
    if (f?.type === 'application/pdf') handleFile(f);
    else showFileError();
  });

  document.getElementById('btn-test-email').addEventListener('click', renderTestEmail);
}

function renderTestEmail() {
  $body.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:12px;">
      <div style="padding:10px 12px;border-radius:8px;background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.2);font-size:11px;color:#94a3b8;line-height:1.5;">
        Envia um e-mail com dados fictícios para verificar o layout e o recebimento.<br>
        <strong style="color:#fb923c;">⚠ O PDF não é enviado no teste</strong> — para testar o anexo, arraste uma NE real.
      </div>
      <div class="field">
        <div class="field-label">Seu e-mail (destinatário do teste)</div>
        <input id="f-test-email" type="email" placeholder="seu@email.com" />
      </div>
    </div>`;

  $footer.innerHTML = `
    <button class="btn btn-ghost" id="btn-test-back">← Voltar</button>
    <button class="btn btn-primary" id="btn-test-send">Enviar Teste</button>`;

  document.getElementById('btn-test-back').addEventListener('click', resetAll);
  document.getElementById('btn-test-send').addEventListener('click', sendTestEmail);
}

async function sendTestEmail() {
  const email = document.getElementById('f-test-email')?.value?.trim();
  if (!email) {
    document.getElementById('f-test-email').style.borderColor = 'rgba(239,68,68,0.6)';
    return;
  }

  renderSpinner('Enviando e-mail de teste…');

  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/send-empenho-email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
      body: JSON.stringify({
        tipo: 'CONVOCACAO',
        email,
        ne_numero: '2026NE000001',
        om_nome: 'GAP-MN — TESTE',
        contato: 'Ten Fulano de Tal — (92) 98000-0000',
        favorecido_nome: 'EMPRESA TESTE LTDA',
        pdf_base64: null,
        pdf_filename: null,
      }),
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(txt || `HTTP ${res.status}`);
    }

    $body.innerHTML = `
      <div class="success-box">
        <div class="icon">✅</div>
        <div class="title">Teste Enviado!</div>
        <div class="info">Verifique a caixa de entrada de</div>
        <div class="info"><span class="val">${esc(email)}</span></div>
      </div>`;
    $footer.innerHTML = `<button class="btn btn-ghost" id="btn-novo-t">← Voltar</button>`;
    document.getElementById('btn-novo-t').addEventListener('click', resetAll);

  } catch (err) {
    $body.innerHTML = `<div class="error-box">Falha: ${esc(String(err))}</div>`;
    $footer.innerHTML = `
      <button class="btn btn-ghost" id="btn-te">← Voltar</button>
      <button class="btn btn-primary" id="btn-tr">Tentar Novamente</button>`;
    document.getElementById('btn-te').addEventListener('click', renderTestEmail);
    document.getElementById('btn-tr').addEventListener('click', sendTestEmail);
  }
}

function renderSpinner(label) {
  $body.innerHTML = `
    <div class="spinner">
      <div class="icon">⏳</div>
      <div class="label">${esc(label)}</div>
    </div>`;
  $footer.innerHTML = '';
}

function renderReview() {
  const badge = fields.email
    ? '<span class="badge badge-ok">encontrado</span>'
    : '<span class="badge badge-warn">não encontrado</span>';

  $body.innerHTML = `
    <div class="grid2">
      <div class="field">
        <div class="field-label">NE Nº</div>
        <input id="f-ne" class="mono" value="${esc(fields.ne_numero)}" placeholder="2026NE000001" />
      </div>
      <div class="field">
        <div class="field-label">CNPJ</div>
        <input id="f-cnpj" class="mono" value="${esc(fields.cnpj)}" readonly />
      </div>
    </div>
    <div class="field">
      <div class="field-label">Fornecedor / Razão Social</div>
      <input id="f-nome" value="${esc(fields.favorecido_nome)}" placeholder="Nome da empresa" />
    </div>
    <div class="field">
      <div class="field-label">E-mail do Fornecedor ${badge}</div>
      <input id="f-email" type="email" value="${esc(fields.email)}" placeholder="contato@empresa.com.br" />
    </div>
    <div class="field">
      <div class="field-label">OM Emitente</div>
      <input id="f-om" value="${esc(fields.om_nome)}" placeholder="Ex.: 1º BEC" />
    </div>
    <div class="field">
      <div class="field-label">Fiscal / Contato</div>
      <input id="f-contato" value="${esc(fields.contato)}" placeholder="Ten Fulano — (61) 99999-9999" />
    </div>`;

  $footer.innerHTML = `
    <button class="btn btn-ghost" id="btn-novo">← Novo</button>
    <button class="btn btn-primary" id="btn-send">Enviar Convocação</button>`;

  document.getElementById('btn-novo').addEventListener('click', resetAll);
  document.getElementById('btn-send').addEventListener('click', sendEmail);
}

function renderDone() {
  $body.innerHTML = `
    <div class="success-box">
      <div class="icon">✅</div>
      <div class="title">Convocação Enviada!</div>
      <div class="info">NE: <span class="val">${esc(fields.ne_numero)}</span></div>
      <div class="info">Para: <span class="val">${esc(fields.email)}</span></div>
    </div>`;
  $footer.innerHTML = `<button class="btn btn-ghost" id="btn-novo2">Nova NE</button>`;
  document.getElementById('btn-novo2').addEventListener('click', resetAll);
}

function renderError(msg) {
  $body.innerHTML = `<div class="error-box">${esc(msg)}</div>`;
  $footer.innerHTML = `
    <button class="btn btn-ghost" id="btn-edit">← Editar</button>
    <button class="btn btn-primary" id="btn-retry">Tentar Novamente</button>`;
  document.getElementById('btn-edit').addEventListener('click', renderReview);
  document.getElementById('btn-retry').addEventListener('click', sendEmail);
}

function showFileError() {
  $body.innerHTML = `<div class="error-box">Arquivo inválido. Selecione um PDF da NE.</div>`;
  $footer.innerHTML = `<button class="btn btn-ghost" id="btn-v">← Voltar</button>`;
  document.getElementById('btn-v').addEventListener('click', resetAll);
}

// ── File handling ───────────────────────────────────────────────────────────

$file.addEventListener('change', () => {
  const f = $file.files[0];
  if (f) handleFile(f);
  $file.value = '';
});

async function handleFile(file) {
  currentFile = file;
  renderSpinner('Extraindo dados do PDF…');

  try {
    const [arrayBuffer, b64] = await Promise.all([
      file.arrayBuffer(),
      toBase64(file),
    ]);
    pdfBase64 = b64;

    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let text = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      text += content.items.map(it => it.str).join(' ') + '\n';
    }

    fields = { ne_numero: '', cnpj: '', email: '', favorecido_nome: '', om_nome: '', contato: '' };
    parseText(text);
    renderSpinner('Consultando e-mail do fornecedor…');
    await lookupEmail();
    renderReview();
  } catch (err) {
    $body.innerHTML = `<div class="error-box">Erro ao processar PDF: ${esc(String(err))}</div>`;
    $footer.innerHTML = `<button class="btn btn-ghost" id="btn-v2">← Voltar</button>`;
    document.getElementById('btn-v2').addEventListener('click', resetAll);
  }
}

// ── PDF text parsing ────────────────────────────────────────────────────────

function parseText(text) {
  const lower = text.toLowerCase();

  // NE number: "2026NE000123" or "2026 NE 123"
  const m1 = text.match(/(20\d{2}NE\d{3,8})/i);
  if (m1) {
    fields.ne_numero = m1[1].toUpperCase();
  } else {
    const m2 = text.match(/\b(20\d{2})\s+NE\s*(\d{1,6})\b/i);
    if (m2) fields.ne_numero = `${m2[1]}NE${m2[2].padStart(6, '0')}`;
  }

  // Na NE há 2 CNPJs: o da UG Emitente (label "CNPJ") e o do fornecedor (label "Código").
  // Estratégia: achar e EXCLUIR o da UG — o restante é do fornecedor.
  const cnpjRe = /\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}/g;
  const allCnpjs = [...text.matchAll(cnpjRe)].map(m => m[0]);

  // Acha o CNPJ da UG Emitente: aparece próximo à palavra isolada "CNPJ"
  let ugCnpj = null;
  for (const m of text.matchAll(/\bCNPJ\b/gi)) {
    const trecho = text.slice(m.index, m.index + 120);
    const found = trecho.match(/(\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2})/);
    if (found) { ugCnpj = found[1]; break; }
  }
  console.log('[NE] UG CNPJ (excluído):', ugCnpj, '| Todos CNPJs:', allCnpjs);

  // CNPJ do fornecedor = qualquer CNPJ que não seja o da UG
  const fornCnpjs = allCnpjs.filter(c => c !== ugCnpj);
  if (fornCnpjs.length > 0) {
    fields.cnpj = fornCnpjs[0];
  } else if (allCnpjs.length > 0) {
    fields.cnpj = allCnpjs[allCnpjs.length - 1];
  }

  // Nome do fornecedor: vem logo após o CNPJ do Código, antes de "Endereço"/"CEP" etc.
  if (fields.cnpj) {
    const cnpjPos = text.indexOf(fields.cnpj);
    if (cnpjPos !== -1) {
      const nomeRaw = text.slice(cnpjPos + fields.cnpj.length)
        .replace(/[\r\n]+/g, ' ')
        .replace(/\s{2,}/g, ' ')
        .trim();
      const nomeCut = nomeRaw
        .replace(/\s*(Endere[çc]o|CEP\b|Munic[ií]pio|Telefone|\bUF\b|Fax\b|Bairro).*/i, '');
      if (nomeCut.length > 2) fields.favorecido_nome = nomeCut.slice(0, 80).trim();
    }
  }

  // OM name: text after a 6-digit UG code on the same area as "unidade gestora" or beginning
  const ugMatch = text.match(/\b(\d{6})\b\s+([A-ZÁÉÍÓÚÂÊÎÔÛÃÕÇ][A-ZÁÉÍÓÚÂÊÎÔÛÃÕÇa-záéíóúâêîôûãõç0-9º\s.'-]{5,60}?)(?=\s{2,}|\n|CNPJ|\d{2}\.\d{3})/);
  if (ugMatch) {
    fields.om_nome = ugMatch[2].replace(/\s+/g, ' ').trim();
  }

  // Contact: military rank + name (+ optional phone)
  const rankRe = /\b(Ten(?:ente)?[\s-]?(?:Cel|Coronel)?|Cel(?:oniel)?|Maj(?:or)?|Cap(?:itão|itan)?|[123]º?\s*Sgt|Sgt|Cb|Sd|Gen(?:eral)?|Brig(?:adeiro)?|Asp|Sub(?:ten)?)\b\.?\s+([A-ZÁÉÍÓÚÂÊÎÔÛÃÕÇ][a-záéíóúâêîôûãõç]+(?:\s+[A-ZÁÉÍÓÚÂÊÎÔÛÃÕÇ][a-záéíóúâêîôûãõç]+){1,4})/i;
  const rm = text.match(rankRe);
  if (rm) {
    fields.contato = rm[0].trim();
    const phoneRe = /\(?\d{2}\)?\s*\d{4,5}[-\s]?\d{4}/;
    const afterContact = text.slice(text.indexOf(rm[0]) + rm[0].length, text.indexOf(rm[0]) + rm[0].length + 80);
    const phone = afterContact.match(phoneRe);
    if (phone) fields.contato += ` — ${phone[0]}`;
  }
}

// ── Supabase lookup ─────────────────────────────────────────────────────────

async function lookupEmail() {
  if (!fields.cnpj) return;
  const cleaned = fields.cnpj.replace(/\D/g, '');
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/fornecedores_email?cnpj=eq.${cleaned}&select=email,nome_empresa`,
      { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
    );
    if (res.ok) {
      const rows = await res.json();
      if (rows.length > 0) {
        fields.email = rows[0].email || '';
        if (!fields.favorecido_nome && rows[0].nome_empresa) {
          fields.favorecido_nome = rows[0].nome_empresa;
        }
      }
    }
  } catch (_) { /* silencioso — usuário pode digitar o e-mail manualmente */ }
}

// ── Send ────────────────────────────────────────────────────────────────────

async function sendEmail() {
  // Capture latest values from form
  fields.ne_numero      = val('f-ne')      || fields.ne_numero;
  fields.email          = val('f-email')   || fields.email;
  fields.favorecido_nome = val('f-nome')   || fields.favorecido_nome;
  fields.om_nome        = val('f-om')      || fields.om_nome;
  fields.contato        = val('f-contato') || fields.contato;

  if (!fields.email) {
    renderError('Informe o e-mail do fornecedor antes de enviar.');
    return;
  }

  renderSpinner('Enviando convocação…');

  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/send-empenho-email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
      body: JSON.stringify({
        tipo: 'CONVOCACAO',
        email: fields.email,
        ne_numero: fields.ne_numero,
        om_nome: fields.om_nome,
        contato: fields.contato,
        favorecido_nome: fields.favorecido_nome,
        pdf_base64: pdfBase64,
        pdf_filename: currentFile?.name || `${fields.ne_numero || 'NE'}.pdf`,
      }),
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(txt || `HTTP ${res.status}`);
    }

    renderDone();
  } catch (err) {
    renderError(`Falha no envio: ${String(err)}`);
  }
}

// ── Utils ───────────────────────────────────────────────────────────────────

function resetAll() {
  currentFile = null;
  pdfBase64   = null;
  fields = { ne_numero: '', cnpj: '', email: '', favorecido_nome: '', om_nome: '', contato: '' };
  renderIdle();
}

function val(id) {
  return document.getElementById(id)?.value?.trim() || '';
}

function toBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload  = () => resolve(r.result.split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── Bootstrap ───────────────────────────────────────────────────────────────
// Se abrimos como popup padrão (clicar no ícone), reabrimos como janela destacada
// que não fecha ao clicar fora. A janela real tem ?w=1 na URL.
(async () => {
  const isStandaloneWindow = new URLSearchParams(location.search).has('w');

  if (!isStandaloneWindow) {
    // Abre como janela independente e fecha o popup imediatamente
    await _ext.windows.create({
      url: _rt.getURL('popup.html?w=1'),
      type: 'popup',
      width: 420,
      height: 600,
      focused: true,
    });
    window.close();
    return;
  }

  // É a janela real — inicializa normalmente
  document.getElementById('btn-close').addEventListener('click', () => window.close());
  renderIdle();
})();
